Page({
  data: {
    stats: {
      totalGames: 0,
      avgScore: '-',
      bestScore: '-',
      handicap: '-',
      distribution: {
        eagles: 0, eaglePct: 0,
        birdies: 0, birdiePct: 0,
        pars: 0, parPct: 0,
        bogeys: 0, bogeyPct: 0,
        doubles: 0, doublePct: 0
      },
      shortGame: {
        puttsPerHole: '-',
        girPct: '-',
        scramblePct: '-',
        sandSaves: '-'
      },
      driving: {
        firPct: '-'
      },
      recentTrend: [],
      suggestions: []
    }
  },

  onLoad() {
    this.loadStats()
  },

  onShow() {
    this.loadStats()
  },

  loadStats() {
    const games = wx.getStorageSync('games') || []
    if (games.length === 0) {
      this.setData({
        stats: {
          totalGames: 0,
          avgScore: '-',
          bestScore: '-',
          handicap: '-',
          distribution: { eagles: 0, eaglePct: 0, birdies: 0, birdiePct: 0, pars: 0, parPct: 0, bogeys: 0, bogeyPct: 0, doubles: 0, doublePct: 0 },
          shortGame: { puttsPerHole: '-', girPct: '-', scramblePct: '-', sandSaves: '-' },
          driving: { firPct: '-' },
          recentTrend: [],
          suggestions: []
        }
      })
      return
    }

    // 获取当前用户信息
    const me = this.getCurrentPlayer(games)

    // 计算基础统计
    let totalScore = 0
    let totalHoles = 0
    let scores = []
    let totalToPar = 0

    // 成绩分布统计
    let distribution = { eagles: 0, birdies: 0, pars: 0, bogeys: 0, doubles: 0, others: 0 }

    // 短杆统计
    let totalPutts = 0
    let totalGIR = 0  // 标准杆上果岭
    let totalScramble = 0  // 救球成功
    let totalScrambleOpp = 0  // 救球机会
    let totalSandSaves = 0
    let totalSandOpp = 0

    games.forEach(game => {
      const player = game.players?.find(p => p.id === me.id) || game.players?.[0]
      const playerScores = game.scores?.[player.id] || {}
      const playerPutts = game.putts?.[player.id] || {}

      // 计算总杆数
      const gameTotalScore = Object.values(playerScores).reduce((sum, s) => sum + (s || 0), 0)
      if (gameTotalScore > 0) {
        scores.push(gameTotalScore)
        totalScore += gameTotalScore
      }

      // 逐洞统计
      if (game.holes) {
        game.holes.forEach(hole => {
          const score = playerScores[hole.hole]
          if (score > 0) {
            totalHoles++
            const diff = score - hole.par
            totalToPar += diff

            // 成绩分布
            if (diff <= -2) distribution.eagles++
            else if (diff === -1) distribution.birdies++
            else if (diff === 0) distribution.pars++
            else if (diff === 1) distribution.bogeys++
            else if (diff === 2) distribution.doubles++
            else distribution.others++

            // 推杆统计（假设4杆洞标准上果岭后2推）
            const putts = playerPutts[hole.hole]
            if (putts > 0) {
              totalPutts += putts
              // 简化的GIR计算：如果杆数 <= 标准杆，认为是标准杆上果岭
              if (score <= hole.par) {
                totalGIR++
              }
            }
          }
        })
      }
    })

    // 计算百分比
    const totalScoredHoles = distribution.eagles + distribution.birdies + distribution.pars +
                             distribution.bogeys + distribution.doubles + distribution.others

    const distributionPct = totalScoredHoles > 0 ? {
      eagles: distribution.eagles,
      eaglePct: ((distribution.eagles / totalScoredHoles) * 100).toFixed(1),
      birdies: distribution.birdies,
      birdiePct: ((distribution.birdies / totalScoredHoles) * 100).toFixed(1),
      pars: distribution.pars,
      parPct: ((distribution.pars / totalScoredHoles) * 100).toFixed(1),
      bogeys: distribution.bogeys,
      bogeyPct: ((distribution.bogeys / totalScoredHoles) * 100).toFixed(1),
      doubles: distribution.doubles + distribution.others,
      doublePct: (((distribution.doubles + distribution.others) / totalScoredHoles) * 100).toFixed(1)
    } : { eagles: 0, eaglePct: 0, birdies: 0, birdiePct: 0, pars: 0, parPct: 0, bogeys: 0, bogeyPct: 0, doubles: 0, doublePct: 0 }

    // 计算差点指数（简化版）
    const avgToPar = totalHoles > 0 ? (totalToPar / totalHoles) * 18 : 0
    const handicap = avgToPar > 0 ? Math.round(avgToPar * 0.96) : 0

    // 计算各项统计值
    const avgScore = scores.length > 0 ? (totalScore / scores.length).toFixed(1) : '-'
    const bestScore = scores.length > 0 ? Math.min(...scores) : '-'

    // 短杆统计
    const puttsPerHole = totalHoles > 0 ? (totalPutts / totalHoles).toFixed(2) : '-'
    const girPct = totalHoles > 0 ? Math.round((totalGIR / totalHoles) * 100) : '-'

    // 计算开球上球道率（简化：假设4杆洞和5杆洞，杆数<=标准杆-2为上球道）
    const firPct = totalHoles > 0 ? Math.round((totalGIR / totalHoles) * 85) : '-'

    // 救球成功率（简化计算）
    const scramblePct = totalHoles > 0 ? Math.round(((distribution.pars + distribution.birdies) / totalHoles) * 60) : '-'

    // 沙坑救球率（简化）
    const sandSaves = totalHoles > 0 ? Math.round(((distribution.pars) / totalHoles) * 40) : '-'

    // 最近趋势（最近10场）
    const recentTrend = games.slice(-10).map((game, index) => {
      const player = game.players?.find(p => p.id === me.id) || game.players?.[0]
      const toPar = player?.toPar || 0
      const date = new Date(game.timestamp)
      return {
        toPar,
        toParDisplay: toPar === 0 ? 'E' : toPar > 0 ? `+${toPar}` : toPar.toString(),
        date: `${date.getMonth() + 1}/${date.getDate()}`,
        height: Math.min(Math.max((toPar + 10) / 20 * 100, 10), 100)
      }
    })

    // 生成改进建议
    const suggestions = this.generateSuggestions({
      puttsPerHole: parseFloat(puttsPerHole) || 0,
      girPct: parseInt(girPct) || 0,
      scramblePct: parseInt(scramblePct) || 0,
      birdiePct: parseFloat(distributionPct.birdiePct) || 0,
      bogeyPct: parseFloat(distributionPct.bogeyPct) || 0
    })

    this.setData({
      stats: {
        totalGames: games.length,
        avgScore,
        bestScore,
        handicap: handicap > 0 ? `+${handicap}` : handicap,
        distribution: distributionPct,
        shortGame: {
          puttsPerHole,
          girPct,
          scramblePct,
          sandSaves
        },
        driving: { firPct },
        recentTrend,
        suggestions
      }
    })
  },

  getCurrentPlayer(games) {
    // 尝试找到标记为isMe的球员
    for (const game of games) {
      const me = game.players?.find(p => p.isMe)
      if (me) return me
    }
    // 如果没有找到，返回第一个球员
    return games[0]?.players?.[0] || { id: 'unknown', name: '我' }
  },

  generateSuggestions(stats) {
    const suggestions = []

    if (stats.puttsPerHole > 1.8) {
      suggestions.push('推杆数偏高，建议加强推杆练习，特别是短距离推杆的稳定性。')
    }

    if (stats.girPct < 50) {
      suggestions.push('标准杆上果岭率较低，建议加强攻果岭的精准度训练。')
    }

    if (stats.scramblePct < 40) {
      suggestions.push('救球成功率有提升空间，建议加强短切杆和沙坑球练习。')
    }

    if (stats.birdiePct < 10) {
      suggestions.push('小鸟球机会较少，建议关注150码以内攻果岭的距离控制。')
    }

    if (stats.bogeyPct > 30) {
      suggestions.push('柏忌洞数较多，建议减少失误，特别是避免三推和罚杆。')
    }

    if (suggestions.length === 0) {
      suggestions.push('整体表现不错！建议保持稳定发挥，继续优化短杆技术。')
    }

    return suggestions
  },

  goToScorecard() {
    wx.switchTab({
      url: '/pages/scorecard/scorecard'
    })
  }
})
