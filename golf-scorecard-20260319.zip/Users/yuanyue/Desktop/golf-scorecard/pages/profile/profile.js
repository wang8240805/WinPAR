const app = getApp()

// 默认头像 - 按照官方文档示例
const defaultAvatarUrl = 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0'

Page({
  data: {
    version: '1.0.0',
    userInfo: null,
    avatarUrl: defaultAvatarUrl,
    nicknameFocus: false,
    stats: {
      games: 0,
      holes: 0,
      avgScore: '-',
      bestScore: '-'
    },
    level: null
  },

  onLoad() {
    this.loadStats()
    this.loadVersion()
    this.loadUserInfo()
  },

  onShow() {
    this.loadStats()
    this.loadUserInfo()
    // 设置TabBar选中状态 - 我的页面是第2个（首页0，我的1）
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 1 })
    }
    // 清除TabBar上的通知badge
    this.clearTabBarBadge()
  },

  // 加载用户信息
  loadUserInfo() {
    const userInfo = wx.getStorageSync('userInfo')
    if (userInfo) {
      this.setData({
        userInfo,
        avatarUrl: userInfo.avatarUrl || defaultAvatarUrl
      })
      // 如果有用户信息但是还没有openid，尝试获取
      if (userInfo.nickName && !userInfo.openid) {
        setTimeout(() => {
          this.getWxOpenid()
        }, 1000)
      }
    } else {
      this.setData({
        userInfo: null,
        avatarUrl: defaultAvatarUrl
      })
    }
  },

  // 选择头像（官方最新API - 完全遵循官方示例）
  onChooseAvatar(e) {
    const { avatarUrl } = e.detail
    let userInfo = wx.getStorageSync('userInfo') || {}
    userInfo.avatarUrl = avatarUrl
    wx.setStorageSync('userInfo', userInfo)
    this.setData({
      avatarUrl,
      userInfo
    })
    wx.showToast({ title: '头像已更新', icon: 'success' })

    // 如果已经有昵称了，尝试获取openid（如果还没有）
    if (userInfo.nickName && !userInfo.openid) {
      this.getWxOpenid()
    }

    // 如果还没有昵称，自动聚焦拉起微信昵称选择器
    if (!userInfo.nickName) {
      setTimeout(() => {
        // 通过设置focus属性触发聚焦，微信官方type="nickname"输入框聚焦时会自动弹出昵称选择选项
        this.setData({ nicknameFocus: true })
      }, 500)
    }
  },

  // 输入昵称（官方最新API，自动提供微信昵称选项）
  onNickNameInput(e) {
    const nickName = e.detail.value
    if (!nickName || nickName.trim().length === 0) return

    let userInfo = wx.getStorageSync('userInfo') || {}
    userInfo.nickName = nickName
    wx.setStorageSync('userInfo', userInfo)
    this.setData({ userInfo })
    wx.showToast({ title: '昵称已保存', icon: 'success' })

    // 获取微信openid（如果还没有的话）
    if (!userInfo.openid) {
      this.getWxOpenid()
    }
  },

  // 获取微信openid
  getWxOpenid() {
    console.log('[微信登录] 开始获取openid')
    wx.login({
      success: (res) => {
        console.log('[微信登录] wx.login 返回:', res)
        if (res.code) {
          // 调用云函数换取openid
          wx.cloud.callFunction({
            name: 'code2session',
            data: { code: res.code },
            success: (result) => {
              console.log('[微信登录] 云函数返回:', result)
              const data = result.result
              if (data.success && data.openid) {
                // 保存openid到userInfo
                let userInfo = wx.getStorageSync('userInfo') || {}
                userInfo.openid = data.openid
                if (data.unionid) {
                  userInfo.unionid = data.unionid
                }
                wx.setStorageSync('userInfo', userInfo)
                this.setData({ userInfo })
                console.log('[微信登录] openid保存成功:', data.openid)
              } else {
                console.error('[微信登录] 获取openid失败:', data.error)
              }
            },
            fail: (err) => {
              console.error('[微信登录] 云函数调用失败:', err)
            }
          })
        }
      },
      fail: (err) => {
        console.error('[微信登录] wx.login 失败:', err)
      }
    })
  },

  // 清除TabBar通知badge
  clearTabBarBadge() {
    // 尝试清除tabBar上的badge（删除球场tab后，我的页面是索引1）
    wx.removeTabBarBadge({
      index: 1,
      complete: (res) => {
        console.log('清除badge结果:', res)
      }
    })
    // 同时尝试清除storage中的通知计数
    wx.removeStorageSync('unreadCount')
    wx.removeStorageSync('noticeCount')
    wx.removeStorageSync('messageCount')
  },

  // 加载统计数据
  loadStats() {
    const games = wx.getStorageSync('games') || []
    const currentGame = wx.getStorageSync('currentGame')

    // 过滤出用户本人完成18洞的比赛
    const completedFullGames = games.filter(game => {
      if (!game.completed) return false

      // 查找当前用户
      const player = game.players?.find(p => p.isMe) || game.players?.[0]
      if (!player) return false

      // 新格式：player.scores数组
      if (player.scores && Array.isArray(player.scores)) {
        const validScores = player.scores.filter(s => s.strokes > 0)
        return validScores.length >= 18
      }
      // 旧格式：game.scores对象
      else if (game.scores && game.scores[player.id]) {
        const scores = game.scores[player.id]
        const validCount = Object.values(scores).filter(v => v > 0).length
        return validCount >= 18
      }
      // 兼容有statistics字段的情况
      else if (game.statistics && game.statistics[player.id]) {
        return game.statistics[player.id].holesPlayed >= 18
      }

      return false
    })

    // 总场次（只统计完成18洞的正式比赛）
    const totalGames = completedFullGames.length

    // 总洞数（只计算完成18洞比赛的）
    let totalHoles = 0
    completedFullGames.forEach(game => {
      const player = game.players?.find(p => p.isMe) || game.players?.[0]
      if (!player) return

      if (player.scores && Array.isArray(player.scores)) {
        totalHoles += player.scores.filter(s => s.strokes > 0).length
      } else if (game.scores && game.scores[player.id]) {
        totalHoles += Object.values(game.scores[player.id]).filter(v => v > 0).length
      }
    })

    // 计算平均杆和最佳成绩（只统计本人完成18洞的比赛）
    let allScores = []
    completedFullGames.forEach(game => {
      const player = game.players?.find(p => p.isMe) || game.players?.[0]
      if (!player) return

      if (player.totalScore) {
        allScores.push(player.totalScore)
      } else if (player.scores && Array.isArray(player.scores)) {
        const total = player.scores.filter(s => s.strokes > 0).reduce((sum, s) => sum + s.strokes, 0)
        if (total > 0) allScores.push(total)
      } else if (game.scores && game.scores[player.id]) {
        const total = Object.values(game.scores[player.id]).reduce((sum, s) => sum + (s || 0), 0)
        if (total > 0) allScores.push(total)
      }
    })

    const avgScore = allScores.length > 0
      ? (allScores.reduce((a, b) => a + b, 0) / allScores.length).toFixed(1)
      : '-'

    const bestScore = allScores.length > 0
      ? Math.min(...allScores)
      : '-'

    // 计算等级
    const level = this.calculateLevel(games.length)

    this.setData({
      stats: {
        games: totalGames,
        holes: Math.floor(totalHoles / (games.length || 1)) || 0,
        avgScore,
        bestScore
      },
      level
    })
  },

  // 计算用户等级
  calculateLevel(gameCount) {
    const levels = [
      { min: 0, name: '高尔夫新手', color: '#999' },
      { min: 5, name: '业余爱好者', color: '#2c8f4e' },
      { min: 20, name: '球场常客', color: '#1b5e20' },
      { min: 50, name: '高尔夫达人', color: '#ff9800' },
      { min: 100, name: '传奇球手', color: '#f44336' }
    ]

    for (let i = levels.length - 1; i >= 0; i--) {
      if (gameCount >= levels[i].min) {
        return levels[i]
      }
    }
    return levels[0]
  },

  // 加载版本号
  loadVersion() {
    const accountInfo = wx.getAccountInfoSync()
    this.setData({
      version: accountInfo.miniProgram.version || '1.0.0'
    })
  },

  // 跳转比赛记录
  goToHistory() {
    wx.navigateTo({
      url: '/pages/history/history'
    })
  },

  // 跳转数据统计
  goToStatistics() {
    wx.navigateTo({
      url: '/pages/statistics/statistics'
    })
  },

  // 跳转我的球场
  goToCourses() {
    wx.navigateTo({
      url: '/pages/courses/courses'
    })
  },

  // 跳转常用球员
  goToPlayers() {
    wx.navigateTo({
      url: '/pages/players/players'
    })
  },

  // 跳转设置
  goToSettings() {
    wx.navigateTo({
      url: '/pages/settings/settings'
    })
  },

  // 跳转意见反馈
  goToFeedback() {
    wx.navigateTo({
      url: '/pages/feedback/feedback'
    })
  },

  // 跳转打赏
  goToReward() {
    wx.navigateTo({
      url: '/pages/reward/reward'
    })
  },

  // 跳转关于页面
  goToAbout() {
    wx.showModal({
      title: '关于 WinPAR',
      content: '专业高尔夫智能记分工具，支持多人比赛、AI智能分析报告和完整技术统计，助力球技提升。',
      showCancel: false
    })
  },

  // 分享给朋友
  onShareAppMessage() {
    return {
      title: '推荐你一个好用的高尔夫记分工具',
      path: '/pages/index/index',
      imageUrl: '/assets/share-cover.png' // 如果有分享封面图的话
    }
  }
})
