Page({
  data: {
    gameCount: 0,
    // 通用设置
    defaultTee: '蓝Tee',
    autoLock: false,
    defaultPlayer: '我',
    // 记分设置
    voiceBroadcast: true,
    vibration: true,
    autoCompleteConfirm: true,
    defaultMatchPlay: false
  },

  onLoad() {
    this.loadData()
    this.loadSettings()
  },

  onShow() {
    this.loadData()

    // 设置TabBar选中状态 - 设置页面也是"我的"模块的一部分
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 2 })
    }
  },

  loadData() {
    const games = wx.getStorageSync('games') || []
    this.setData({
      gameCount: games.length
    })
  },

  // 加载用户设置
  loadSettings() {
    const settings = wx.getStorageSync('appSettings') || {}
    this.setData({
      defaultTee: settings.defaultTee || '蓝Tee',
      autoLock: settings.autoLock || false,
      defaultPlayer: settings.defaultPlayer || '我',
      voiceBroadcast: settings.voiceBroadcast !== false,
      vibration: settings.vibration !== false,
      autoCompleteConfirm: settings.autoCompleteConfirm !== false,
      defaultMatchPlay: settings.defaultMatchPlay || false
    })
  },

  // 保存设置
  saveSettings() {
    const settings = {
      defaultTee: this.data.defaultTee,
      autoLock: this.data.autoLock,
      defaultPlayer: this.data.defaultPlayer,
      voiceBroadcast: this.data.voiceBroadcast,
      vibration: this.data.vibration,
      autoCompleteConfirm: this.data.autoCompleteConfirm,
      defaultMatchPlay: this.data.defaultMatchPlay
    }
    wx.setStorageSync('appSettings', settings)
  },

  // 选择默认发球台
  selectDefaultTee() {
    const tees = ['蓝Tee', '白Tee', '红Tee', '金Tee', '黑Tee']
    wx.showActionSheet({
      itemList: tees,
      success: (res) => {
        this.setData({ defaultTee: tees[res.tapIndex] })
        this.saveSettings()
      }
    })
  },

  // 切换自动锁屏
  toggleAutoLock(e) {
    this.setData({ autoLock: e.detail.value })
    this.saveSettings()
    wx.showToast({
      title: e.detail.value ? '自动锁屏已开启' : '自动锁屏已关闭',
      icon: 'none'
    })
  },

  // 选择默认球员
  selectDefaultPlayer() {
    const players = wx.getStorageSync('savedPlayers') || []
    const playerNames = players.map(p => p.name).concat(['我'])

    wx.showActionSheet({
      itemList: playerNames,
      success: (res) => {
        this.setData({ defaultPlayer: playerNames[res.tapIndex] })
        this.saveSettings()
      }
    })
  },

  // 切换语音播报
  toggleVoiceBroadcast(e) {
    this.setData({ voiceBroadcast: e.detail.value })
    this.saveSettings()
    wx.showToast({
      title: e.detail.value ? '语音播报已开启' : '语音播报已关闭',
      icon: 'none'
    })
  },

  // 切换震动反馈
  toggleVibration(e) {
    this.setData({ vibration: e.detail.value })
    this.saveSettings()
    wx.showToast({
      title: e.detail.value ? '震动反馈已开启' : '震动反馈已关闭',
      icon: 'none'
    })
  },

  // 切换自动完成确认
  toggleAutoCompleteConfirm(e) {
    this.setData({ autoCompleteConfirm: e.detail.value })
    this.saveSettings()
    wx.showToast({
      title: e.detail.value ? '自动确认已开启' : '自动确认已关闭',
      icon: 'none'
    })
  },

  // 切换默认显示比洞赛
  toggleDefaultMatchPlay(e) {
    this.setData({ defaultMatchPlay: e.detail.value })
    this.saveSettings()
    wx.showToast({
      title: e.detail.value ? '默认比洞赛已开启' : '默认比杆赛已开启',
      icon: 'none'
    })
  },

  // 导出数据
  exportData() {
    wx.showToast({ title: '开发中，敬请期待', icon: 'none' })
  },

  // 清除历史记录
  clearHistory() {
    if (this.data.gameCount === 0) {
      wx.showToast({ title: '暂无历史记录', icon: 'none' })
      return
    }

    wx.showModal({
      title: '确认清除',
      content: `确定要清除 ${this.data.gameCount} 场比赛记录吗？此操作不可恢复。`,
      confirmColor: '#f44336',
      success: (res) => {
        if (res.confirm) {
          wx.removeStorageSync('games')
          this.setData({ gameCount: 0 })
          wx.showToast({ title: '已清除', icon: 'success' })
        }
      }
    })
  },

  // 清除所有数据
  clearAllData() {
    wx.showModal({
      title: '确认清除',
      content: '确定要清除所有数据吗？包括比赛记录、设置和球员信息。此操作不可恢复！',
      confirmColor: '#f44336',
      success: (res) => {
        if (res.confirm) {
          wx.clearStorageSync()
          this.setData({
            gameCount: 0
          })

          // 重新初始化默认设置
          this.loadSettings()

          wx.showToast({
            title: '已重置',
            icon: 'success',
            duration: 2000
          })

          setTimeout(() => {
            wx.switchTab({ url: '/pages/index/index' })
          }, 1500)
        }
      }
    })
  }
})