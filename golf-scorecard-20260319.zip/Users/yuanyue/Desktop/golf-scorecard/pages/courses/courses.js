const app = getApp()
// 使用准确数据（374个球场，正确Par分布）
const { CHINA_COURSES } = require('../../data/courses-accurate.js')
const { calculateDistance } = require('../../utils/geo-utils.js')

// 开发模式开关
const DEV_MODE = false

Page({
  data: {
    courses: [],
    filteredCourses: [],
    favoriteCourseIds: [],
    showDetailModal: false,
    detailCourse: { holes: [] },
    userCity: '', // 用户所在城市
    userLocation: null,
    showOcrResult: false,
    recognizedCourse: { name: '', holes: [] }
  },

  onLoad() {
    // 先初始化默认空数组，再加载数据
    this.setData({ favoriteCourseIds: [] }, () => {
      this.loadUserData()
      this.getUserLocation()
    })
  },

  onShow() {
    this.loadUserData()
    this.loadCourses()
    // 设置TabBar选中状态 - 球场页面是第1个
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 1 })
    }
  },

  // 获取用户位置
  getUserLocation() {
    // 开发模式：使用模拟位置
    if (DEV_MODE) {
      this.setData({
        userLocation: { latitude: 39.90, longitude: 116.40 }
      }, () => {
        this.loadCourses()
      })
      return
    }

    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        const location = {
          latitude: res.latitude,
          longitude: res.longitude
        }
        this.setData({ userLocation: location })

        // 使用逆地理编码获取城市名称
        this.getCityFromLocation(location)
      },
      fail: () => {
        // 获取位置失败，继续加载所有球场
        this.loadCourses()
      }
    })
  },

  // 根据坐标获取城市（简化版，使用内置数据匹配）
  getCityFromLocation(location) {
    // 找到最近的球场，以其城市为准
    let nearestCourse = null
    let minDistance = Infinity

    CHINA_COURSES.forEach(course => {
      const distance = calculateDistance(
        location.latitude, location.longitude,
        course.latitude, course.longitude
      )
      if (distance < minDistance) {
        minDistance = distance
        nearestCourse = course
      }
    })

    let userCity = '北京'
    if (nearestCourse) {
      if (nearestCourse.province === nearestCourse.city) {
        userCity = nearestCourse.province
      } else {
        userCity = `${nearestCourse.province} ${nearestCourse.city}`
      }
    }
    this.setData({ userCity }, () => {
      this.loadCourses()
    })
  },

  // 加载用户数据（收藏）
  loadUserData() {
    try {
      const favoriteCourseIds = wx.getStorageSync('favoriteCourseIds')
      // 确保是数组
      if (Array.isArray(favoriteCourseIds)) {
        this.setData({ favoriteCourseIds })
      } else {
        this.setData({ favoriteCourseIds: [] })
        wx.setStorageSync('favoriteCourseIds', [])
      }
    } catch (e) {
      this.setData({ favoriteCourseIds: [] })
    }
  },

  // 加载球场数据：只显示收藏的 + 最近10个
  loadCourses() {
    console.log('加载我的球场')
    const allCourses = CHINA_COURSES
    const games = wx.getStorageSync('games') || []
    const { favoriteCourseIds, userLocation } = this.data

    // 确保 favoriteCourseIds 是数组
    const safeFavoriteIds = Array.isArray(favoriteCourseIds) ? favoriteCourseIds : []

    // 统计每个球场的打球次数
    const playCountMap = {}
    games.forEach(game => {
      if (game.courseId) {
        playCountMap[game.courseId] = (playCountMap[game.courseId] || 0) + 1
      }
    })

    // 处理所有球场数据，计算距离
    const coursesWithStats = allCourses.map(course => {
      // 跳过没有 holes 数据的球场
      if (!course || !course.holes || !Array.isArray(course.holes)) {
        return null
      }
      // 计算距离
      let distance = Infinity
      if (userLocation && course.latitude && course.longitude) {
        distance = this.calculateDistance(
          userLocation.latitude, userLocation.longitude,
          course.latitude, course.longitude
        )
      }
      return {
        ...course,
        totalPar: course.holes.reduce((sum, h) => sum + h.par, 0),
        playCount: playCountMap[course.id] || 0,
        isFavorite: course.id ? safeFavoriteIds.includes(course.id) : false,
        distance: distance
      }
    }).filter(c => c !== null) // 过滤掉无效数据

    // 1. 先筛选收藏的球场
    const favoriteCourses = coursesWithStats.filter(c => c.isFavorite)

    // 2. 筛选最近的10个球场（排除已经在收藏里的）
    const nonFavoriteCourses = coursesWithStats
      .filter(c => !c.isFavorite)
      .sort((a, b) => a.distance - b.distance) // 按距离升序
      .slice(0, 10) // 取前10个

    // 合并：收藏的在前，最近的在后
    const mergedCourses = [...favoriteCourses, ...nonFavoriteCourses]

    this.setData({
      courses: mergedCourses,
      filteredCourses: mergedCourses
    })
  },

  // 跳转到全部球场页面
  goToAllCourses() {
    wx.navigateTo({
      url: '/pages/all-courses/all-courses'
    })
  },

  // 切换收藏状态
  toggleFavorite(e) {
    const courseId = e.currentTarget.dataset.courseId
    if (!courseId) return

    const { favoriteCourseIds } = this.data
    // 确保是数组
    const safeFavorites = Array.isArray(favoriteCourseIds) ? favoriteCourseIds : []

    let newFavorites
    if (safeFavorites.includes(courseId)) {
      newFavorites = safeFavorites.filter(id => id !== courseId)
      wx.showToast({ title: '已取消收藏', icon: 'none' })
    } else {
      newFavorites = [...safeFavorites, courseId]
      wx.showToast({ title: '已收藏', icon: 'success' })
    }

    wx.setStorageSync('favoriteCourseIds', newFavorites)
    this.setData({ favoriteCourseIds: newFavorites }, () => {
      this.loadCourses()
    })
  },

  // 添加球场
  addCourse() {
    // 初始化18洞数据
    const holes = []
    for (let i = 1; i <= 18; i++) {
      holes.push({
        hole: i,
        par: 4,
        distance: 0,
        handicap: i
      })
    }

    this.setData({
      showModal: true,
      editingCourse: null,
      formData: {
        name: '',
        location: '',
        holes
      }
    })
  },

  // 编辑球场
  editCourse(e) {
    const course = e.currentTarget.dataset.course
    if (!course.isCustom) {
      wx.showToast({ title: '预设球场不可编辑', icon: 'none' })
      return
    }

    this.setData({
      showModal: true,
      editingCourse: course,
      formData: {
        name: course.name,
        location: course.location || '',
        holes: course.holes.map(h => ({ ...h }))
      }
    })
  },

  // 查看球场详情
  viewCourseDetail(e) {
    const course = e.currentTarget.dataset.course
    this.setData({
      showDetailModal: true,
      detailCourse: course
    })
  },

  // 关闭详情弹窗
  closeDetailModal() {
    this.setData({ showDetailModal: false })
  },

  preventHide() {
    // 阻止冒泡
  },

  // OCR识别计分卡
  openOcrScanner() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['camera', 'album'],
      camera: 'back',
      success: (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath
        wx.showLoading({ title: '识别中...' })
        this.recognizeScorecard(tempFilePath)
      },
      fail: () => {
        wx.showToast({ title: '取消选择', icon: 'none' })
      }
    })
  },

  // 识别计分卡图片
  recognizeScorecard(imagePath) {
    wx.hideLoading()
    // 临时方案：先提示用户OCR功能需要配置插件
    wx.showModal({
      title: '功能待配置',
      content: 'OCR识别功能需要先在微信公众平台添加插件，添加后取消代码注释即可使用。暂时可以使用手动添加球场功能。',
      showCancel: false
    })

    // 开通OCR插件后，请删除上面的临时代码并取消下面的注释
    /*
    // 使用微信小程序OCR插件（需要在微信公众平台开通并添加插件）
    // 插件申请地址：https://mp.weixin.qq.com/wxopen/pluginbasicinfo?action=get&appid=wx4418e3e031e551be
    try {
      const OCR = requirePlugin('ocr-plugin')
      const ocr = new OCR()

      ocr.recognize({
        type: 0, // 0 通用印刷体识别
        image: imagePath,
        success: (res) => {
          wx.hideLoading()
          const ocrText = res.words_result.map(item => item.word).join('\n')
          const courseData = this.parseOcrText(ocrText)

          if (courseData.holes.length === 18) {
            this.setData({
              showOcrResult: true,
              recognizedCourse: courseData
            })
          } else if (courseData.holes.length > 0) {
            wx.showModal({
              title: '识别不完整',
              content: `仅识别到${courseData.holes.length}个洞，是否保存并手动补充剩余洞数据？`,
              confirmText: '保存',
              success: (res) => {
                if (res.confirm) {
                  this.setData({
                    showOcrResult: true,
                    recognizedCourse: courseData
                  })
                }
              }
            })
          } else {
            wx.showModal({
              title: '识别失败',
              content: '未能识别到任何洞数据，请确保图片清晰包含完整计分卡，或手动输入数据',
              showCancel: false
            })
          }
        },
        fail: (err) => {
          wx.hideLoading()
          wx.showModal({
            title: '识别失败',
            content: 'OCR识别服务调用失败，请确保已在微信公众平台开通OCR插件，或手动输入数据',
            showCancel: false
          })
        }
      })
    } catch (e) {
      wx.hideLoading()
      wx.showModal({
        title: '功能未启用',
        content: 'OCR插件未安装，请先在微信公众平台添加OCR插件',
        showCancel: false
      })
    }
    */
  },

  // 解析OCR文本提取洞数据
  parseOcrText(text) {
    const course = {
      name: '',
      par: 0,
      holes: []
    }

    // 尝试提取球场名称
    const nameMatch = text.match(/(.*?)(高尔夫|球场|俱乐部)/)
    if (nameMatch) {
      course.name = nameMatch[0]
    }

    // 匹配洞数据：洞号 + Par + 距离
    const holePattern = /[第洞]*(\d{1,2})\D*?[Pp][Aa][Rr]*\s*(\d)\D*?(\d{2,4})\s*[码|Y]/g
    let match
    const holesMap = {}

    while ((match = holePattern.exec(text)) !== null) {
      const holeNum = parseInt(match[1])
      const par = parseInt(match[2])
      const distance = parseInt(match[3])

      if (1 <= holeNum <= 18 && 3 <= par <=5 && 100 <= distance <= 700) {
        holesMap[holeNum] = {
          hole: holeNum,
          par: par,
          distance: distance,
          handicap: 0
        }
      }
    }

    // 转换为数组并排序
    course.holes = Object.values(holesMap).sort((a, b) => a.hole - b.hole)
    course.par = course.holes.reduce((sum, h) => sum + h.par, 0)

    return course
  },

  // 确认识别结果
  confirmRecognizedCourse() {
    const { recognizedCourse, userCity, userLocation } = this.data
    const customCourses = wx.getStorageSync('customCourses') || []

    // 生成新球场ID
    const newCourseId = `custom-${Date.now()}`
    const newCourse = {
      id: newCourseId,
      name: recognizedCourse.name || '自定义球场',
      location: userCity || '',
      province: userCity || '',
      city: userCity || '',
      latitude: userLocation?.latitude || 0,
      longitude: userLocation?.longitude || 0,
      par: recognizedCourse.par,
      holes: recognizedCourse.holes,
      isCustom: true,
      playCount: 0
    }

    // 保存到本地存储
    customCourses.push(newCourse)
    wx.setStorageSync('customCourses', customCourses)

    // 刷新球场列表
    this.loadCourses()

    this.setData({ showOcrResult: false })
    wx.showToast({ title: '球场添加成功', icon: 'success' })
  },

  // 关闭OCR结果弹窗
  closeOcrModal() {
    this.setData({ showOcrResult: false })
  },

  // 获取排序方式文本
  getSortByText() {
    const texts = { playCount: '按次数', name: '按名称', distance: '按距离' }
    return texts[this.data.sortBy] || '排序'
  }
})
