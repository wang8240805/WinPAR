Page({
  data: {
    selectedAmount: 0,
    customAmount: '',
    showMessage: false,
    messageText: '',
    supporters: [],
    messages: [
      '感谢您的支持，我会继续努力！',
      '您的每一份支持都是我前进的动力！',
      '谢谢您的咖啡，代码更有灵感了！',
      '感谢您的认可，会继续做好用的功能！',
      '您的支持让这个项目变得更好！'
    ]
  },

  onLoad() {
    this.loadSupporters()
  },

  onShow() {
    // 设置TabBar选中状态 - 打赏页面属于"我的"模块
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 3 })
    }
  },

  // 加载支持者列表
  loadSupporters() {
    // 这里可以从服务器获取真实的支持者列表
    // 现在使用模拟数据
    const supporters = wx.getStorageSync('supporters') || [
      { id: '1', name: 'Golf爱好者', amount: 18, time: Date.now() - 86400000 },
      { id: '2', name: '高尔夫小王子', amount: 66, time: Date.now() - 172800000 }
    ]
    this.setData({ supporters })
  },

  // 选择金额
  selectAmount(e) {
    this.setData({
      selectedAmount: e.currentTarget.dataset.amount,
      customAmount: ''
    })
  },

  // 输入自定义金额
  onCustomAmountInput(e) {
    const value = e.detail.value
    this.setData({
      customAmount: value,
      selectedAmount: 0
    })
  },

  // 提交打赏
  submitReward() {
    const { selectedAmount, customAmount } = this.data
    const amount = selectedAmount || parseFloat(customAmount)

    if (!amount || amount <= 0) {
      wx.showToast({ title: '请选择或输入金额', icon: 'none' })
      return
    }

    if (amount < 1) {
      wx.showToast({ title: '金额不能少于1元', icon: 'none' })
      return
    }

    // 检查云开发是否可用
    if (!wx.cloud) {
      wx.showModal({
        title: '功能不可用',
        content: '打赏功能需要云开发支持，请检查配置',
        showCancel: false
      })
      return
    }

    // 确认支付
    wx.showModal({
      title: '确认打赏',
      content: `确认打赏 ¥${amount} 支持开发者吗？`,
      confirmText: '确认支付',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          this.createOrder(amount)
        }
      }
    })
  },

  // 创建支付订单，调用云函数获取支付参数
  createOrder(amount) {
    wx.showLoading({ title: '发起支付...' })

    // 调用云函数创建订单
    wx.cloud.callFunction({
      name: 'createRewardOrder',
      data: {
        amount: amount,
        timestamp: Date.now()
      },
      success: (res) => {
        wx.hideLoading()
        console.log('创建订单成功', res)

        if (res.result && res.result.payment) {
          // 发起微信支付
          wx.requestPayment({
            ...res.result.payment,
            success: (payRes) => {
              console.log('支付成功', payRes)
              this.handlePaymentSuccess(amount)
            },
            fail: (payErr) => {
              console.log('支付失败', payErr)
              if (payErr.errMsg !== 'requestPayment:fail cancel') {
                wx.showToast({
                  title: '支付失败，请重试',
                  icon: 'none'
                })
              }
            }
          })
        } else {
          wx.showToast({
            title: '创建订单失败',
            icon: 'none'
          })
        }
      },
      fail: (err) => {
        wx.hideLoading()
        console.error('创建订单失败', err)
        wx.showToast({
          title: '创建订单失败，请检查云函数配置',
          icon: 'none'
        })
      }
    })
  },

  // 支付成功处理
  handlePaymentSuccess(amount) {
    // 显示随机感谢语
    const messages = this.data.messages
    const messageText = messages[Math.floor(Math.random() * messages.length)]

    this.setData({
      showMessage: true,
      messageText
    })

    // 保存本地打赏记录
    const userInfo = wx.getStorageSync('userInfo')
    const supporter = {
      id: Date.now().toString(),
      name: userInfo ? userInfo.nickName : '匿名用户',
      amount: amount,
      time: Date.now()
    }

    const supporters = wx.getStorageSync('supporters') || []
    supporters.unshift(supporter)
    wx.setStorageSync('supporters', supporters)

    this.setData({
      supporters: supporters.slice(0, 10),
      selectedAmount: 0,
      customAmount: ''
    })

    // 保存到云端数据库
    if (wx.cloud) {
      const db = wx.cloud.database()
      db.collection('rewards').add({
        data: {
          ...supporter,
          createTime: db.serverDate(),
          userInfo: userInfo || null
        },
        success: res => {
          console.log('打赏记录保存云端成功', res._id)
        },
        fail: err => {
          console.error('保存打赏记录失败', err)
        }
      })
    }

    wx.showToast({
      title: '打赏成功，感谢支持！',
      icon: 'success',
      duration: 2000
    })
  }
})
