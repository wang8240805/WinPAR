Page({
  data: {
    games: [],
    courses: [],
    totalPlayers: 0,
    avgScore: null,
    bestScore: null,
    hasMore: false,
    pageSize: 10,
    currentPage: 1
  },

  onLoad() {
    this.loadData()
  },

  onShow() {
    this.loadData()
    // 设置TabBar选中状态 - 历史现在是第1个
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 1 })
    }
  },

  loadData() {
    const courses = wx.getStorageSync('courses') || []
    const currentGame = wx.getStorageSync('currentGame')
    let games = wx.getStorageSync('games') || []

    // 合并进行中的比赛
    if (currentGame) {
      games = [...games, currentGame]
    }

    // 反转顺序，最新的在前
    games = games.reverse()

    // 格式化数据
    const formattedGames = this.formatGames(games)

    this.setData({
      courses,
      games: formattedGames,
      hasMore: games.length > this.data.pageSize
    })

    this.calculateOverview(games.filter(g => g.completed))
  },

  formatGames(games) {
    return games.slice(0, this.data.pageSize).map(game => {
      const date = new Date(game.timestamp)
      const playerResults = this.calculatePlayerResults(game)
      const stats = this.aggregateStats(game)

      return {
        ...game,
        date: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`,
        playerResults,
        stats,
        expanded: false
      }
    })
  },

  calculatePlayerResults(game) {
    if (!game.statistics) return []

    return game.players.map(player => {
      const stats = game.statistics[player.id]
      const total = stats?.totalScore || 0
      const toPar = stats?.toPar || 0

      return {
        playerId: player.id,
        name: player.name,
        color: player.color,
        total,
        toPar,
        toParDisplay: toPar === 0 ? 'E' : toPar > 0 ? `+${toPar}` : toPar.toString(),
        toParClass: toPar < 0 ? 'under' : toPar > 0 ? 'over' : ''
      }
    }).sort((a, b) => a.total - b.total)
  },

  aggregateStats(game) {
    const stats = { eagles: 0, birdies: 0, pars: 0, bogeys: 0, doubles: 0 }

    if (!game.statistics) return stats

    Object.values(game.statistics).forEach(playerStats => {
      stats.eagles += playerStats.eagles || 0
      stats.birdies += playerStats.birdies || 0
      stats.pars += playerStats.pars || 0
      stats.bogeys += playerStats.bogeys || 0
      stats.doubles += (playerStats.doubleBogeys || 0) + (playerStats.others || 0)
    })

    return stats
  },

  calculateOverview(completedGames) {
    if (completedGames.length === 0) return

    // 统计球员数
    const allPlayers = new Set()
    let totalScores = 0
    let scoreCount = 0
    let bestScore = Infinity

    completedGames.forEach(game => {
      game.players.forEach(p => allPlayers.add(p.id))

      if (game.statistics) {
        Object.values(game.statistics).forEach(stats => {
          if (stats.totalScore) {
            totalScores += stats.totalScore
            scoreCount++
            bestScore = Math.min(bestScore, stats.totalScore)
          }
        })
      }
    })

    this.setData({
      totalPlayers: allPlayers.size,
      avgScore: scoreCount > 0 ? Math.round(totalScores / scoreCount) : null,
      bestScore: bestScore === Infinity ? null : bestScore
    })
  },

  toggleExpand(e) {
    const index = e.currentTarget.dataset.index
    const games = this.data.games
    games[index].expanded = !games[index].expanded
    this.setData({ games })
  },

  continueGame(e) {
    const game = e.currentTarget.dataset.game
    wx.setStorageSync('currentGame', game)
    wx.switchTab({
      url: '/pages/scorecard/scorecard'
    })
  },

  viewDetail(e) {
    const game = e.currentTarget.dataset.game
    // 可以导航到详情页面
    wx.showModal({
      title: game.courseName,
      content: `比赛时间：${game.date}\n\n球员成绩：\n${game.playerResults.map(p =>
        `${p.name}: ${p.total}杆 (${p.toParDisplay})`
      ).join('\n')}`,
      showCancel: false
    })
  },

  deleteGame(e) {
    const game = e.currentTarget.dataset.game

    wx.showModal({
      title: '确认删除',
      content: '确定要删除这场比赛记录吗？此操作不可恢复。',
      confirmColor: '#f44336',
      success: (res) => {
        if (res.confirm) {
          // 删历史记录
          let games = wx.getStorageSync('games') || []
          games = games.filter(g => g.id !== game.id)
          wx.setStorageSync('games', games)

          // 如果删除的是当前进行中的比赛，也清除
          const currentGame = wx.getStorageSync('currentGame')
          if (currentGame && currentGame.id === game.id) {
            wx.removeStorageSync('currentGame')
          }

          wx.showToast({ title: '已删除', icon: 'success' })
          this.loadData()
        }
      }
    })
  },

  loadMore() {
    const currentPage = this.data.currentPage + 1
    const allGames = wx.getStorageSync('games') || []
    const currentGame = wx.getStorageSync('currentGame')

    let games = [...allGames]
    if (currentGame) {
      games.push(currentGame)
    }
    games = games.reverse()

    const start = this.data.pageSize * (currentPage - 1)
    const end = start + this.data.pageSize
    const moreGames = games.slice(start, end)

    if (moreGames.length === 0) {
      this.setData({ hasMore: false })
      return
    }

    const formattedGames = this.formatGames(games.slice(0, end))

    this.setData({
      games: formattedGames,
      currentPage,
      hasMore: games.length > end
    })
  }
})