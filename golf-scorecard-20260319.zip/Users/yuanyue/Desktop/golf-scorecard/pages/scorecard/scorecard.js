const app = getApp()
const { GAME_MODES } = require('../../data/game-modes.js')
const voiceRecognition = require('../../utils/voice-recognition.js')
const analysisReport = require('../../utils/analysis-report.js')
const posterGenerator = require('../../utils/poster-generator.js')
const preferenceManager = require('../../utils/preference-manager.js')
const plugin = requirePlugin('WechatSI')
const OCRPlugin = requirePlugin('ocr-plugin')

Page({
  data: {
    currentGame: null,
    currentHole: 1,
    holes: [],
    totalHoles: 18,
    totalPar: 72,
    currentHoleData: {},
    currentDate: '',
    courses: [],
    gameModes: GAME_MODES,
    currentMode: null,
    leaderInfo: null,
    showModeSelector: false,
    showAddPlayer: false,
    // 当前编辑的成绩
    editingScore: {
      playerId: null,
      playerName: '',
      strokes: null,
      putts: 2,
      penalties: {
        ob: 0,
        water: 0,
        other: 0
      },
      advancedStats: {
        bunker: 0,
        bunkerSave: 0,
        chip: 0,
        chipIn: 0
      },
      showCustomInput: false
    },
    showAdvanced: false,
    // 让洞/让杆设置
    showHandicapModal: false,
    editingHandicap: {
      playerId: null,
      handicapStrokes: 0
    },
    handicapType: 'holes', // 'holes' 或 'strokes'
    // 组队设置
    showTeamModal: false,
    // 地主设置
    showLandlordModal: false,
    // 语音输入
    isRecording: false,
    showVoiceToast: false,
    showVoiceModal: false,
    voiceText: '',
    voiceResult: '',
    showVoiceHint: true,
    // 语音播报
    isPlayingTip: false,
    // 球员总杆显示列表（与players数组顺序一致）
    playerTotalList: [],
    // 记分卡网格数据（预计算每个洞每个球员的成绩）
    scoreGridData: [],
    // OCR校对
    showOcrVerifyModal: false,
    originalHoles: [],
    originalTotalPar: 0,
    ocrHoles: [],
    ocrTotalPar: 0,
    hasDiff: false,
    hasScoreDiff: false
  },

  onLoad(options) {
    // 获取gameId参数（多人同步比赛）
    if (options && options.gameId) {
      this.gameId = options.gameId
      this.isCloudGame = true
    }

    this.loadCourses()
    this.loadGame()
  },

  // 页面首次渲染完成时初始化插件
  onReady() {
    // 语音识别 - 使用微信同声传译插件官方正确方式
    // 插件自带录音+识别，不需要自己录音
    console.log('[语音识别] 页面ready，开始初始化插件')
    try {
      const plugin = requirePlugin('WechatSI')
      console.log('[语音识别] 插件加载成功:', plugin)

      this.voiceManager = plugin.getRecordRecognitionManager()
      console.log('[语音识别] 语音管理器创建成功:', this.voiceManager)

      // 识别开始
      this.voiceManager.onStart((res) => {
        console.log('[语音识别] 识别已开始', res)
      })

      // 识别结束，直接返回结果（插件已经识别完了）
      this.voiceManager.onStop((res) => {
        console.log('[语音识别] 识别完成，完整返回:', res)
        const { result, tempFilePath, duration } = res
        console.log(`[语音识别] 时长: ${duration}ms, 识别结果: "${result}"`)

        // 检查录音时长，太短可能没有内容
        if (!duration || duration < 1000) {
          this.setData({ isRecording: false, showVoiceModal: false })
          wx.showToast({ title: '说话太短，请重试', icon: 'none' })
          return
        }

        if (!result || result.trim().length === 0) {
          this.setData({ isRecording: false, showVoiceModal: false })
          wx.showToast({ title: '未识别到有效内容', icon: 'none' })
          return
        }

        // 插件已经识别完了，直接显示弹窗
        const text = result.trim()
        console.log('[语音识别] 最终识别文本:', text)

        this.setData({
          isRecording: false,
          showVoiceModal: true,
          voiceText: text
        })
      })

      // 识别错误
      this.voiceManager.onError((err) => {
        console.error('[语音识别] 识别错误:', err)
        this.setData({ isRecording: false })
        const errMsg = err.msg || err.errMsg || '未知错误'
        wx.showToast({ title: '识别错误: ' + errMsg, icon: 'none', duration: 2000 })
      })

      wx.showToast({ title: '语音识别已就绪', icon: 'success' })
    } catch (err) {
      console.error('[语音识别] 插件初始化失败:', err)
      wx.showToast({ title: '语音识别功能不可用', icon: 'none', duration: 2000 })
    }
  },

  onShow() {
    this.loadGame()
    this.checkVoiceUsage()

    // 设置TabBar选中状态 - 记分卡页面属于功能页，不高亮任何tab
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: null })
    }
  },

  // 检查语音使用次数，决定"试试说"提示是否显示
  checkVoiceUsage() {
    const voiceStats = wx.getStorageSync('voiceStats') || { count: 0 }
    // 累计有效语音输入超过100次，不再显示提示
    const showVoiceHint = voiceStats.count < 100
    this.setData({ showVoiceHint })
  },

  // 记录一次有效语音输入
  recordVoiceUsage() {
    const voiceStats = wx.getStorageSync('voiceStats') || { count: 0 }
    voiceStats.count++
    wx.setStorageSync('voiceStats', voiceStats)
    // 如果刚超过100次，隐藏提示
    if (voiceStats.count >= 100 && this.data.showVoiceHint) {
      this.setData({ showVoiceHint: false })
    }
  },

  onUnload() {
    // 页面卸载时停止语音播放
    this.stopHoleTip()

    // 停止云端数据监听
    if (this.watcher) {
      this.watcher.close()
      this.watcher = null
    }
  },

  loadCourses() {
    const courses = wx.getStorageSync('courses') || []
    this.setData({ courses })
  },

  loadGame() {
    // 如果是云端多人比赛，从云数据库加载
    if (this.isCloudGame && this.gameId) {
      this.loadCloudGame(this.gameId)
      return
    }

    // 本地比赛从storage加载
    const currentGame = wx.getStorageSync('currentGame')
    if (!currentGame) {
      this.setData({ currentGame: null })
      return
    }

    // 从storage重新读取courses，避免真机加载延迟导致找不到球场
    let courses = this.data.courses
    if (!courses || courses.length === 0) {
      courses = wx.getStorageSync('courses') || []
    }

    const course = courses.find(c => c.id === currentGame.courseId)
    if (!course) {
      this.setData({ currentGame: null })
      return
    }

    const now = new Date()
    const dateStr = `${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日`

    // 获取当前玩法
    const currentMode = GAME_MODES.find(m => m.id === currentGame.gameMode) || GAME_MODES[0]

    // 预计算每个球员的总杆显示（转换为数组，保持与players数组顺序一致）
    const playerTotalList = this.calcPlayerTotalList(currentGame, course.holes)
    // 预计算记分卡网格数据
    const scoreGridData = this.calcScoreGridData(currentGame, course.holes)

    this.setData({
      currentGame,
      holes: course.holes,
      totalHoles: course.holes.length,
      totalPar: course.holes.reduce((sum, h) => sum + h.par, 0),
      currentHoleData: course.holes[0],
      holeTip: this.generateHoleTip(course.holes[0]),
      currentDate: dateStr,
      currentMode,
      playerTotalList,
      scoreGridData
    })

    // 计算领先者
    this.calculateLeader(currentGame, course)

    // 恢复上次记录的洞
    const savedHole = wx.getStorageSync('currentHole')
    if (savedHole && savedHole <= course.holes.length) {
      this.setCurrentHole(savedHole)
    }
  },

  // 从云端加载多人比赛
  loadCloudGame(gameId) {
    wx.showLoading({ title: '加载比赛...' })

    const db = wx.cloud.database()
    db.collection('games').doc(gameId).get().then(res => {
      wx.hideLoading()

      if (!res.data) {
        wx.showToast({ title: '比赛不存在', icon: 'none' })
        setTimeout(() => {
          wx.navigateBack()
        }, 1500)
        return
      }

      const cloudGame = res.data
      console.log('云端比赛加载成功:', cloudGame)

      // 加载球场数据
      let courses = this.data.courses
      if (!courses || courses.length === 0) {
        courses = wx.getStorageSync('courses') || []
      }

      // 查找球场
      let course = courses.find(c => c.id === cloudGame.courseId)
      if (!course) {
        const { CHINA_COURSES } = require('../../data/courses-accurate.js')
        course = CHINA_COURSES.find(c => c.id === cloudGame.courseId)
        if (course && !courses.find(c => c.id === cloudGame.courseId)) {
          courses.push(course)
          wx.setStorageSync('courses', courses)
        }
      }

      if (!course) {
        wx.showToast({ title: '找不到球场数据', icon: 'none' })
        return
      }

      // 补全totalPar
      if (!course.totalPar) {
        course.totalPar = course.holes.reduce((sum, h) => sum + h.par, 0)
      }

      const now = new Date()
      const dateStr = `${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日`

      // 获取当前玩法
      const currentMode = GAME_MODES.find(m => m.id === cloudGame.gameMode) || GAME_MODES[0]

      // 转换云端数据格式为本地格式
      const currentGame = {
        ...cloudGame,
        courseId: cloudGame.courseId,
        gameMode: cloudGame.gameMode || 'stroke',
        players: cloudGame.players || [],
        scores: cloudGame.scores || {},
        putts: cloudGame.putts || {},
        penalties: cloudGame.penalties || {},
        advancedStats: cloudGame.advancedStats || {},
        fairways: cloudGame.fairways || {}
      }

      // 预计算每个球员的总杆显示
      const playerTotalList = this.calcPlayerTotalList(currentGame, course.holes)
      const scoreGridData = this.calcScoreGridData(currentGame, course.holes)

      this.setData({
        currentGame,
        holes: course.holes,
        totalHoles: course.holes.length,
        totalPar: course.totalPar,
        currentHoleData: course.holes[0],
        holeTip: this.generateHoleTip(course.holes[0]),
        currentDate: dateStr,
        currentMode,
        playerTotalList,
        scoreGridData
      })

      // 计算领先者
      this.calculateLeader(currentGame, course)

      // 设置第一个洞
      this.setCurrentHole(1)

      // 设置云端数据监听，实时同步
      this.watchCloudGame(gameId)

      // 添加当前用户到球员列表（如果不在列表中）
      this.addCurrentUserToCloudGameIfNeeded(currentGame)
    }).catch(err => {
      wx.hideLoading()
      console.error('加载云端比赛失败:', err)
      wx.showToast({ title: '加载比赛失败', icon: 'none' })
    })
  },

  // 监听云端比赛数据变化，实时同步
  watchCloudGame(gameId) {
    if (!wx.cloud) return

    const db = wx.cloud.database()

    // 监听比赛文档变化
    this.watcher = db.collection('games').doc(gameId).watch({
      onChange: snapshot => {
        console.log('云端比赛数据更新:', snapshot)
        if (!snapshot.docs || snapshot.docs.length === 0) return

        const updatedGame = snapshot.docs[0]
        this.onCloudGameUpdate(updatedGame)
      },
      onError: err => {
        console.error('云端监听错误:', err)
      }
    })

    console.log('已开始监听云端比赛更新')
  },

  // 云端数据更新，同步到本地
  onCloudGameUpdate(updatedGame) {
    const currentGame = this.data.currentGame
    if (!currentGame) return

    // 更新比赛数据
    const newGame = {
      ...currentGame,
      ...updatedGame,
      scores: updatedGame.scores || {},
      putts: updatedGame.putts || {},
      penalties: updatedGame.penalties || {},
      advancedStats: updatedGame.advancedStats || {},
      fairways: updatedGame.fairways || {}
    }

    // 重新计算网格数据
    const playerTotalList = this.calcPlayerTotalList(newGame, this.data.holes)
    const scoreGridData = this.calcScoreGridData(newGame, this.data.holes)

    this.setData({
      currentGame: newGame,
      playerTotalList,
      scoreGridData
    })

    // 重新计算领先者
    const course = this.data.courses.find(c => c.id === newGame.courseId)
    if (course) {
      this.calculateLeader(newGame, course)
    }

    console.log('已同步云端更新')
  },

  // 如果当前用户不在球员列表中，自动添加
  addCurrentUserToCloudGameIfNeeded(game) {
    const cachedUserInfo = wx.getStorageSync('userInfo')
    if (!cachedUserInfo || !cachedUserInfo.nickName) return

    const hasMe = game.players.some(p => p.openid === cachedUserInfo.openid || p.isMe)
    if (!hasMe) {
      // 添加当前用户到球员列表
      const colors = ['#2c8f4e', '#2196f3', '#ff9800', '#f44336', '#9c27b0', '#00bcd4', '#795548', '#607d8b']
      const colorIndex = game.players.length % colors.length

      const newPlayer = {
        id: 'current-user-cloud',
        name: cachedUserInfo.nickName,
        color: colors[colorIndex],
        avatar: cachedUserInfo.avatarUrl || '',
        openid: cachedUserInfo.openid || '',
        isMe: true
      }

      game.players.push(newPlayer)

      // 更新到云端
      this.updateCloudGame(game)

      // 更新本地
      const playerTotalList = this.calcPlayerTotalList(game, this.data.holes)
      const scoreGridData = this.calcScoreGridData(game, this.data.holes)

      this.setData({
        currentGame: game,
        playerTotalList,
        scoreGridData
      })

      wx.showToast({ title: '已加入比赛', icon: 'success' })
    }
  },

  // 更新比赛数据到云端
  updateCloudGame(game) {
    if (!this.isCloudGame || !this.gameId || !wx.cloud) return

    const db = wx.cloud.database()

    // 只更新需要同步的数据
    const updateData = {
      players: game.players,
      scores: game.scores,
      putts: game.putts,
      penalties: game.penalties,
      advancedStats: game.advancedStats,
      fairways: game.fairways,
      updateTime: db.serverDate()
    }

    db.collection('games').doc(this.gameId).update({
      data: updateData,
      success: () => {
        console.log('云端更新成功')
      },
      fail: err => {
        console.error('云端更新失败:', err)
      }
    })
  },

  // 计算领先者
  calculateLeader(game, course) {
    if (!game || !game.players || game.players.length === 0) return

    const mode = game.gameMode || 'stroke'
    const playerScores = game.players.map(player => {
      const scores = game.scores[player.id] || {}
      const stats = this.getPlayerStats(scores, course)
      return {
        ...player,
        ...stats
      }
    })

    let leader = null

    switch (mode) {
      case 'stroke':
        // 比杆赛：总杆数最少 wins
        playerScores.sort((a, b) => a.totalScore - b.totalScore)
        leader = playerScores[0]
        leader.displayScore = leader.totalScore > 0 ? `${leader.totalScore}杆` : '-'
        break

      case 'match':
        // 比洞赛：计算每洞胜负（考虑让洞）
        const matchResults = this.calculateMatchHoles(game, course)
        playerScores.forEach(p => {
          p.holesWon = matchResults[p.id] || 0
        })
        playerScores.sort((a, b) => b.holesWon - a.holesWon)
        leader = playerScores[0]
        leader.displayScore = leader.holesWon > 0 ? `赢${leader.holesWon}洞` : '-'
        break

      case 'bestball':
        // 最佳球：显示每队最佳成绩
        leader = playerScores[0]
        leader.displayScore = leader.totalScore > 0 ? `${leader.totalScore}杆` : '-'
        break

      case 'landlord':
        // 斗地主：显示当前地主和得分
        leader = playerScores[0]
        leader.displayScore = leader.totalScore > 0 ? `${leader.totalScore}杆` : '-'
        break

      default:
        playerScores.sort((a, b) => a.totalScore - b.totalScore)
        leader = playerScores[0]
        leader.displayScore = leader.totalScore > 0 ? `${leader.totalScore}杆` : '-'
    }

    this.setData({
      leaderInfo: {
        name: leader.name,
        score: leader.displayScore,
        color: leader.color,
        modeName: this.data.currentMode?.name || '比杆赛'
      }
    })
  },

  // 获取球员统计数据
  getPlayerStats(scores, course) {
    let totalScore = 0
    let holesPlayed = 0
    let points = 0
    let holesWon = 0
    let skinsWon = 0

    Object.entries(scores).forEach(([holeNum, score]) => {
      if (score && course) {
        const holeData = course.holes.find(h => h.hole === parseInt(holeNum))
        if (holeData) {
          totalScore += parseInt(score)
          holesPlayed++

          // 计算积分（史特伯福特）
          const diff = score - holeData.par
          if (diff <= -2) points += 8 // 双鹰
          else if (diff === -1) points += 3 // 小鸟
          else if (diff === 0) points += 2 // par
          else if (diff === 1) points += 1 // 柏忌
          // 双柏忌及以上 0 分
        }
      }
    })

    return {
      totalScore,
      holesPlayed,
      points,
      holesWon,
      skinsWon
    }
  },

  // 计算比洞赛每洞胜负（考虑让洞）
  calculateMatchHoles(game, course) {
    if (!game || !game.players || game.players.length < 2) return {}

    const handicaps = game.handicaps || {}
    const results = {}

    // 初始化每位球员的赢洞数
    game.players.forEach(p => results[p.id] = 0)

    // 遍历每一洞
    course.holes.forEach(hole => {
      const holeScores = game.players.map(player => {
        const score = game.scores[player.id]?.[hole.hole]
        const handicap = handicaps[player.id] || 0
        // 计算该洞是否获得让杆：让洞数 >= 洞号时获得让1杆
        const handicapStrokes = handicap >= hole.hole ? 1 : 0
        return {
          playerId: player.id,
          rawScore: score,
          netScore: score ? score - handicapStrokes : null
        }
      }).filter(s => s.netScore !== null)

      if (holeScores.length >= 2) {
        // 找出该洞最低成绩
        const bestScore = Math.min(...holeScores.map(s => s.netScore))
        const winners = holeScores.filter(s => s.netScore === bestScore)

        // 如果有唯一胜者，该球员赢1洞
        if (winners.length === 1) {
          results[winners[0].playerId]++
        }
      }
    })

    return results
  },

  setCurrentHole(hole) {
    const holeData = this.data.holes[hole - 1]
    this.setData({
      currentHole: hole,
      currentHoleData: holeData,
      holeTip: this.generateHoleTip(holeData)
    })
    wx.setStorageSync('currentHole', hole)
  },

  // 生成洞打法建议（基于洞的设计特点和策略）
  generateHoleTip(holeData) {
    if (!holeData) return ''

    const tips = []
    const par = holeData.par
    const distance = holeData.distance
    const handicap = holeData.handicap

    // 根据洞的具体特点给出策略建议
    if (par === 3) {
      // 三杆洞 策略
      if (distance > 180) {
        tips.push('长距离三杆洞，选长杆瞄向果岭前部，宁愿短也别长过果岭')
      } else if (distance < 120) {
        tips.push('短三杆洞机会洞，选择精准的挖起杆，积极进攻打低于标准杆一杆')
      } else {
        tips.push('标准三杆洞，瞄向果岭中心，避开左右沙坑是首要目标')
      }
    } else if (par === 4) {
      // 四杆洞 策略
      if (distance > 400) {
        tips.push('长四杆洞，开球务必上球道，第二杆用中长铁杆留短推机会')
      } else if (distance < 320) {
        tips.push('短四杆洞机会洞，开球选木杆或长铁越过转角，争取直攻果岭')
      } else {
        tips.push('标准四杆洞，开球落点选在球道宽阔处，第二杆留100码左右最舒适')
      }

      // 狗腿洞提示
      if (holeData.dogleg) {
        if (holeData.dogleg === 'left') {
          tips.push('左狗腿球道，球路从左往右打，避开左侧树林/长草')
        } else if (holeData.dogleg === 'right') {
          tips.push('右狗腿球道，球路从右往左打，利用球道右侧空间')
        }
      }
    } else if (par === 5) {
      // 五杆洞 策略
      if (distance > 520) {
        tips.push('长五杆洞，别强求两杆上果岭，开球后稳稳放在球道，第三杆切近保Par')
      } else {
        tips.push('距离适中的五杆洞，第二杆看准落点，两杆上果岭机会大时果断进攻')
      }
    }

    // 障碍应对策略
    if (holeData.hazards) {
      if (holeData.hazards.includes('水')) {
        tips.push('此洞水障碍威胁大，宁愿多打一杆也别下水，保守即胜利')
      } else if (holeData.hazards.includes('沙坑')) {
        tips.push('果岭周边沙坑多，进攻时选择带背旋的落点，避免滚入沙坑')
      } else if (holeData.hazards.includes('OB') || holeData.hazards.includes('出界')) {
        tips.push('两侧OB线，开球瞄准球道中心，宁可短杆救球也别冒险直攻')
      }
    }

    // 难度评级补充
    if (handicap <= 3 && tips.length < 2) {
      tips.push('全场最难洞之一，心态放平，+1也是好成绩')
    } else if (handicap >= 15 && tips.length < 2) {
      tips.push('相对简单的洞，稳定发挥就有机会打低于标准杆一杆')
    }

    return tips.slice(0, 2).join('；') + '。'
  },

  // 获取用户在某洞的历史统计数据
  getHoleUserStats(holeNumber) {
    const currentGame = this.data.currentGame
    if (!currentGame || !currentGame.scores) {
      return { played: 0, totalStrokes: 0, fairwayHits: 0, fairwayAttempts: 0 }
    }

    const stats = {
      played: 0,
      totalStrokes: 0,
      fairwayHits: 0,
      fairwayAttempts: 0
    }

    // 统计所有球员在该洞的数据（作为示例，实际可以只统计当前用户）
    Object.values(currentGame.scores).forEach(playerScores => {
      if (playerScores[holeNumber]) {
        const score = playerScores[holeNumber]
        stats.played++
        stats.totalStrokes += score.strokes || 0
        if (score.fairway !== undefined) {
          stats.fairwayAttempts++
          if (score.fairway === true) {
            stats.fairwayHits++
          }
        }
      }
    })

    return stats
  },

  // 上一洞
  prevHole() {
    if (this.data.currentHole > 1) {
      this.setCurrentHole(this.data.currentHole - 1)
    }
  },

  // 下一洞
  nextHole() {
    if (this.data.currentHole < this.data.totalHoles) {
      this.setCurrentHole(this.data.currentHole + 1)
    }
  },

  // 跳转到指定洞
  jumpToHole(e) {
    const hole = e.currentTarget.dataset.hole
    this.setCurrentHole(hole)
  },

  // 显示玩法选择器
  showModeSelector() {
    this.setData({ showModeSelector: true })
  },

  // 隐藏玩法选择器
  hideModeSelector() {
    this.setData({ showModeSelector: false })
  },

  // 阻止冒泡
  preventHide() {
    // 什么都不做，只是阻止事件冒泡
  },

  // 选择玩法
  selectMode(e) {
    const modeId = e.currentTarget.dataset.mode
    const mode = GAME_MODES.find(m => m.id === modeId)

    // 更新游戏玩法
    const game = this.data.currentGame
    game.gameMode = modeId

    this.setData({
      currentGame: game,
      currentMode: mode,
      showModeSelector: false
    })

    if (!this.isCloudGame) {
      wx.setStorageSync('currentGame', game)
    } else {
      this.updateCloudGame(game)
    }

    // 重新计算领先者
    const course = this.data.courses.find(c => c.id === game.courseId)
    this.calculateLeader(game, course)

    wx.showToast({
      title: `已切换至${mode.name}`,
      icon: 'none'
    })

    // 如果切换到需要设置的玩法，自动打开设置（比洞赛的让洞设置已在弹窗内显示）
    setTimeout(() => {
      if (modeId === 'stroke') {
        this.showHandicapSetup()
      } else if (modeId === 'bestball') {
        this.showTeamSetup()
      } else if (modeId === 'landlord') {
        this.showLandlordSetup()
      }
      // 比洞赛的让洞设置已经在玩法选择弹窗内，不需要再弹出单独弹窗
    }, 500)
  },

  // 显示让洞设置弹窗
  showHandicapSetup() {
    this.setData({
      showHandicapModal: true,
      editingHandicap: {
        playerId: null,
        handicapStrokes: 0
      }
    })
  },

  // 隐藏让洞设置弹窗
  hideHandicapModal() {
    this.setData({ showHandicapModal: false })
  },

  // 设置球员的让洞数
  setPlayerHandicap(e) {
    const playerId = e.currentTarget.dataset.player
    const game = this.data.currentGame

    if (!game.handicaps) game.handicaps = {}

    this.setData({
      editingHandicap: {
        playerId: playerId,
        handicapStrokes: game.handicaps[playerId] || 0
      }
    })
  },

  // 调整让洞数
  adjustHandicap(e) {
    const delta = parseInt(e.currentTarget.dataset.delta)
    const current = this.data.editingHandicap.handicapStrokes || 0
    const newValue = Math.max(0, current + delta)

    this.setData({
      'editingHandicap.handicapStrokes': newValue
    })
  },

  // 调整球员让洞数（弹窗中直接操作）
  adjustPlayerHandicap(e) {
    console.log('adjustPlayerHandicap called', e.currentTarget.dataset)
    const playerId = e.currentTarget.dataset.player
    const delta = parseInt(e.currentTarget.dataset.delta)

    if (!playerId) {
      console.error('playerId is empty')
      return
    }

    const game = this.data.currentGame
    const currentHandicaps = game.handicaps || {}
    const current = currentHandicaps[playerId] || 0
    const newValue = Math.max(0, Math.min(current + delta, 18))

    console.log('Setting handicap:', playerId, 'from', current, 'to', newValue)

    // 创建新的 handicaps 对象以确保响应性
    game.handicaps = {
      ...currentHandicaps,
      [playerId]: newValue
    }

    this.setData({ currentGame: { ...game } })
  },

  // 保存让洞设置
  saveHandicap() {
    const game = this.data.currentGame

    if (!this.isCloudGame) {
      wx.setStorageSync('currentGame', game)
    } else {
      this.updateCloudGame(game)
    }

    wx.showToast({
      title: '让洞设置已保存',
      icon: 'none'
    })

    this.hideHandicapModal()

    // 重新计算领先者
    const course = this.data.courses.find(c => c.id === game.courseId)
    this.calculateLeader(game, course)
  },

  // 获取球员的让洞数/让杆数
  getPlayerHandicap(playerId) {
    return this.data.currentGame?.handicaps?.[playerId] || 0
  },

  // ========== 组队设置（最佳球） ==========
  showTeamSetup() {
    const game = this.data.currentGame
    // 如果没有设置过，默认每人一队
    if (!game.teams) {
      game.teams = {}
      game.players.forEach((p, index) => {
        game.teams[p.id] = Math.floor(index / 2) + 1
      })
      this.setData({ currentGame: game })
      wx.setStorageSync('currentGame', game)
    }
    this.setData({ showTeamModal: true })
  },

  hideTeamModal() {
    this.setData({ showTeamModal: false })
  },

  adjustPlayerTeam(e) {
    const playerId = e.currentTarget.dataset.player
    const delta = parseInt(e.currentTarget.dataset.delta)
    const game = this.data.currentGame
    const currentTeam = game.teams[playerId] || 1
    const newTeam = Math.max(1, currentTeam + delta)

    game.teams[playerId] = newTeam
    this.setData({ currentGame: { ...game } })
    if (!this.isCloudGame) {
      wx.setStorageSync('currentGame', game)
    } else {
      this.updateCloudGame(game)
    }
  },

  saveTeamSetup() {
    const game = this.data.currentGame
    if (this.isCloudGame) {
      this.updateCloudGame(game)
    }
    this.hideTeamModal()
    wx.showToast({ title: '组队设置已保存', icon: 'none' })
  },

  // ========== 地主设置（斗地主） ==========
  showLandlordSetup() {
    const game = this.data.currentGame
    // 如果没有设置过，默认第一个球员
    if (!game.landlordId && game.players.length > 0) {
      game.landlordId = game.players[0].id
      game.currentLandlordId = game.players[0].id
      this.setData({ currentGame: game })
      if (!this.isCloudGame) {
        wx.setStorageSync('currentGame', game)
      } else {
        this.updateCloudGame(game)
      }
    }
    this.setData({ showLandlordModal: true })
  },

  hideLandlordModal() {
    this.setData({ showLandlordModal: false })
  },

  selectLandlordPlayer(e) {
    const playerId = e.currentTarget.dataset.player
    const game = this.data.currentGame
    game.landlordId = playerId
    game.currentLandlordId = playerId
    this.setData({ currentGame: { ...game } })
  },

  saveLandlordSetup() {
    const game = this.data.currentGame
    if (!this.isCloudGame) {
      wx.setStorageSync('currentGame', game)
    } else {
      this.updateCloudGame(game)
    }
    this.hideLandlordModal()
    wx.showToast({ title: '地主设置已保存', icon: 'none' })
  },

  // 获取球员分数
  getScore(playerId) {
    return this.data.currentGame?.scores[playerId]?.[this.data.currentHole]
  },

  // 获取球员推杆数
  getPutts(playerId) {
    return this.data.currentGame?.putts?.[playerId]?.[this.data.currentHole]
  },

  // 获取球员开球上球道记录
  getFairway(playerId) {
    return this.data.currentGame?.fairways?.[playerId]?.[this.data.currentHole]
  },

  // 显示成绩录入弹窗
  showScoreInput(e) {
    const playerId = e.currentTarget.dataset.player
    // 支持从记分卡点击特定洞
    const holeNum = e.currentTarget.dataset.hole
    if (holeNum && holeNum !== this.data.currentHole) {
      this.setCurrentHole(parseInt(holeNum))
    }

    const player = this.data.currentGame.players.find(p => p.id === playerId)
    const currentScore = this.getScore(playerId)
    const currentPutts = this.getPutts(playerId) || 2
    const currentPenalties = this.getPenalties(playerId) || { ob: 0, water: 0, other: 0 }
    const currentAdvanced = this.getAdvancedStats(playerId) || { bunker: 0, bunkerSave: 0, chip: 0, chipIn: 0 }
    const currentFairway = this.getFairway(playerId)

    // 如果没有成绩，默认设为当前洞的标准杆
    const defaultStrokes = currentScore || this.data.currentHoleData.par

    // 检查是否有高级记录数据（罚杆>0或有沙坑/切杆记录）
    const hasAdvancedData = this.checkHasAdvancedData(currentPenalties, currentAdvanced)

    this.setData({
      editingScore: {
        playerId: playerId,
        playerName: player ? player.name : '',
        strokes: defaultStrokes,
        putts: currentPutts,
        penalties: currentPenalties,
        advancedStats: currentAdvanced,
        fairway: currentFairway,
        showCustomInput: false
      },
      showAdvanced: hasAdvancedData
    })
  },

  // 检查是否有高级记录数据
  checkHasAdvancedData(penalties, advancedStats) {
    // 检查罚杆
    if (penalties) {
      if ((penalties.ob || 0) > 0) return true
      if ((penalties.water || 0) > 0) return true
      if ((penalties.other || 0) > 0) return true
    }
    // 检查高级统计
    if (advancedStats) {
      if ((advancedStats.bunker || 0) > 0) return true
      if ((advancedStats.bunkerSave || 0) > 0) return true
      if ((advancedStats.chip || 0) > 0) return true
      if ((advancedStats.chipIn || 0) > 0) return true
    }
    return false
  },

  // 获取球员高级统计数据
  getAdvancedStats(playerId) {
    return this.data.currentGame?.advancedStats?.[playerId]?.[this.data.currentHole]
  },

  // 切换高级记录显示
  toggleAdvanced() {
    this.setData({
      showAdvanced: !this.data.showAdvanced
    })
  },

  // 快速设置杆数（含智能推杆建议）
  setStrokesQuick(e) {
    const value = e.currentTarget.dataset.value
    // 如果是 "custom"，显示自定义输入
    if (value === 'custom') {
      this.setData({
        'editingScore.showCustomInput': true
      })
      return
    }
    const strokes = parseInt(value)
    // 智能推测推杆数
    let suggestedPutts = 2
    if (strokes <= 2) suggestedPutts = 1
    else if (strokes >= this.data.currentHoleData.par + 2) suggestedPutts = 3

    this.setData({
      'editingScore.strokes': strokes,
      'editingScore.putts': suggestedPutts,
      'editingScore.showCustomInput': false
    })
  },

  // 手动输入杆数
  onCustomStrokesInput(e) {
    const value = parseInt(e.detail.value) || this.data.currentHoleData.par
    this.setData({
      'editingScore.strokes': value
    })
  },

  // 添加高级统计
  addAdvancedStat(e) {
    const type = e.currentTarget.dataset.type
    const current = this.data.editingScore.advancedStats?.[type] || 0
    this.setData({
      [`editingScore.advancedStats.${type}`]: current + 1
    })
  },

  // 减少高级统计
  removeAdvancedStat(e) {
    const type = e.currentTarget.dataset.type
    const current = this.data.editingScore.advancedStats?.[type] || 0
    if (current > 0) {
      this.setData({
        [`editingScore.advancedStats.${type}`]: current - 1
      })
    }
  },

  // 切换开球上球道状态
  toggleFairway(e) {
    const value = e.currentTarget.dataset.value === 'true'
    const currentValue = this.data.editingScore.fairway
    // 如果是相同值则取消选择（设为null），否则设置新值
    const newValue = currentValue === value ? null : value
    this.setData({
      'editingScore.fairway': newValue
    })
  },

  // 播放AI打法建议语音
  playHoleTip() {
    const tip = this.data.holeTip
    if (!tip) return

    // 如果正在播放，停止播放
    if (this.data.isPlayingTip) {
      this.stopHoleTip()
      return
    }

    // 使用微信原生InnerAudioContext播放语音
    this.speakWithTTS(tip)
  },

  // 使用微信同声传译插件语音合成播放（官方插件，稳定可靠）
  speakWithTTS(text) {
    this.setData({ isPlayingTip: true })

    // 使用微信官方插件进行语音合成
    plugin.textToSpeech({
      lang: 'zh_CN',
      content: text,
      success: (res) => {
        console.log('TTS合成成功', res)
        // 创建音频播放器播放
        this.innerAudioContext = wx.createInnerAudioContext()
        this.innerAudioContext.src = res.filename
        this.innerAudioContext.play()

        this.innerAudioContext.onEnded(() => {
          this.setData({ isPlayingTip: false })
          this.innerAudioContext.destroy()
          this.innerAudioContext = null
        })

        this.innerAudioContext.onError((err) => {
          console.error('播放失败', err)
          wx.showToast({ title: '播放失败', icon: 'none' })
          this.setData({ isPlayingTip: false })
          this.innerAudioContext.destroy()
          this.innerAudioContext = null
        })
      },
      fail: (err) => {
        console.log('TTS合成失败', err)
        let msg = '语音合成失败'
        if (err && err.errMsg) {
          msg = `语音合成失败: ${err.errMsg}`
        }
        wx.showToast({ title: msg, icon: 'none', duration: 2000 })
        this.setData({ isPlayingTip: false })
      }
    })
  },

  // 停止语音播放
  stopHoleTip() {
    if (this.innerAudioContext) {
      this.innerAudioContext.stop()
      this.innerAudioContext.destroy()
      this.innerAudioContext = null
    }

    this.setData({ isPlayingTip: false })
  },

  // 获取球员罚杆数
  getPenalties(playerId) {
    return this.data.currentGame?.penalties?.[playerId]?.[this.data.currentHole]
  },

  // 获取球员总罚杆数
  getPlayerTotalPenalties(playerId) {
    const penalties = this.data.currentGame.penalties?.[playerId]
    if (!penalties) return 0

    let total = 0
    Object.values(penalties).forEach(p => {
      if (p) {
        total += (p.ob || 0) + (p.water || 0) + (p.other || 0)
      }
    })
    return total
  },

  // 关闭成绩录入弹窗
  hideScoreInput() {
    this.setData({
      editingScore: {
        playerId: null,
        playerName: '',
        strokes: null,
        putts: 2,
        penalties: { ob: 0, water: 0, other: 0 },
        advancedStats: { bunker: 0, bunkerSave: 0, chip: 0, chipIn: 0 }
      },
      showAdvanced: false
    })
  },

  // 添加罚杆
  addPenalty(e) {
    const type = e.currentTarget.dataset.type
    const current = this.data.editingScore.penalties[type] || 0
    this.setData({
      [`editingScore.penalties.${type}`]: current + 1
    })
  },

  // 减少罚杆
  removePenalty(e) {
    const type = e.currentTarget.dataset.type
    const current = this.data.editingScore.penalties[type] || 0
    if (current > 0) {
      this.setData({
        [`editingScore.penalties.${type}`]: current - 1
      })
    }
  },

  // 设置杆数
  setStrokes(e) {
    const strokes = parseInt(e.currentTarget.dataset.value)
    this.setData({
      'editingScore.strokes': strokes,
      // 智能设置推杆数：如果没有设置过，根据成绩智能建议
      'editingScore.putts': this.data.editingScore.putts || (strokes <= 2 ? 1 : 2)
    })
  },

  // +/- 调节杆数
  adjustStrokes(e) {
    const delta = parseInt(e.currentTarget.dataset.delta)
    const current = this.data.editingScore.strokes || this.data.currentHoleData.par
    const newValue = Math.max(1, current + delta)
    this.setData({
      'editingScore.strokes': newValue
    })
  },

  // +/- 调节推杆数
  adjustPutts(e) {
    const delta = parseInt(e.currentTarget.dataset.delta)
    const current = this.data.editingScore.putts || 0
    const newValue = Math.max(0, Math.min(current + delta, 10))
    this.setData({
      'editingScore.putts': newValue
    })
  },

  // 快速设置成绩（预设按钮）
  quickSetScore(e) {
    const strokes = parseInt(e.currentTarget.dataset.strokes)
    const putts = parseInt(e.currentTarget.dataset.putts)
    this.setData({
      'editingScore.strokes': strokes,
      'editingScore.putts': putts
    })
    // 自动确认
    setTimeout(() => this.confirmScore(), 200)
  },

  // 设置推杆数
  setPutts(e) {
    const putts = parseInt(e.currentTarget.dataset.value)
    this.setData({
      'editingScore.putts': putts
    })
  },

  // 确认成绩录入
  confirmScore() {
    const { playerId, strokes, putts, penalties, advancedStats, fairway } = this.data.editingScore
    if (!playerId || !strokes) return

    // 获取最新的游戏数据（避免并发修改）
    let game = this.isCloudGame ? this.data.currentGame : (wx.getStorageSync('currentGame') || this.data.currentGame)
    const currentHole = this.data.currentHole

    // 确保 scores 结构存在
    if (!game.scores) game.scores = {}
    if (!game.scores[playerId]) game.scores[playerId] = {}

    // 更新杆数（总杆数包含罚杆）
    const totalPenalties = (penalties.ob || 0) + (penalties.water || 0) + (penalties.other || 0)
    const actualStrokes = strokes + totalPenalties
    game.scores[playerId][currentHole] = actualStrokes

    // 更新推杆数
    if (!game.putts) game.putts = {}
    if (!game.putts[playerId]) game.putts[playerId] = {}
    game.putts[playerId][currentHole] = putts

    // 更新罚杆记录
    if (!game.penalties) game.penalties = {}
    if (!game.penalties[playerId]) game.penalties[playerId] = {}
    game.penalties[playerId][currentHole] = penalties

    // 更新高级统计记录
    if (!game.advancedStats) game.advancedStats = {}
    if (!game.advancedStats[playerId]) game.advancedStats[playerId] = {}
    game.advancedStats[playerId][currentHole] = advancedStats

    // 更新开球上球道记录
    if (!game.fairways) game.fairways = {}
    if (!game.fairways[playerId]) game.fairways[playerId] = {}
    game.fairways[playerId][currentHole] = fairway

    // 如果是本地比赛，保存到 storage
    if (!this.isCloudGame) {
      wx.setStorageSync('currentGame', game)
    }

    // 重新计算所有球员的总杆显示列表和记分卡网格数据
    const playerTotalList = this.calcPlayerTotalList(game, this.data.holes)
    const scoreGridData = this.calcScoreGridData(game, this.data.holes)

    this.setData({ currentGame: game, playerTotalList, scoreGridData })

    // 更新领先者
    const course = this.data.courses.find(c => c.id === game.courseId)
    this.calculateLeader(game, course)

    this.hideScoreInput()

    // 如果是云端比赛，同步更新到云端
    if (this.isCloudGame) {
      this.updateCloudGame(game)
    }

    // 检查是否所有球员都已完成当前洞，如果是则自动跳到下一洞
    this.checkAndAutoAdvance()
  },

  // 检查是否所有球员都已完成当前洞，如果是则自动跳到下一洞或完成比赛
  checkAndAutoAdvance() {
    const game = this.data.currentGame
    const currentHole = this.data.currentHole
    const players = game.players || []
    const scores = game.scores || {}
    const holes = this.data.holes || []

    // 检查所有球员是否都有当前洞的成绩
    const allPlayersScored = players.every(player => {
      const playerScores = scores[player.id]
      return playerScores && playerScores[currentHole]
    })

    if (!allPlayersScored) return

    // 检查是否所有洞所有球员都已完成
    const allHolesCompleted = holes.every(hole => {
      return players.every(player => {
        const playerScores = scores[player.id]
        return playerScores && playerScores[hole.hole]
      })
    })

    // 如果全部洞都完成，弹出确认框询问是否完成比赛
    if (allHolesCompleted) {
      setTimeout(() => {
        wx.showModal({
          title: '比赛完成',
          content: '所有洞成绩已录入完毕，是否完成比赛并查看报告？',
          confirmText: '查看报告',
          cancelText: '继续编辑',
          success: (res) => {
            if (res.confirm) {
              this.finishGame()
            }
          }
        })
      }, 500)
      return
    }

    // 不是最后一洞，自动跳到下一洞
    if (currentHole < this.data.totalHoles) {
      setTimeout(() => {
        this.setCurrentHole(currentHole + 1)
      }, 300)
    }
  },

  // 获取总推杆数
  getPlayerTotalPutts(playerId) {
    const putts = this.data.currentGame.putts?.[playerId]
    if (!putts) return 0

    let total = 0
    Object.values(putts).forEach(p => {
      if (p) total += parseInt(p)
    })
    return total
  },

  // 获取分数显示
  getScoreDisplay(playerId) {
    const score = this.getScore(playerId)
    const par = this.data.currentHoleData.par
    if (!score) return ''

    const diff = score - par
    if (diff === -2) return '老鹰'
    if (diff === -1) return '小鸟'
    if (diff === 0) return '平标准'
    if (diff === 1) return '+1'
    if (diff === 2) return '+2'
    return diff > 0 ? `+${diff}` : diff.toString()
  },

  // 获取分数样式类
  getScoreClass(playerId) {
    const score = this.getScore(playerId)
    const par = this.data.currentHoleData.par
    if (!score) return ''

    const diff = score - par
    if (diff <= -2) return 'badge-eagle'
    if (diff === -1) return 'badge-birdie'
    if (diff === 0) return 'badge-par'
    if (diff === 1) return 'badge-bogey'
    return 'badge-double'
  },

  // 获取单元格分数样式
  getCellScoreClass(playerId, hole) {
    const score = this.data.currentGame.scores[playerId]?.[hole]
    if (!score) return ''

    const holeData = this.data.holes.find(h => h.hole === hole)
    if (!holeData) return ''

    const diff = score - holeData.par
    if (diff <= -2) return 'eagle'
    if (diff === -1) return 'birdie'
    if (diff === 0) return 'par'
    if (diff === 1) return 'bogey'
    if (diff >= 2) return 'double-bogey'
    return ''
  },

  // 获取单个洞的差点显示（E, +1, -1等）
  getScoreToParDisplay(playerId, hole) {
    const game = this.data.currentGame
    if (!game || !game.scores) return '-'

    const playerScores = game.scores[playerId]
    if (!playerScores) return '-'

    // 使用宽松匹配查找成绩（数字/字符串类型无关）
    const score = playerScores[hole] || playerScores[String(hole)]
    if (!score) return '-'

    const holes = this.data.holes || []
    const holeData = holes.find(h => h.hole == hole || h.holeNumber == hole)
    if (!holeData) return score

    const diff = parseInt(score) - holeData.par
    if (diff === 0) return 'E'
    if (diff > 0) return `+${diff}`
    return `${diff}`
  },

  // 获取单个洞差点的颜色类名
  getScoreToParClass(playerId, hole) {
    const game = this.data.currentGame
    if (!game || !game.scores) return ''

    const playerScores = game.scores[playerId]
    if (!playerScores) return ''

    const score = playerScores[hole] || playerScores[String(hole)]
    if (!score) return ''

    const holes = this.data.holes || []
    const holeData = holes.find(h => h.hole == hole || h.holeNumber == hole)
    if (!holeData) return ''

    const diff = parseInt(score) - holeData.par
    if (diff < 0) return 'to-par-under'
    if (diff > 0) return 'to-par-over'
    return 'to-par-even'
  },

  // 计算记分卡网格数据
  calcScoreGridData(game, holes) {
    if (!game || !game.players || !game.scores || !holes) return []

    return holes.map(hole => {
      const holeScores = game.players.map(player => {
        const playerScores = game.scores[player.id]
        const score = playerScores?.[hole.hole] || playerScores?.[String(hole.hole)]

        if (!score) {
          return {
            playerId: player.id,
            display: '-',
            class: ''
          }
        }

        const diff = parseInt(score) - hole.par
        let display = ''
        let className = ''

        if (diff === 0) {
          display = 'Par'
          className = 'to-par-even'
        } else if (diff > 0) {
          display = `+${diff}`
          className = 'to-par-over'
        } else {
          display = `${diff}`
          className = 'to-par-under'
        }

        return {
          playerId: player.id,
          display,
          class: className
        }
      })

      return {
        hole: hole.hole,
        par: hole.par,
        scores: holeScores
      }
    })
  },

  // 获取球员总分
  getPlayerTotal(playerId) {
    const scores = this.data.currentGame.scores[playerId]
    if (!scores) return '-'

    let total = 0
    let hasScore = false
    Object.values(scores).forEach(score => {
      if (score) {
        total += parseInt(score)
        hasScore = true
      }
    })

    return hasScore ? total : '-'
  },

  // 计算所有球员的总杆显示列表（与players数组顺序一致）
  calcPlayerTotalList(game, holes) {
    if (!game || !game.players || !game.scores) return []

    return game.players.map(player => {
      const playerScores = game.scores[player.id]
      if (!playerScores) {
        return { id: player.id, display: '-', class: '' }
      }

      let total = 0
      let parTotal = 0
      let hasScore = false

      for (const [holeNum, score] of Object.entries(playerScores)) {
        if (score && parseInt(score) > 0) {
          total += parseInt(score)
          hasScore = true
          const hole = holes.find(h => (h.hole == holeNum || h.holeNumber == holeNum))
          if (hole) parTotal += hole.par
        }
      }

      if (!hasScore) {
        return { id: player.id, display: '-', class: '' }
      }

      const toPar = total - parTotal
      const toParStr = toPar === 0 ? 'E' : (toPar > 0 ? `+${toPar}` : toPar)
      let className = ''
      if (toPar < 0) className = 'under'
      else if (toPar > 0) className = 'over'
      else className = 'even'

      return { id: player.id, total: total, diff: toParStr, class: className }
    })
  },

  // 获取总杆数及与标准杆的差值（格式：80(+8) 或 72(E) 或 68(-4)）
  getPlayerTotalWithToPar(playerId) {
    const game = this.data.currentGame
    const holes = this.data.holes

    // 防御性检查
    if (!game) return 'NG'
    if (!game.scores) return 'NS'

    const playerScores = game.scores[playerId]
    if (!playerScores) return 'NP'

    let total = 0
    let parTotal = 0
    let hasScore = false

    for (const [holeNum, score] of Object.entries(playerScores)) {
      if (score && parseInt(score) > 0) {
        total += parseInt(score)
        hasScore = true
        const hole = holes.find(h => (h.hole == holeNum || h.holeNumber == holeNum))
        if (hole) parTotal += hole.par
      }
    }

    if (!hasScore) return '0(E)'

    const toPar = total - parTotal
    const symbol = toPar === 0 ? 'E' : (toPar > 0 ? `+${toPar}` : toPar)
    return `${total}(${symbol})`
  },

  // 获取总分样式
  getTotalClass(playerId) {
    const scores = this.data.currentGame.scores[playerId]
    if (!scores) return ''

    let total = 0
    let holesCompleted = 0
    let parsPlayed = 0

    Object.entries(scores).forEach(([hole, score]) => {
      if (score) {
        total += parseInt(score)
        holesCompleted++
        const holeData = this.data.holes.find(h => h.hole === parseInt(hole))
        if (holeData) parsPlayed += holeData.par
      }
    })

    if (holesCompleted === 0) return ''

    const diff = total - parsPlayed
    if (diff < 0) return 'under'
    if (diff > 0) return 'over'
    return 'even'
  },

  // 输入分数
  onScoreInput(e) {
    const playerId = e.currentTarget.dataset.player
    const value = parseInt(e.detail.value) || null

    this.updateScore(playerId, value)
  },

  // 调整分数
  adjustScore(e) {
    const playerId = e.currentTarget.dataset.player
    const delta = parseInt(e.currentTarget.dataset.delta)

    const currentScore = this.data.currentGame.scores[playerId][this.data.currentHole] || 0
    const newScore = Math.max(1, currentScore + delta)

    this.updateScore(playerId, newScore)
  },

  // 更新分数
  updateScore(playerId, score) {
    const game = this.data.currentGame
    game.scores[playerId][this.data.currentHole] = score

    this.setData({ currentGame: game })

    if (!this.isCloudGame) {
      wx.setStorageSync('currentGame', game)
    } else {
      this.updateCloudGame(game)
    }

    // 更新领先者
    const course = this.data.courses.find(c => c.id === game.courseId)
    this.calculateLeader(game, course)
  },

  // 显示添加选手弹窗
  showAddPlayerModal() {
    this.setData({ showAddPlayer: true })
  },

  // 隐藏添加选手弹窗
  hideAddPlayerModal() {
    this.setData({ showAddPlayer: false })
  },

  // 添加新选手
  addPlayer(e) {
    const name = e.detail.value.name?.trim()
    if (!name) {
      wx.showToast({ title: '请输入姓名', icon: 'none' })
      return
    }

    const game = this.data.currentGame
    const colors = ['#4CAF50', '#2196F3', '#FF9800', '#9C27B0', '#F44336', '#00BCD4', '#795548', '#607D8B']

    const newPlayer = {
      id: 'player_' + Date.now(),
      name: name,
      color: colors[game.players.length % colors.length],
      isCustom: true
    }

    game.players.push(newPlayer)
    game.scores[newPlayer.id] = {}

    this.setData({
      currentGame: game,
      showAddPlayer: false
    })

    if (!this.isCloudGame) {
      wx.setStorageSync('currentGame', game)
    } else {
      this.updateCloudGame(game)
    }

    wx.showToast({
      title: '已添加 ' + name,
      icon: 'success'
    })
  },

  // 从微信通讯录选择好友
  chooseWxContact() {
    wx.chooseContact({
      success: (res) => {
        const name = res.displayName || res.firstName || res.lastName
        if (name) {
          this.addPlayer({ detail: { value: { name: name } } })
        }
      },
      fail: (err) => {
        console.log('选择联系人失败:', err)
      }
    })
  },

  // 完成比赛
  finishGame() {
    console.log('【finishGame】开始完成比赛')

    // 检查当前游戏数据
    const game = this.data.currentGame
    if (!game) {
      console.error('【finishGame】错误: currentGame 为空')
      wx.showToast({ title: '比赛数据错误', icon: 'none' })
      return
    }
    console.log('【finishGame】当前游戏:', game.id, '球员数:', game.players?.length)

    // 先计算获胜者信息
    let winnerInfo = null
    try {
      winnerInfo = this.calculateWinnerForGame()
      console.log('【finishGame】获胜者信息:', winnerInfo)
    } catch (err) {
      console.error('【finishGame】计算获胜者失败:', err)
      console.error('【finishGame】错误堆栈:', err.stack)
    }

    // 构建获胜者显示文本
    let winnerText = ''
    if (winnerInfo && winnerInfo.players && winnerInfo.players.length > 0) {
      const playerNames = winnerInfo.players.map(p => p.name).join('、')
      winnerText = `\n\n🏆 ${winnerInfo.title}\n${playerNames}\n${winnerInfo.players[0]?.score || ''}`
    }

    console.log('【finishGame】准备显示确认弹窗')

    wx.showModal({
      title: '比赛结束',
      content: `本场比赛已结束！${winnerText}\n\n是否查看详细报告？`,
      confirmText: '查看报告',
      cancelText: '留在本页',
      success: (res) => {
        console.log('【finishGame】用户选择:', res.confirm ? '查看报告' : '留在记分卡')
        // 保存获胜者信息到游戏数据
        game.winnerInfo = winnerInfo
        wx.setStorageSync('currentGame', game)

        // 无论选择哪个选项，都完成比赛
        if (res.confirm) {
          // 查看报告 - 完成比赛并跳转
          this.completeGame()
        } else {
          // 留在记分卡 - 完成比赛但留在当前页面
          this.completeGameStay()
        }
      },
      fail: (err) => {
        console.error('【finishGame】showModal 失败:', err)
      }
    })
  },

  // 计算比赛获胜者（用于完成比赛时显示）
  calculateWinnerForGame() {
    const game = this.data.currentGame
    const players = game.players || []
    const mode = game.gameMode || game.mode || 'stroke'
    const holes = this.data.holes || []

    console.log('【calculateWinnerForGame】模式:', mode, '球员数:', players.length)

    if (players.length === 0) return null

    // 计算每个球员的总成绩
    const playersWithTotals = players.map(player => {
      const scores = game.scores?.[player.id] || {}
      let total = 0
      let parTotal = 0
      let hasScore = false

      Object.entries(scores).forEach(([holeNum, score]) => {
        if (score && parseInt(score) > 0) {
          total += parseInt(score)
          hasScore = true
          const hole = holes.find(h => (h.hole == holeNum || h.holeNumber == holeNum))
          if (hole) parTotal += hole.par
        }
      })

      return {
        ...player,
        total: total,
        toPar: total - parTotal,
        hasScore: hasScore
      }
    })

    switch (mode) {
      case 'stroke':
      case 'match':
        // 比杆赛/比洞赛：杆数最少者获胜
        const sortedByScore = [...playersWithTotals].sort((a, b) => (a.total || 0) - (b.total || 0))
        if (sortedByScore.length === 0 || !sortedByScore[0]) return null
        const bestScore = sortedByScore[0].total || 0
        const winners = sortedByScore.filter(p => (p.total || 0) === bestScore)
        const toPar = winners[0]?.toPar || 0
        return {
          title: winners.length > 1 ? '并列冠军' : '冠军',
          players: winners.map(p => ({
            name: p.name,
            color: p.color,
            score: `${p.total}杆 ${toPar > 0 ? '+' : ''}${toPar}`
          })),
          desc: winners.length > 1 ? `${winners.length}位球员并列第一` : '总杆数最少'
        }

      case 'stableford':
        // 史特伯福特：积分最高者获胜
        const sortedByPoints = [...playersWithTotals].sort((a, b) => (b.points || 0) - (a.points || 0))
        if (sortedByPoints.length === 0 || !sortedByPoints[0]) return null
        const bestPoints = sortedByPoints[0].points || 0
        const pointWinners = sortedByPoints.filter(p => (p.points || 0) === bestPoints)
        return {
          title: pointWinners.length > 1 ? '并列冠军' : '冠军',
          players: pointWinners.map(p => ({
            name: p.name,
            color: p.color,
            score: `${p.points || 0}分`
          })),
          desc: '史特伯福特积分制'
        }

      case 'skins':
        const sortedBySkins = [...playersWithTotals].sort((a, b) => (b.skinsWon || 0) - (a.skinsWon || 0))
        if (sortedBySkins.length === 0 || !sortedBySkins[0]) return null
        const bestSkins = sortedBySkins[0].skinsWon || 0
        if (bestSkins > 0) {
          const skinWinners = sortedBySkins.filter(p => (p.skinsWon || 0) === bestSkins)
          return {
            title: skinWinners.length > 1 ? '并列冠军' : '冠军',
            players: skinWinners.map(p => ({
              name: p.name,
              color: p.color,
              score: `赢得${p.skinsWon}洞`
            })),
            desc: 'Skins赛制'
          }
        }
        return null

      default:
        const defaultSorted = [...playersWithTotals].sort((a, b) => (a.total || 0) - (b.total || 0))
        if (defaultSorted.length === 0 || !defaultSorted[0]) return null
        const defaultToPar = defaultSorted[0].toPar || 0
        return {
          title: '最佳成绩',
          players: [defaultSorted[0]].map(p => ({
            name: p.name,
            color: p.color,
            score: `${p.total}杆 ${defaultToPar > 0 ? '+' : ''}${defaultToPar}`
          })),
          desc: '总杆数'
        }
    }
  },

  // 完成比赛并跳转到报告
  completeGame() {
    console.log('【completeGame】开始完成比赛并跳转')
    try {
      const game = this.data.currentGame
      if (!game) {
        console.error('【completeGame】错误: currentGame 为空')
        wx.showToast({ title: '比赛数据错误', icon: 'none' })
        return
      }

      game.completed = true
      game.endTime = Date.now()

      // 计算最终统计
      game.statistics = this.calculateStatistics(game)
      console.log('【completeGame】统计计算完成')

      // 保存到历史记录
      const games = wx.getStorageSync('games') || []
      games.push(game)
      wx.setStorageSync('games', games)
      console.log('【completeGame】比赛已保存到历史记录')

      // ========== 上传到云端数据库，管理员后台可查看 ==========
      if (wx.cloud) {
        const db = wx.cloud.database()
        db.collection('games').add({
          data: {
            ...game,
            createTime: db.serverDate()
          },
          success: res => {
            console.log('【云端上传】比赛数据上传成功', res._id)
          },
          fail: err => {
            console.error('【云端上传】上传失败', err)
          }
        })
      }

      // 更新球场打球次数
      this.updateCoursePlayCount(game.courseId)

      // 清除当前比赛
      wx.removeStorageSync('currentGame')
      wx.removeStorageSync('currentHole')

      wx.showToast({
        title: '比赛完成！',
        icon: 'success',
        duration: 1500
      })

      // 生成海报并跳转到报告页面
      setTimeout(() => {
        this.generateAndShare(game)
      }, 1500)
    } catch (err) {
      console.error('【completeGame】错误:', err)
      console.error('【completeGame】错误堆栈:', err.stack)
      wx.showToast({ title: '完成比赛失败', icon: 'none' })
    }
  },

  // 完成比赛但留在当前页面
  completeGameStay() {
    console.log('【completeGameStay】开始完成比赛并停留')
    try {
      const game = this.data.currentGame
      if (!game) {
        console.error('【completeGameStay】错误: currentGame 为空')
        wx.showToast({ title: '比赛数据错误', icon: 'none' })
        return
      }

      game.completed = true
      game.endTime = Date.now()

      // 计算最终统计
      game.statistics = this.calculateStatistics(game)
      console.log('【completeGameStay】统计计算完成')

      // 保存到历史记录
      const games = wx.getStorageSync('games') || []
      games.push(game)
      wx.setStorageSync('games', games)
      wx.setStorageSync('currentGame', game) // 保留当前比赛以便查看
      console.log('【completeGameStay】比赛已保存到历史记录')

      // ========== 上传到云端数据库，管理员后台可查看 ==========
      if (wx.cloud) {
        const db = wx.cloud.database()
        db.collection('games').add({
          data: {
            ...game,
            createTime: db.serverDate()
          },
          success: res => {
            console.log('【云端上传】比赛数据上传成功', res._id)
          },
          fail: err => {
            console.error('【云端上传】上传失败', err)
          }
        })
      }

      // 更新球场打球次数
      this.updateCoursePlayCount(game.courseId)

      wx.showToast({
        title: '比赛已完成',
        icon: 'success',
        duration: 1500
      })

      // 更新页面状态，显示比赛已完成
      this.setData({ currentGame: game })
      console.log('【completeGameStay】完成')
    } catch (err) {
      console.error('【completeGameStay】错误:', err)
      console.error('【completeGameStay】错误堆栈:', err.stack)
      wx.showToast({ title: '完成比赛失败', icon: 'none' })
    }
  },

  // 更新球场打球次数
  updateCoursePlayCount(courseId) {
    if (!courseId) return

    const coursePlayCounts = wx.getStorageSync('coursePlayCounts') || {}
    coursePlayCounts[courseId] = (coursePlayCounts[courseId] || 0) + 1
    wx.setStorageSync('coursePlayCounts', coursePlayCounts)

    console.log(`【球场统计】${courseId} 打球次数 +1，当前: ${coursePlayCounts[courseId]}`)
  },

  // 生成海报并分享
  async generateAndShare(game) {
    wx.showLoading({ title: '生成海报...' })

    try {
      // 获取用户偏好的海报风格
      const preferredStyle = preferenceManager.getPreference('posterStyle', 'pro')
      const player = game.players[0] || { name: '球员', color: '#2c8f4e' }

      // 生成海报
      const posterUrl = await posterGenerator.generatePoster({
        type: preferredStyle,
        game,
        player,
        context: this
      })

      wx.hideLoading()

      // 跳转到报告页面，并带上海报地址
      wx.navigateTo({
        url: `/pages/game-report/game-report?gameId=${game.id}`,
        success: (res) => {
          res.eventChannel.emit('reportData', {
            game: game,
            report: analysisReport.generateGameReport(game),
            posterUrl: posterUrl,
            autoShowPoster: true
          })
        }
      })
    } catch (err) {
      console.error('生成海报失败:', err)
      wx.hideLoading()

      // 生成失败也跳转到报告页面
      wx.navigateTo({
        url: `/pages/game-report/game-report?gameId=${game.id}`,
        success: (res) => {
          res.eventChannel.emit('reportData', {
            game: game,
            report: analysisReport.generateGameReport(game)
          })
        }
      })
    }
  },

  calculateStatistics(game) {
    const stats = {}

    // 防御性检查
    if (!game || !game.players) {
      console.log('【calculateStatistics】游戏数据不完整')
      return stats
    }

    // 安全获取球场数据
    const courses = this.data.courses || []
    const course = courses.find(c => c.id === game.courseId)
    if (!course) {
      console.log('【calculateStatistics】未找到球场数据:', game.courseId)
    }

    game.players.forEach(player => {
      const scores = game.scores?.[player.id] || {}
      const playerStats = {
        totalScore: 0,
        totalPar: 0,
        holesPlayed: 0,
        pars: 0,
        birdies: 0,
        eagles: 0,
        bogeys: 0,
        doubleBogeys: 0,
        others: 0
      }

      Object.entries(scores).forEach(([holeNum, score]) => {
        if (score) {
          const holeData = course?.holes?.find(h => h.hole === parseInt(holeNum))
          const par = holeData?.par || 4 // 默认par 4

          playerStats.totalScore += parseInt(score) || 0
          playerStats.totalPar += par
          playerStats.holesPlayed++

          const diff = parseInt(score) - par
          if (diff <= -2) playerStats.eagles++
          else if (diff === -1) playerStats.birdies++
          else if (diff === 0) playerStats.pars++
          else if (diff === 1) playerStats.bogeys++
          else if (diff === 2) playerStats.doubleBogeys++
          else playerStats.others++
        }
      })

      playerStats.toPar = playerStats.totalScore - playerStats.totalPar
      stats[player.id] = playerStats
    })

    return stats
  },

  // ========== 语音输入功能 - 按住录音松开识别 ==========

  // 按下开始录音识别（微信同声传译插件官方方式）
  startVoiceInput() {
    // 如果已经在录音中，先停止，避免卡住
    if (this.data.isRecording) {
      console.log('[语音识别] 已在识别中，重置状态')
      if (this.voiceManager) {
        this.voiceManager.stop()
      }
      this.setData({ isRecording: false })
      return
    }

    // 先设置状态，解决权限弹窗导致touchend无法触发的问题
    this.setData({
      isRecording: true,
      voiceText: ''
      // 💡 不在这里显示弹窗，识别完成再显示 - 体验和微信发语音一致
    })

    // 微信同声传译插件内部处理录音和权限
    console.log('[语音识别] 开始识别')
    this.voiceManager.start({
      duration: 60000, // 最长60秒
      lang: 'zh_CN'   // 中文识别
    })

    // 震动反馈
    if (wx.getStorageSync('appSettings')?.vibration !== false) {
      wx.vibrateShort()
    }
  },

  // 松开停止录音识别
  stopVoiceInput() {
    console.log('[语音识别] 松开手指，停止识别')
    if (!this.data.isRecording) {
      console.log('[语音识别] isRecording=false，不需要停止')
      return
    }
    this.setData({ isRecording: false })
    if (this.voiceManager) {
      this.voiceManager.stop()
    }
    // 震动反馈
    if (wx.getStorageSync('appSettings')?.vibration !== false) {
      wx.vibrateShort()
    }
  },

  // 隐藏语音弹窗
  hideVoiceModal() {
    this.setData({ showVoiceModal: false })
  },

  // 阻止冒泡
  preventHide() {
    // 空函数，防止点击内容区关闭弹窗
  },

  // 编辑识别文本
  onVoiceTextInput(e) {
    this.setData({ voiceText: e.detail.value })
  },

  // 重新录音
  retryVoiceRecognition() {
    this.setData({ voiceText: '' })
    this.startVoiceInput()
  },

  // 确认识别结果
  confirmVoiceRecognition() {
    const text = this.data.voiceText.trim()
    if (!text) {
      wx.showToast({ title: '请说话录入内容', icon: 'none' })
      return
    }

    // 解析文本
    const parsed = voiceRecognition.parseVoiceInput(
      text,
      this.data.currentHole,
      this.data.currentHoleData.par
    )

    this.setData({ showVoiceModal: false })
    this.handleVoiceResult(text, parsed)
  },

  handleVoiceResult(text, parsed) {
    console.log('语音识别结果:', text, parsed)

    let voiceResult = '未能识别，请重试'
    if (parsed.isValid) {
      if (parsed.strokes >= 1 && parsed.strokes <= 20) {
        voiceResult = `识别: 第${parsed.hole}洞, ${parsed.strokes}杆`
      } else {
        voiceResult = `识别: 跳转第${parsed.hole}洞`
      }
    }

    this.setData({
      showVoiceToast: true,
      voiceText: text,
      voiceResult: voiceResult
    })

    // 3秒后隐藏提示
    setTimeout(() => {
      this.setData({ showVoiceToast: false })
    }, 3000)

    if (parsed.isValid) {
      // 记录有效语音输入
      this.recordVoiceUsage()

      // 自动填充成绩
      const playerId = this.data.currentGame.players[0]?.id
      if (playerId) {
        this.setCurrentHole(result.hole)
        // 只有当杆数合法才更新成绩，否则只跳转
        if (result.strokes >= 1 && result.strokes <= 20) {
          this.updateScore(playerId, result.strokes)
          wx.showToast({
            title: `已记录第${result.hole}洞 ${result.strokes}杆`,
            icon: 'success'
          })
        } else {
          wx.showToast({
            title: `已跳转第${result.hole}洞`,
            icon: 'none'
          })
        }
      }
    }
  },

  // ========== 智能分析报告 ==========
  generateAnalysisReport() {
    const historyGames = wx.getStorageSync('games') || []
    const report = analysisReport.generateGameReport(this.data.currentGame, historyGames)

    wx.navigateTo({
      url: '/pages/game-report/game-report',
      success: (res) => {
        res.eventChannel.emit('reportData', { report, game: this.data.currentGame })
      }
    })
  },

  // ========== OCR拍计分卡 ==========

  // 开始OCR校对 - 拍照选择图片
  startOcrVerify() {
    const currentGame = this.data.currentGame
    if (!currentGame || !currentGame.courseId) {
      wx.showToast({ title: '比赛数据异常', icon: 'none' })
      return
    }

    // 保存原始洞数据
    const originalHoles = currentGame.holes || []
    const originalTotalPar = originalHoles.reduce((sum, h) => sum + h.par, 0)

    this.setData({
      originalHoles,
      originalTotalPar
    })

    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['camera', 'album'],
      camera: 'back',
      success: (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath
        wx.showLoading({ title: '识别中...' })
        this.recognizeScorecard(tempFilePath)
      },
      fail: () => {
        wx.showToast({ title: '取消选择', icon: 'none' })
      }
    })
  },

  // 识别计分卡图片
  recognizeScorecard(imagePath) {
    // 临时提示：需要开通微信OCR插件
    wx.hideLoading()
    wx.showModal({
      title: 'OCR功能说明',
      content: 'OCR识别需要开通微信公众平台OCR插件。开通后删除临时代码即可使用。当前请对比差异后手动确认。',
      showCancel: false,
      confirmText: '知道了'
    })

    // 开通OCR插件后取消注释下面代码启用功能
    /*
    try {
      const ocr = new OCRPlugin()

      ocr.recognize({
        type: 0, // 通用印刷体识别
        image: imagePath,
        success: (res) => {
          wx.hideLoading()
          const ocrText = res.words_result.map(item => item.word).join('\n')
          const courseData = this.parseOcrText(ocrText)

          if (courseData.holes.length > 0) {
            // 对比数据差异
            this.compareData(courseData.holes)
          } else {
            wx.showModal({
              title: '识别失败',
              content: '未能识别出有效的计分卡数据，请确保图片清晰并包含完整的18洞标准杆信息',
              showCancel: false
            })
          }
        },
        fail: (err) => {
          wx.hideLoading()
          wx.showToast({ title: '识别失败: ' + err.errMsg, icon: 'none' })
        }
      })
    } catch (e) {
      wx.hideLoading()
      wx.showToast({ title: 'OCR插件初始化失败', icon: 'none' })
      console.error('OCR error:', e)
    }
    */
  },

  // 解析OCR文本提取洞数据（简化版，只提取标准杆）
  parseOcrText(ocrText) {
    // TODO: 实现更完善的解析逻辑
    const lines = ocrText.split('\n')
    const numbers = lines.flatMap(line => {
      const matches = line.match(/\d+/g) || []
      return matches.map(Number).filter(n => n >= 1 && n <= 18)
    })

    // 假设每两个连续数字是 [洞号, par]
    const holes = []
    for (let i = 0; i < Math.min(18, numbers.length); i += 2) {
      const id = numbers[i]
      const par = numbers[i + 1]
      if (id && par && par >= 2 && par <= 6) {
        holes.push({ id, par })
      }
    }

    // 如果只识别出18个数字，按顺序分配给1-18洞
    if (holes.length === 0 && numbers.length === 18) {
      numbers.forEach((par, index) => {
        if (par >= 2 && par <= 6) {
          holes.push({ id: index + 1, par })
        }
      })
    }

    return { holes }
  },

  // 对比数据差异
  compareData(ocrHoles) {
    const originalHoles = this.data.originalHoles
    let hasDiff = false

    // 补齐到18洞
    const fullOcrHoles = []
    for (let i = 1; i <= 18; i++) {
      const match = ocrHoles.find(h => h.id === i)
      if (match) {
        fullOcrHoles.push(match)
        const original = originalHoles[i - 1]
        if (original && original.par !== match.par) {
          hasDiff = true
        }
      } else if (originalHoles[i - 1]) {
        fullOcrHoles.push({ id: i, par: originalHoles[i - 1].par })
      }
    }

    const ocrTotalPar = fullOcrHoles.reduce((sum, h) => sum + h.par, 0)

    // 检查是否有已记录成绩会被覆盖
    let hasScoreDiff = false
    const currentGame = this.data.currentGame
    if (currentGame && currentGame.scores) {
      // 如果已经有成绩记录，说明这是已开始的比赛，需要提示覆盖
      const hasAnyScores = Object.keys(currentGame.scores).some(playerId =>
        Object.keys(currentGame.scores[playerId] || {}).length > 0
      )
      if (hasAnyScores && hasDiff) {
        hasScoreDiff = true
      }
    }

    this.setData({
      ocrHoles: fullOcrHoles,
      ocrTotalPar,
      hasDiff,
      hasScoreDiff,
      showOcrVerifyModal: true
    })
  },

  // 关闭弹窗
  hideOcrVerifyModal() {
    this.setData({ showOcrVerifyModal: false })
  },

  // 阻止冒泡
  preventHide() {
    // 空方法，阻止弹窗内容区点击关闭弹窗
  },

  // 确认替换数据
  confirmReplaceData() {
    const currentGame = this.data.currentGame
    const ocrHoles = this.data.ocrHoles

    // 更新球场洞数据
    const updatedGame = {
      ...currentGame,
      holes: ocrHoles
    }

    // 重新计算总分
    updatedGame.totalPar = ocrHoles.reduce((sum, h) => sum + h.par, 0)

    // 保存更新
    this.setData({
      currentGame: updatedGame
    })

    // 重新计算网格数据并保存到存储
    this.updateScoreGrid()
    this.saveGame()

    wx.showToast({
      title: '数据已更新',
      icon: 'success'
    })

    this.hideOcrVerifyModal()
  },

  // 更新记分卡网格数据
  updateScoreGrid() {
    const game = this.data.currentGame
    const playerTotalList = this.calcPlayerTotalList(game, this.data.holes)
    const scoreGridData = this.calcScoreGridData(game, this.data.holes)
    this.setData({
      playerTotalList,
      scoreGridData
    })
  },

  // 保存游戏数据
  saveGame() {
    const game = this.data.currentGame
    if (!this.isCloudGame) {
      wx.setStorageSync('currentGame', game)
    } else {
      this.updateCloudGame(game)
    }
  },

  // 拦截左上角返回按钮，直接返回首页
  onBackPress() {
    wx.switchTab({ url: '/pages/index/index' })
    return true
  }
})
