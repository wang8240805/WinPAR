const app = getApp()
// 使用准确数据（374个球场，正确Par分布）
const { CHINA_COURSES } = require('../../data/courses-accurate.js')
const { calculateDistance } = require('../../utils/geo-utils.js')

// 开发模式开关
const DEV_MODE = false

Page({
  data: {
    courses: [],
    filteredCourses: [],
    favoriteCourseIds: [],
    searchKeyword: '',
    showFavoritesOnly: false,
    sortBy: 'playCount', // 'playCount' | 'name' | 'distance'
    showDetailModal: false,
    detailCourse: { holes: [] },
    userCity: '', // 用户所在城市
    userLocation: null
  },

  onLoad() {
    wx.setNavigationBarTitle({ title: '全部球场' })
    // 先初始化默认空数组，再加载数据
    this.setData({ favoriteCourseIds: [] }, () => {
      this.loadUserData()
      this.getUserLocation()
    })
  },

  onShow() {
    this.loadUserData()
    this.loadCourses()
  },

  // 获取用户位置
  getUserLocation() {
    // 开发模式：使用模拟位置
    if (DEV_MODE) {
      this.setData({
        userLocation: { latitude: 39.90, longitude: 116.40 }
      }, () => {
        this.loadCourses()
      })
      return
    }

    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        const location = {
          latitude: res.latitude,
          longitude: res.longitude
        }
        this.setData({ userLocation: location })

        // 使用逆地理编码获取城市名称
        this.getCityFromLocation(location)
      },
      fail: () => {
        // 获取位置失败，继续加载所有球场
        this.loadCourses()
      }
    })
  },

  // 根据坐标获取城市（简化版，使用内置数据匹配）
  getCityFromLocation(location) {
    // 找到最近的球场，以其城市为准
    let nearestCourse = null
    let minDistance = Infinity

    CHINA_COURSES.forEach(course => {
      const distance = this.calculateDistance(
        location.latitude, location.longitude,
        course.latitude, course.longitude
      )
      if (distance < minDistance) {
        minDistance = distance
        nearestCourse = course
      }
    })

    const userCity = nearestCourse ? nearestCourse.province : '北京'
    this.setData({ userCity }, () => {
      this.loadCourses()
    })
  },

  // 加载用户数据
  loadUserData() {
    const favoriteIds = wx.getStorageSync('favoriteCourseIds') || []
    this.setData({ favoriteCourseIds: favoriteIds })
  },

  // 加载球场数据（显示所有球场，不限制城市）
  loadCourses() {
    console.log('加载全部球场')
    const cityCourses = CHINA_COURSES
    console.log('球场总数:', cityCourses.length)

    const games = wx.getStorageSync('games') || []
    const { favoriteCourseIds } = this.data

    // 确保 favoriteCourseIds 是数组
    const safeFavoriteIds = Array.isArray(favoriteCourseIds) ? favoriteCourseIds : []

    // 统计每个球场的打球次数
    const playCountMap = {}
    games.forEach(game => {
      if (game.courseId) {
        playCountMap[game.courseId] = (playCountMap[game.courseId] || 0) + 1
      }
    })

    // 计算总距离并添加打球次数和收藏状态
    const coursesWithStats = cityCourses.map(course => {
      // 跳过没有 holes 数据的球场
      if (!course || !course.holes || !Array.isArray(course.holes)) {
        console.warn('球场数据不完整:', course?.name || '未知')
        return null
      }
      const totalDistance = course.holes.reduce((sum, h) => sum + (h.distance || 0), 0)
      return {
        ...course,
        totalPar: course.holes.reduce((sum, h) => sum + h.par, 0),
        totalDistance,
        playCount: playCountMap[course.id] || 0,
        isFavorite: course.id ? safeFavoriteIds.includes(course.id) : false,
        isCustom: course.id ? (!course.id.startsWith('china-') && !course.id.startsWith('scraped-')) : false
      }
    }).filter(c => c !== null) // 过滤掉无效数据

    console.log('处理后的球场数据:', coursesWithStats.length, '个球场')

    this.setData({ courses: coursesWithStats }, () => {
      this.applyFilters()
    })
  },

  // 搜索输入
  onSearchInput(e) {
    this.setData({ searchKeyword: e.detail.value }, () => {
      this.applyFilters()
    })
  },

  // 清除搜索
  clearSearch() {
    this.setData({ searchKeyword: '' }, () => {
      this.applyFilters()
    })
  },

  // 切换只显示收藏
  toggleFavoritesOnly() {
    this.setData({ showFavoritesOnly: !this.data.showFavoritesOnly }, () => {
      this.applyFilters()
    })
  },

  // 切换排序方式
  toggleSortBy() {
    const sortOptions = ['playCount', 'name', 'distance']
    const currentIndex = sortOptions.indexOf(this.data.sortBy)
    const nextSortBy = sortOptions[(currentIndex + 1) % sortOptions.length]
    this.setData({ sortBy: nextSortBy }, () => {
      this.applyFilters()
    })
  },

  // 应用筛选和排序
  applyFilters() {
    const { courses, searchKeyword, showFavoritesOnly, sortBy } = this.data

    // 确保 courses 是数组
    if (!Array.isArray(courses)) {
      this.setData({ filteredCourses: [] })
      return
    }

    let result = [...courses]

    // 1. 按收藏筛选
    if (showFavoritesOnly) {
      result = result.filter(c => c.isFavorite)
    }

    // 2. 按搜索关键词筛选
    if (searchKeyword.trim()) {
      const keyword = searchKeyword.toLowerCase()
      result = result.filter(c =>
        c.name.toLowerCase().includes(keyword) ||
        (c.location && c.location.toLowerCase().includes(keyword)) ||
        (c.city && c.city.toLowerCase().includes(keyword))
      )
    }

    // 3. 排序
    switch (sortBy) {
      case 'playCount':
        result.sort((a, b) => b.playCount - a.playCount)
        break
      case 'name':
        result.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN'))
        break
      case 'distance':
        result.sort((a, b) => (b.totalDistance || 0) - (a.totalDistance || 0))
        break
    }

    this.setData({ filteredCourses: result })
  },

  // 切换收藏状态
  toggleFavorite(e) {
    const courseId = e.currentTarget.dataset.courseId
    let favoriteIds = this.data.favoriteCourseIds || []

    if (favoriteIds.includes(courseId)) {
      // 取消收藏
      favoriteIds = favoriteIds.filter(id => id !== courseId)
      wx.showToast({ title: '已取消收藏', icon: 'success' })
    } else {
      // 添加收藏
      favoriteIds.push(courseId)
      wx.showToast({ title: '收藏成功', icon: 'success' })
    }

    // 保存到本地存储
    wx.setStorageSync('favoriteCourseIds', favoriteIds)
    this.setData({ favoriteCourseIds: favoriteIds }, () => {
      this.loadCourses()
    })
  },

  // 查看球场详情
  viewCourseDetail(e) {
    const course = e.currentTarget.dataset.course
    this.setData({
      showDetailModal: true,
      detailCourse: course
    })
  },

  // 关闭详情弹窗
  closeDetailModal() {
    this.setData({ showDetailModal: false })
  },

  preventHide() {
    // 阻止冒泡
  }
})
