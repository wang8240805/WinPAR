const plugin = requirePlugin('WechatSI')

Page({
  data: {
    content: '',
    contact: '',
    showThanks: false,
    isRecording: false,
    recorderManager: null
  },

  onLoad() {
    // 初始化录音管理器
    this.recorderManager = wx.getRecorderManager()

    // 监听录音结束事件
    this.recorderManager.onStop((res) => {
      console.log('录音结束', res)
      this.handleVoiceToText(res.tempFilePath)
    })

    // 监听录音错误事件
    this.recorderManager.onError((err) => {
      console.error('录音错误', err)
      this.setData({ isRecording: false })
      wx.showToast({ title: '录音失败，请重试', icon: 'none' })
    })
  },

  onShow() {
    // 设置TabBar选中状态 - 反馈页面属于"我的"模块
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 2 })
    }
  },

  // 长按输入框开始录音
  startRecordingLongPress() {
    this.startRecording()
  },

  // 输入反馈内容
  onContentInput(e) {
    this.setData({
      content: e.detail.value
    })
  },

  // 输入联系方式
  onContactInput(e) {
    this.setData({
      contact: e.detail.value
    })
  },

  // 获取手机号
  getPhoneNumber(e) {
    if (e.detail.errMsg === 'getPhoneNumber:ok') {
      // 使用云开发解密手机号
      if (wx.cloud) {
        wx.showLoading({ title: '获取中...' })
        wx.cloud.callFunction({
          name: 'getPhoneNumber',
          data: {
            cloudID: e.detail.cloudID
          },
          success: (res) => {
            wx.hideLoading()
            // 解密得到手机号明文
            if (res.result && res.result.phoneNumber) {
              this.setData({ contact: res.result.phoneNumber })
              wx.showToast({
                title: '获取成功',
                icon: 'success'
              })
            } else {
              wx.showToast({
                title: '解密失败，请手动输入',
                icon: 'none'
              })
            }
          },
          fail: (err) => {
            wx.hideLoading()
            console.error('解密手机号失败', err)
            wx.showToast({
              title: '解密失败，请手动输入',
              icon: 'none'
            })
          }
        })
      } else {
        // 未开云开发，只提示
        wx.showToast({
          title: '已获取授权，请手动输入手机号',
          icon: 'success'
        })
      }
    } else {
      wx.showToast({
        title: '获取失败',
        icon: 'none'
      })
    }
  },

  // 开始录音
  startRecording() {
    // 先设置录音状态，解决权限弹窗导致touchend无法触发停止的问题
    this.setData({ isRecording: true })

    // 再申请录音权限
    wx.authorize({
      scope: 'scope.record',
      success: () => {
        console.log('录音权限申请成功')

        // 开始录音
        this.recorderManager.start({
          duration: 60000, // 最长录音1分钟
          sampleRate: 16000,
          numberOfChannels: 1,
          encodeBitRate: 48000,
          format: 'mp3'
        })

        // 震动反馈
        if (wx.getStorageSync('appSettings')?.vibration !== false) {
          wx.vibrateShort()
        }
      },
      fail: () => {
        this.setData({ isRecording: false })
        wx.showModal({
          title: '需要录音权限',
          content: '请在设置中开启录音权限，以使用语音输入功能',
          showCancel: false
        })
      }
    })
  },

  // 结束录音
  stopRecording() {
    if (!this.data.isRecording) return

    this.setData({ isRecording: false })
    this.recorderManager.stop()

    // 震动反馈
    if (wx.getStorageSync('appSettings')?.vibration !== false) {
      wx.vibrateShort()
    }

    wx.showLoading({ title: '识别中...' })
  },

  // 语音转文字处理 - 使用微信同声传译官方插件
  handleVoiceToText(filePath) {
    plugin.speechRecognize({
      lang: 'zh_CN',
      filePath: filePath,
      success: (res) => {
        wx.hideLoading()
        if (res.result && res.result.trim()) {
          this.setData({
            content: this.data.content + res.result
          })
          wx.showToast({ title: '识别成功', icon: 'success' })
        } else {
          wx.showToast({ title: '未识别到有效内容', icon: 'none' })
        }
      },
      fail: (err) => {
        wx.hideLoading()
        console.error('语音识别失败', err)
        wx.showToast({ title: '识别失败，请重试', icon: 'none' })
      }
    })
  },

  // 提交反馈
  submitFeedback() {
    const { content, contact } = this.data

    if (!content || content.length < 5) {
      wx.showToast({ title: '请输入至少5个字符', icon: 'none' })
      return
    }

    // 收集反馈数据
    const feedback = {
      content: content,
      contact: contact,
      timestamp: new Date().getTime(),
      userInfo: wx.getStorageSync('userInfo') || null
    }

    // 保存到本地存储
    const feedbacks = wx.getStorageSync('feedbacks') || []
    feedbacks.push(feedback)
    wx.setStorageSync('feedbacks', feedbacks)

    console.log('用户反馈：', feedback)

    // ========== 上传到云端数据库，管理员后台可查看 ==========
    if (wx.cloud) {
      const db = wx.cloud.database()
      db.collection('feedback').add({
        data: {
          ...feedback,
          createTime: db.serverDate()
        },
        success: res => {
          console.log('【云端上传】反馈上传成功', res._id)
        },
        fail: err => {
          console.error('【云端上传】上传失败', err)
        }
      })
    }

    // 显示感谢提示
    this.setData({ showThanks: true })

    wx.showToast({
      title: '提交成功',
      icon: 'success',
      success: () => {
        setTimeout(() => {
          wx.navigateBack()
        }, 2000)
      }
    })
  }
})
