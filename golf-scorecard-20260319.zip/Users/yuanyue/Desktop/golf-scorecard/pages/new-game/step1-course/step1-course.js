// 使用准确数据（374个球场，正确Par分布）
const { CHINA_COURSES } = require('../../../data/courses-accurate.js')
const { calculateDistance, formatDistance } = require('../../../utils/geo-utils.js')

// 开发模式开关
const DEV_MODE = false

Page({
  data: {
    userLocation: null,
    recommendedCourse: null,
    nearbyCourses: [],
    displayCourses: [], // 经过筛选/排序后显示的球场列表
    nearbyCoursesDisplay: [], // 附近球场列表（只显示前10个）
    selectedCourseId: '',
    markers: [],
    weather: null,
    weatherEffect: '',
    // 搜索和筛选
    searchKeyword: '',
    showFavoritesOnly: false,
    sortBy: 'distance', // 'distance' | 'playCount'
    // 收藏功能
    favoriteCourseIds: [],
    // 打球次数统计
    coursePlayCounts: {},
    // 数据纠错相关
    showDataModal: false,
    selectedCourseForReport: {},
    errorTypeIndex: -1,
    errorTypes: ['标准杆错误', '距离错误', '洞数错误', '球场位置错误', '其他'],
    correctValue: '',
    // 洞明细弹窗
    showHolesModal: false,
    selectedCourse: { holes: [] },
    totalPar: 72,
    // OCR校对弹窗
    showOcrVerifyModal: false,
    originalHoles: [],
    originalTotalPar: 0,
    ocrHoles: [],
    ocrTotalPar: 0,
    hasDiff: false
  },

  onLoad() {
    // 加载用户收藏和打球次数
    this.loadUserData()
    this.loadCourses()
    this.getUserLocation()
  },

  // 加载用户数据（收藏、打球次数）
  loadUserData() {
    const favoriteCourseIds = wx.getStorageSync('favoriteCourseIds') || []
    const coursePlayCounts = wx.getStorageSync('coursePlayCounts') || {}
    this.setData({
      favoriteCourseIds,
      coursePlayCounts
    })
  },

  onShow() {
    // step1-course 不是 TabBar 页面，不需要设置 selected
    // 保持 TabBar 上次的选中状态
  },

  // 获取球场图片URL - 使用本地默认图片（避免外部URL防盗链问题）
  getCourseImage(courseName) {
    // 统一使用本地默认图片，避免Unsplash防盗链导致404
    return '/images/default-course.jpg'
  },

  // 获取用户位置
  getUserLocation() {
    if (DEV_MODE) {
      const MOCK_LOCATION = { latitude: 39.90, longitude: 116.40 }
      this.setData({ userLocation: MOCK_LOCATION })
      this.calculateNearbyCourses(MOCK_LOCATION)
      console.log('开发模式：使用模拟位置（北京）')
      return
    }

    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        const location = {
          latitude: res.latitude,
          longitude: res.longitude
        }
        this.setData({ userLocation: location })
        this.calculateNearbyCourses(location)
      },
      fail: () => {
        wx.showToast({ title: '定位失败，使用默认位置', icon: 'none' })
        const DEFAULT_LOCATION = { latitude: 39.90, longitude: 116.40 }
        this.setData({ userLocation: DEFAULT_LOCATION })
        this.calculateNearbyCourses(DEFAULT_LOCATION)
      }
    })
  },

  // 加载球场数据（带自动计算和校正）
  loadCourses() {
    // 处理球场数据：自动计算总杆数和总距离，标记异常数据
    const courses = CHINA_COURSES.map(course => {
      // 自动计算总标准杆和总距离
      const totalPar = course.holes.reduce((sum, h) => sum + h.par, 0)
      const totalDistance = course.holes.reduce((sum, h) => sum + (h.distance || 0), 0)

      // 校验标准杆是否合理（正常应该是70-74之间）
      const isParValid = totalPar >= 70 && totalPar <= 74

      // 标记需要用户验证的数据
      const needsVerification = !isParValid

      return {
        ...course,
        totalPar,
        totalDistance,
        needsVerification,
        dataSource: '内置数据库',
        dataVersion: '2024.03'
      }
    })

    // 检查是否有异常数据并记录日志
    const abnormalCourses = courses.filter(c => c.needsVerification)
    if (abnormalCourses.length > 0) {
      console.warn('【球场数据】以下球场标准杆异常，建议验证：', abnormalCourses.map(c => c.name))
    }

    wx.setStorageSync('courses', courses)
    console.log('球场数据已加载，共', courses.length, '个球场')
  },

  // 报告球场数据错误（用户纠错入口）
  reportCourseError(courseId, errorType, correctValue) {
    const courses = wx.getStorageSync('courses') || []
    const course = courses.find(c => c.id === courseId)
    if (!course) return

    // 保存用户反馈到本地
    const feedback = {
      courseId,
      courseName: course.name,
      errorType, // 'par', 'distance', 'location', etc.
      currentValue: course.holes.find(h => h.hole === errorType)?.par || course.totalPar,
      correctValue,
      reportTime: new Date().toISOString(),
      userId: wx.getStorageSync('userId') || 'anonymous'
    }

    let feedbackList = wx.getStorageSync('courseFeedback') || []
    feedbackList.push(feedback)
    wx.setStorageSync('courseFeedback', feedbackList)

    console.log('【球场纠错】用户反馈已保存：', feedback)
    wx.showToast({ title: '感谢您的反馈，我们会尽快核实', icon: 'none' })

    // 实际项目中这里应该发送到服务器
    // this.submitFeedbackToServer(feedback)
  },

  // 计算附近球场
  calculateNearbyCourses(userLoc) {
    const courses = wx.getStorageSync('courses') || []
    // 过滤掉模拟数据，只显示真实球场数据
    const builtinCourses = courses.filter(c => !c.id.startsWith('mock-'))

    const { coursePlayCounts } = this.data

    const coursesWithDistance = builtinCourses.map(course => {
      const distance = calculateDistance(
        userLoc.latitude, userLoc.longitude,
        course.latitude, course.longitude
      )
      return {
        ...course,
        distance,
        playCount: coursePlayCounts[course.id] || 0,
        totalPar: course.holes.reduce((sum, h) => sum + h.par, 0),
        totalDistance: course.holes.reduce((sum, h) => sum + (h.distance || 0), 0)
      }
    })

    // 保存完整列表用于后续筛选
    this.setData({ nearbyCourses: coursesWithDistance })

    // 应用当前的排序和筛选
    this.applyFiltersAndSort()

    // 获取天气信息
    this.fetchWeather(userLoc)
  },

  // 应用筛选和排序
  applyFiltersAndSort() {
    const { nearbyCourses, searchKeyword, showFavoritesOnly, favoriteCourseIds, sortBy } = this.data

    let result = [...nearbyCourses]

    // 球场名称去重：同名保留一个（已经按距离排序，保留第一个就是最近的）
    const nameMap = new Map()
    result = result.filter(course => {
      if (nameMap.has(course.name)) {
        return false
      }
      nameMap.set(course.name, true)
      return true
    })

    // 1. 按收藏筛选
    if (showFavoritesOnly) {
      result = result.filter(c => favoriteCourseIds.includes(c.id))
    }

    // 2. 按搜索关键词筛选
    if (searchKeyword.trim()) {
      const keyword = searchKeyword.toLowerCase()
      result = result.filter(c =>
        c.name.toLowerCase().includes(keyword) ||
        c.location.toLowerCase().includes(keyword) ||
        (c.city && c.city.toLowerCase().includes(key))
      )
    }

    // 3. 排序
    if (sortBy === 'playCount') {
      // 按打球次数降序，次数相同按距离升序
      result.sort((a, b) => {
        if (b.playCount !== a.playCount) return b.playCount - a.playCount
        return a.distance - b.distance
      })
    } else {
      // 默认按距离升序
      result.sort((a, b) => a.distance - b.distance)
    }

    // 4. 格式化显示数据
    const displayCourses = result.map(course => {
      const totalDistanceFormatted = course.totalDistance > 0
        ? (course.totalDistance / 1000).toFixed(1) + 'k'
        : '-'
      return {
        ...course,
        distanceFormatted: formatDistance(course.distance),
        totalDistanceFormatted,
        imageUrl: this.getCourseImage(course.name),
        isFavorite: favoriteCourseIds.includes(course.id)
      }
    })

    // 更新推荐球场（取第一个）
    const recommendedCourse = displayCourses.length > 0 ? displayCourses[0] : null
    const selectedCourseId = recommendedCourse ? recommendedCourse.id : ''

    // 生成地图标记
    const markers = displayCourses.slice(0, 3).map((course, index) => ({
      id: index,
      latitude: course.latitude,
      longitude: course.longitude,
      title: course.name
    }))

    this.setData({
      displayCourses,
      nearbyCoursesDisplay: displayCourses.slice(0, 10),
      recommendedCourse,
      selectedCourseId,
      markers
    })

    // 保存选中的球场
    if (recommendedCourse) {
      wx.setStorageSync('currentCourseId', recommendedCourse.id)
    }
  },

  // 搜索输入
  onSearchInput(e) {
    this.setData({ searchKeyword: e.detail.value }, () => {
      this.applyFiltersAndSort()
    })
  },

  // 清除搜索
  clearSearch() {
    this.setData({ searchKeyword: '' }, () => {
      this.applyFiltersAndSort()
    })
  },

  // 切换只显示收藏
  toggleFavoritesOnly() {
    this.setData({ showFavoritesOnly: !this.data.showFavoritesOnly }, () => {
      this.applyFiltersAndSort()
    })
  },

  // 切换排序方式
  toggleSortBy() {
    const newSortBy = this.data.sortBy === 'distance' ? 'playCount' : 'distance'
    this.setData({ sortBy: newSortBy }, () => {
      this.applyFiltersAndSort()
    })
  },

  // 切换收藏状态
  toggleFavorite(e) {
    const courseId = e.currentTarget.dataset.courseId
    const { favoriteCourseIds } = this.data

    let newFavorites
    if (favoriteCourseIds.includes(courseId)) {
      newFavorites = favoriteCourseIds.filter(id => id !== courseId)
      wx.showToast({ title: '已取消收藏', icon: 'none' })
    } else {
      newFavorites = [...favoriteCourseIds, courseId]
      wx.showToast({ title: '已收藏', icon: 'success' })
    }

    wx.setStorageSync('favoriteCourseIds', newFavorites)
    this.setData({ favoriteCourseIds: newFavorites }, () => {
      this.applyFiltersAndSort()
    })
  },

  // 获取天气（使用模拟数据，实际可接入和风天气等API）
  fetchWeather(location) {
    // 模拟天气数据，根据时间决定
    const hour = new Date().getHours()
    const weatherTypes = [
      { icon: '☀️', temp: 25, desc: '晴', effect: 'sunny' },
      { icon: '⛅', temp: 22, desc: '多云', effect: 'cloudy' },
      { icon: '🌧️', temp: 18, desc: '小雨', effect: 'rainy' },
      { icon: '☁️', temp: 20, desc: '阴', effect: 'cloudy' }
    ]

    // 根据位置简单随机选择一种天气（实际应根据真实API返回）
    const index = Math.floor((location.latitude + location.longitude) * 100) % weatherTypes.length
    const weather = weatherTypes[index]

    this.setData({
      weather: {
        icon: weather.icon,
        temp: weather.temp,
        desc: weather.desc
      },
      weatherEffect: weather.effect
    })
  },

  // 选择球场
  selectCourse(e) {
    const course = e.currentTarget.dataset.course
    this.setData({ selectedCourseId: course.id })
    wx.setStorageSync('currentCourseId', course.id)

    // 更新推荐球场显示 - 从nearbyCoursesDisplay找，它已经格式化好了
    const recommendedCourse = this.data.nearbyCoursesDisplay.find(c => c.id === course.id)
    if (recommendedCourse) {
      this.setData({ recommendedCourse })
    }
  },

  // 跳转到全部球场页面
  goToAllCourses() {
    wx.navigateTo({
      url: '/pages/all-courses/all-courses'
    })
  },

  // 下一步
  goNext() {
    if (!this.data.selectedCourseId) {
      wx.showToast({ title: '请先选择球场', icon: 'none' })
      return
    }

    wx.navigateTo({
      url: '/pages/new-game/step2-players/step2-players'
    })
  },

  // 显示数据来源弹窗
  showCourseDataSource() {
    const course = this.data.recommendedCourse
    if (!course) return

    // 确保有默认值
    const courseForReport = {
      name: course.name || '',
      totalPar: course.totalPar || 72,
      dataSource: course.dataSource || '公开资料',
      needsVerification: course.needsVerification || false,
      ...course
    }

    this.setData({
      showDataModal: true,
      selectedCourseForReport: courseForReport,
      errorTypeIndex: -1,
      correctValue: ''
    })
  },

  // 隐藏数据来源弹窗
  hideDataModal() {
    this.setData({ showDataModal: false })
  },

  // 阻止冒泡
  preventHide(e) {
    // 阻止事件冒泡，点击弹窗内容时不关闭
  },

  // 选择错误类型
  onErrorTypeChange(e) {
    this.setData({ errorTypeIndex: parseInt(e.detail.value) })
  },

  // 输入正确值
  onCorrectValueInput(e) {
    this.setData({ correctValue: e.detail.value })
  },

  // 提交球场数据纠错
  submitCourseError() {
    const { selectedCourseForReport, errorTypeIndex, errorTypes, correctValue } = this.data

    if (errorTypeIndex < 0) {
      wx.showToast({ title: '请选择错误类型', icon: 'none' })
      return
    }

    if (!correctValue.trim()) {
      wx.showToast({ title: '请输入正确的数据', icon: 'none' })
      return
    }

    // 调用之前定义的 reportCourseError 方法
    const errorTypeMap = {
      0: 'par',
      1: 'distance',
      2: 'holes',
      3: 'location',
      4: 'other'
    }

    this.reportCourseError(
      selectedCourseForReport.id,
      errorTypeMap[errorTypeIndex],
      correctValue.trim()
    )

    this.hideDataModal()
  },

  // 显示洞明细弹窗
  showHolesDetail() {
    const course = this.data.recommendedCourse
    if (!course) {
      wx.showToast({ title: '请先选择球场', icon: 'none' })
      return
    }

    this.setData({
      showHolesModal: true,
      selectedCourse: course,
      totalPar: course.holes.reduce((sum, h) => sum + h.par, 0)
    })
  },

  // 关闭洞明细弹窗
  hideHolesModal() {
    this.setData({ showHolesModal: false })
  },

  // 开始OCR校对 - 拍照选择图片
  startOcrVerify() {
    const course = this.data.recommendedCourse
    if (!course) {
      wx.showToast({ title: '请先选择球场', icon: 'none' })
      return
    }

    // 保存原始数据
    this.setData({
      originalHoles: course.holes,
      originalTotalPar: course.totalPar
    })

    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['camera', 'album'],
      camera: 'back',
      success: (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath
        wx.showLoading({ title: '识别中...' })
        this.recognizeScorecard(tempFilePath)
      },
      fail: () => {
        wx.showToast({ title: '取消选择', icon: 'none' })
      }
    })
  },

  // 识别计分卡图片
  recognizeScorecard(imagePath) {
    // 临时提示：需要开通微信OCR插件
    wx.hideLoading()
    wx.showModal({
      title: 'OCR功能说明',
      content: 'OCR识别需要开通微信公众平台OCR插件。开通后删除临时代码即可使用。当前请对比差异后手动确认。',
      showCancel: false,
      confirmText: '知道了'
    })

    // 开通OCR插件后取消注释下面代码启用功能
    /*
    try {
      const OCR = requirePlugin('ocr-plugin')
      const ocr = new OCR()

      ocr.recognize({
        type: 0, // 通用印刷体识别
        image: imagePath,
        success: (res) => {
          wx.hideLoading()
          const ocrText = res.words_result.map(item => item.word).join('\n')
          const courseData = this.parseOcrText(ocrText)

          if (courseData.holes.length > 0) {
            // 对比数据差异
            this.compareData(courseData.holes)
          } else {
            wx.showModal({
              title: '识别失败',
              content: '未能识别到任何洞数据，请确保图片清晰包含完整计分卡',
              showCancel: false
            })
          }
        },
        fail: (err) => {
          wx.hideLoading()
          wx.showModal({
            title: '识别失败',
            content: 'OCR识别服务调用失败，请确保已开通OCR插件',
            showCancel: false
          })
        }
      })
    } catch (e) {
      wx.hideLoading()
      wx.showModal({
        title: '功能未启用',
        content: 'OCR插件未安装，请先在微信公众平台添加OCR插件',
        showCancel: false
      })
    }
    */
  },

  // 解析OCR文本提取洞数据
  parseOcrText(text) {
    const holes = []

    // 匹配洞数据：尝试多种格式
    // 格式1: 1 4 420 / 洞1 Par 4
    const holePattern1 = /[#Hh]?ole?\s*(\d{1,2})[\s\D]+([3-5])[\s\D]*(\d{2,4})/gi
    // 格式2: 第一洞 标准杆4
    const holePattern2 = /[第]?\s*(\d{1,2})\s*[洞][\s\D]*[Pp][Aa][Rr]?\s*([3-5])/gi
    // 格式3: 1: par=4
    const holePattern3 = /(\d{1,2})[\:\s]+[Pp][Aa][Rr]\s*=\s*([3-5])/gi

    let match
    const holesMap = {}

    // 尝试所有模式
    while ((match = holePattern1.exec(text)) !== null) {
      this.addParsedHole(holesMap, match)
    }
    while ((match = holePattern2.exec(text)) !== null) {
      this.addParsedHole(holesMap, match)
    }
    while ((match = holePattern3.exec(text)) !== null) {
      this.addParsedHole(holesMap, match)
    }

    // 转换为数组，补全缺失洞
    for (let i = 1; i <= 18; i++) {
      if (holesMap[i]) {
        holes.push({
          id: i,
          par: holesMap[i].par,
          distance: holesMap[i].distance || 0
        })
      }
    }

    return {
      holes: holes.sort((a, b) => a.id - b.id),
      par: holes.reduce((sum, h) => sum + h.par, 0)
    }
  },

  // 添加解析到的洞数据
  addParsedHole(holesMap, match) {
    const holeNum = parseInt(match[1])
    const par = parseInt(match[2])
    const distance = match[3] ? parseInt(match[3]) : 0

    if (1 <= holeNum && holeNum <= 18 && 3 <= par && par <= 5) {
      holesMap[holeNum] = { par, distance }
    }
  },

  // 对比原始数据和识别数据，找出差异
  compareData(ocrHoles) {
    const { originalHoles } = this.data
    let hasDiff = false

    // 补全OCR缺失的洞
    const fullOcrHoles = []
    for (let i = 1; i <= 18; i++) {
      const found = ocrHoles.find(h => h.id === i)
      if (found) {
        fullOcrHoles.push(found)
      } else if (originalHoles[i - 1]) {
        // 缺失的洞保持原样
        fullOcrHoles.push({ ...originalHoles[i - 1] })
      } else {
        fullOcrHoles.push({ id: i, par: 4, distance: 0 })
      }
    }

    // 检查差异
    for (let i = 0; i < 18; i++) {
      const original = originalHoles[i]
      const ocr = fullOcrHoles[i]
      if (original && ocr && original.par !== ocr.par) {
        hasDiff = true
        break
      }
    }

    const ocrTotalPar = fullOcrHoles.reduce((sum, h) => sum + h.par, 0)

    this.setData({
      showOcrVerifyModal: true,
      ocrHoles: fullOcrHoles,
      ocrTotalPar,
      hasDiff
    })
  },

  // 确认替换数据
  confirmReplaceData() {
    const { recommendedCourse, ocrHoles, ocrTotalPar } = this.data
    if (!recommendedCourse) return

    // 从缓存中取出所有球场
    let allCourses = wx.getStorageSync('courses') || []
    const courseIndex = allCourses.findIndex(c => c.id === recommendedCourse.id)

    // 更新球场数据
    const updatedCourse = {
      ...recommendedCourse,
      holes: ocrHoles,
      totalPar: ocrTotalPar,
      needsVerification: false,
      updatedAt: new Date().toISOString()
    }

    if (courseIndex >= 0) {
      allCourses[courseIndex] = updatedCourse
    } else {
      allCourses.push(updatedCourse)
    }

    // 保存回缓存
    wx.setStorageSync('courses', allCourses)

    // 更新页面数据
    this.setData({
      recommendedCourse: updatedCourse,
      showOcrVerifyModal: false
    })

    // 重新保存选中的球场
    wx.setStorageSync('currentCourseId', recommendedCourse.id)

    wx.showToast({ title: '数据已更新', icon: 'success' })
  },

  // 关闭OCR校对弹窗
  hideOcrVerifyModal() {
    this.setData({ showOcrVerifyModal: false })
  },

  // 新增球场 - 打开OCR识别
  addNewCourse() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['camera', 'album'],
      camera: 'back',
      success: (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath
        wx.showLoading({ title: '识别中...' })
        this.recognizeScorecardForNew(tempFilePath)
      },
      fail: () => {
        wx.showToast({ title: '取消选择', icon: 'none' })
      }
    })
  },

  // 识别新球场计分卡
  recognizeScorecardForNew(imagePath) {
    // 临时提示：需要开通微信OCR插件
    wx.hideLoading()
    wx.showModal({
      title: 'OCR功能说明',
      content: 'OCR识别需要开通微信公众平台OCR插件。开通后删除临时代码即可使用。',
      showCancel: false,
      confirmText: '知道了'
    })

    // 开通OCR插件后取消注释下面代码启用功能
    /*
    try {
      const OCR = requirePlugin('ocr-plugin')
      const ocr = new OCR()

      ocr.recognize({
        type: 0,
        image: imagePath,
        success: (res) => {
          wx.hideLoading()
          const ocrText = res.words_result.map(item => item.word).join('\n')
          const courseData = this.parseOcrText(ocrText)

          if (courseData.holes.length > 0) {
            // 补全18洞
            const fullHoles = []
            for (let i = 1; i <= 18; i++) {
              const found = courseData.holes.find(h => h.id === i)
              if (found) {
                fullHoles.push(found)
              } else {
                fullHoles.push({ id: i, par: 4, distance: 0 })
              }
            }
            const totalPar = fullHoles.reduce((sum, h) => sum + h.par, 0)

            // 弹窗让用户确认球场名称
            wx.showModal({
              title: '识别完成',
              content: `识别到${courseData.holes.length}个洞，总标准杆${totalPar}，请确认球场名称`,
              editable: true,
              placeholderText: '请输入球场名称',
              success: (res) => {
                if (res.confirm && res.content.trim()) {
                  this.saveNewCourse(res.content.trim(), fullHoles, totalPar)
                }
              }
            })
          } else {
            wx.showModal({
              title: '识别失败',
              content: '未能识别到任何洞数据，请确保图片清晰包含完整计分卡',
              showCancel: false
            })
          }
        },
        fail: () => {
          wx.hideLoading()
          wx.showModal({
            title: '识别失败',
            content: 'OCR识别服务调用失败，请确保已开通OCR插件',
            showCancel: false
          })
        }
      })
    } catch (e) {
      wx.hideLoading()
      wx.showModal({
        title: '功能未启用',
        content: 'OCR插件未安装，请先在微信公众平台添加OCR插件',
        showCancel: false
      })
    }
    */
  },

  // 保存新球场
  saveNewCourse(courseName, holes, totalPar) {
    const { userLocation, userCity } = this.data
    const allCourses = wx.getStorageSync('courses') || []

    // 检查是否已存在同名球场
    const existing = allCourses.find(c =>
      c.name.toLowerCase().includes(courseName.toLowerCase()) ||
      courseName.toLowerCase().includes(c.name.toLowerCase())
    )

    if (existing) {
      wx.showModal({
        title: '球场已存在',
        content: `已找到相似球场 "${existing.name}"，是否仍要创建新球场？`,
        success: (res) => {
          if (res.confirm) {
            this.doSaveNewCourse(courseName, holes, totalPar, userLocation, userCity, allCourses)
          }
        }
      })
    } else {
      this.doSaveNewCourse(courseName, holes, totalPar, userLocation, userCity, allCourses)
    }
  },

  // 执行保存
  doSaveNewCourse(courseName, holes, totalPar, userLocation, userCity, allCourses) {
    const newId = 'custom-' + Date.now()
    const newCourse = {
      id: newId,
      name: courseName,
      location: userCity || '自定义',
      province: userCity || '',
      city: userCity || '',
      latitude: userLocation?.latitude || 0,
      longitude: userLocation?.longitude || 0,
      holes: holes,
      totalPar: totalPar,
      totalDistance: holes.reduce((sum, h) => sum + (h.distance || 0), 0),
      isCustom: true,
      createdAt: new Date().toISOString(),
      needsVerification: false
    }

    allCourses.push(newCourse)
    wx.setStorageSync('courses', allCourses)

    // 重新计算附近球场
    if (userLocation) {
      this.calculateNearbyCourses(userLocation)
    }

    wx.showToast({ title: '新球场添加成功', icon: 'success' })
  }
})
