const { GAME_MODES } = require('../../../data/game-modes.js')

Page({
  data: {
    currentCourse: null,
    players: [],
    gameModes: GAME_MODES,
    selectedMode: '',
    selectedModeInfo: null,
    showModal: false,
    modalContent: {},
    // 让洞/让杆设置
    showHandicapModal: false,
    handicaps: {},
    handicapType: 'holes', // 'holes' 或 'strokes'
    // 组队设置（最佳球）
    showTeamModal: false,
    teams: {},
    // 地主设置（斗地主）
    showLandlordModal: false,
    landlordId: ''
  },

  onLoad() {
    this.loadCourse()
    this.loadPlayers()
    this.initSettings()
    this.setData({
      selectedMode: GAME_MODES[0]?.id || '',
      selectedModeInfo: GAME_MODES[0] || null
    })
  },

  onShow() {
    // step3-mode 不是 TabBar 页面，不需要设置 selected
  },

  // 初始化设置数据
  initSettings() {
    const players = wx.getStorageSync('tempPlayers') || []
    const handicaps = {}
    players.forEach(p => {
      handicaps[p.id] = 0
    })
    this.setData({ handicaps })
  },

  // 加载当前球场
  loadCourse() {
    const currentCourseId = wx.getStorageSync('currentCourseId')
    const courses = wx.getStorageSync('courses') || []
    const currentCourse = courses.find(c => c.id === currentCourseId)
    this.setData({ currentCourse })
  },

  // 加载球员
  loadPlayers() {
    const players = wx.getStorageSync('tempPlayers') || []
    this.setData({ players })
  },

  // 选择玩法
  selectMode(e) {
    const modeId = e.currentTarget.dataset.mode
    const selectedModeInfo = this.data.gameModes.find(m => m.id === modeId)

    this.setData({
      selectedMode: modeId,
      selectedModeInfo
    })

    // 根据玩法类型提示设置
    this.promptModeSettings(modeId, selectedModeInfo)
  },

  // 提示玩法设置
  promptModeSettings(modeId, modeInfo) {
    // 比杆赛 - 让杆设置
    if (modeId === 'stroke' && modeInfo.hasHandicap) {
      wx.showModal({
        title: '让杆设置',
        content: '比杆赛支持让杆设计，是否现在设置？',
        confirmText: '去设置',
        cancelText: '跳过',
        success: (res) => {
          if (res.confirm) {
            this.setData({ handicapType: 'strokes' })
            this.showHandicapSetup()
          }
        }
      })
    }

    // 比洞赛 - 让洞设置
    if (modeId === 'match' && modeInfo.hasHandicap) {
      wx.showModal({
        title: '让洞设置',
        content: '比洞赛支持让洞设计，是否现在设置？',
        confirmText: '去设置',
        cancelText: '跳过',
        success: (res) => {
          if (res.confirm) {
            this.setData({ handicapType: 'holes' })
            this.showHandicapSetup()
          }
        }
      })
    }

    // 最佳球 - 组队设置
    if (modeId === 'bestball' && modeInfo.needsTeams) {
      wx.showModal({
        title: '组队设置',
        content: '最佳球玩法需要两人一队，是否现在设置？',
        confirmText: '去设置',
        cancelText: '跳过',
        success: (res) => {
          if (res.confirm) {
            this.showTeamSetup()
          }
        }
      })
    }

    // 斗地主 - 初始地主设置
    if (modeId === 'landlord' && modeInfo.needsLandlord) {
      wx.showModal({
        title: '初始地主设置',
        content: '斗地主玩法需要设置初始地主，是否现在设置？',
        confirmText: '去设置',
        cancelText: '跳过',
        success: (res) => {
          if (res.confirm) {
            this.showLandlordSetup()
          }
        }
      })
    }
  },

  // ========== 让洞/让杆设置 ==========
  // 显示让洞/让杆设置弹窗
  showHandicapSetup() {
    this.setData({
      showHandicapModal: true
    })
  },

  // 隐藏让洞/让杆设置弹窗
  hideHandicapModal() {
    this.setData({ showHandicapModal: false })
  },

  // 调整让洞/让杆数
  adjustHandicap(e) {
    const playerId = e.currentTarget.dataset.player
    const delta = parseInt(e.currentTarget.dataset.delta)
    const maxValue = this.data.handicapType === 'holes' ? 18 : 36

    const current = this.data.handicaps[playerId] || 0
    const newValue = Math.max(0, Math.min(current + delta, maxValue))

    this.setData({
      [`handicaps.${playerId}`]: newValue
    })
  },

  // 确认让洞/让杆设置
  confirmHandicap() {
    this.setData({ showHandicapModal: false })
  },

  // ========== 组队设置（最佳球） ==========
  // 显示组队设置弹窗
  showTeamSetup() {
    const { players } = this.data
    // 默认自动分组
    const teams = {}
    players.forEach((p, index) => {
      teams[p.id] = Math.floor(index / 2) + 1 // 1, 1, 2, 2, 3, 3...
    })
    this.setData({
      showTeamModal: true,
      teams
    })
  },

  // 隐藏组队设置弹窗
  hideTeamModal() {
    this.setData({ showTeamModal: false })
  },

  // 调整队伍
  adjustTeam(e) {
    const playerId = e.currentTarget.dataset.player
    const delta = parseInt(e.currentTarget.dataset.delta)
    const current = this.data.teams[playerId] || 1
    const newValue = Math.max(1, current + delta)

    this.setData({
      [`teams.${playerId}`]: newValue
    })
  },

  // 确认组队设置
  confirmTeamSetup() {
    this.setData({ showTeamModal: false })
  },

  // ========== 地主设置（斗地主） ==========
  // 显示地主设置弹窗
  showLandlordSetup() {
    const { players } = this.data
    this.setData({
      showLandlordModal: true,
      landlordId: players[0]?.id || ''
    })
  },

  // 隐藏地主设置弹窗
  hideLandlordModal() {
    this.setData({ showLandlordModal: false })
  },

  // 选择地主
  selectLandlord(e) {
    const playerId = e.currentTarget.dataset.player
    this.setData({ landlordId: playerId })
  },

  // 确认地主设置
  confirmLandlordSetup() {
    this.setData({ showLandlordModal: false })
  },

  // ========== 规则弹窗 ==========
  // 显示规则
  showRules(e) {
    const mode = e.currentTarget.dataset.mode
    this.setData({
      showModal: true,
      modalContent: mode
    })
  },

  // 隐藏弹窗
  hideModal() {
    this.setData({ showModal: false })
  },

  // 阻止冒泡
  preventHide() {
    // 什么都不做，只是阻止事件冒泡
  },

  // 上一步
  goBack() {
    wx.navigateBack()
  },

  // 开始比赛
  startGame() {
    const { currentCourse, players, selectedMode, handicaps, teams, landlordId, handicapType } = this.data

    if (!selectedMode) {
      wx.showToast({ title: '请选择玩法', icon: 'none' })
      return
    }

    // 检查球场数据是否需要验证
    const verifiedCourses = wx.getStorageSync('verifiedCourses') || []
    const isCourseVerified = verifiedCourses.includes(currentCourse.id)

    if (!isCourseVerified && currentCourse.needsVerification) {
      // 显示请求验证弹窗
      wx.showModal({
        title: '球场数据待验证',
        content: '该球场的数据尚未经过人工核对，可能存在偏差。为了确保计分准确，建议您拍摄一张球场纸质记分卡，AI将自动解析出每洞的标准杆和距离数据。',
        confirmText: '拍摄记分卡',
        cancelText: '使用现有数据',
        success: (res) => {
          if (res.confirm) {
            this.requestCourseVerification()
          } else {
            // 用户选择跳过，直接开始比赛
            this.doStartGame()
          }
        }
      })
      return
    }

    // 无需验证，直接开始比赛
    this.doStartGame()
  },

  // 请求球场数据验证
  requestCourseVerification() {
    const { currentCourse } = this.data

    wx.showActionSheet({
      itemList: ['拍摄记分卡', '从相册选择'],
      success: (res) => {
        const sourceType = res.tapIndex === 0 ? ['camera'] : ['album']

        wx.chooseMedia({
          count: 1,
          mediaType: ['image'],
          sourceType: sourceType,
          success: (mediaRes) => {
            const tempFilePath = mediaRes.tempFiles[0].tempFilePath

            wx.showLoading({ title: 'AI解析中...' })

            // 模拟AI解析过程（实际项目中调用后端AI服务）
            setTimeout(() => {
              wx.hideLoading()

              // 模拟解析结果
              const mockResult = this.mockAIParse()

              wx.showModal({
                title: '解析结果',
                content: `AI已解析出球场数据：\n前9洞: ${mockResult.front9.join(', ')}\n后9洞: ${mockResult.back9.join(', ')}\n\n是否使用此数据更新球场信息？`,
                confirmText: '使用新数据',
                cancelText: '重新拍摄',
                success: (modalRes) => {
                  if (modalRes.confirm) {
                    this.updateCourseData(mockResult)
                    // 标记球场已验证
                    const verifiedCourses = wx.getStorageSync('verifiedCourses') || []
                    verifiedCourses.push(currentCourse.id)
                    wx.setStorageSync('verifiedCourses', verifiedCourses)
                    // 继续开始比赛
                    this.doStartGame()
                  } else {
                    this.requestCourseVerification()
                  }
                }
              })
            }, 2000)
          },
          fail: () => {
            wx.showToast({ title: '选择图片失败', icon: 'none' })
          }
        })
      }
    })
  },

  // 模拟AI解析结果（实际项目中应由后端AI返回）
  mockAIParse() {
    const { currentCourse } = this.data
    // 基于现有数据生成模拟解析结果
    return {
      front9: [4, 4, 3, 4, 5, 4, 4, 3, 5],
      back9: [4, 4, 3, 4, 5, 4, 4, 3, 5],
      distances: [380, 410, 165, 395, 520, 405, 390, 170, 535, 385, 400, 155, 375, 515, 410, 395, 160, 530]
    }
  },

  // 更新球场数据
  updateCourseData(parsedData) {
    const currentCourseId = wx.getStorageSync('currentCourseId')
    const courses = wx.getStorageSync('courses') || []

    const courseIndex = courses.findIndex(c => c.id === currentCourseId)
    if (courseIndex !== -1) {
      // 更新洞数据
      const updatedHoles = courses[courseIndex].holes.map((hole, index) => ({
        ...hole,
        par: parsedData.front9[index] || parsedData.back9[index - 9] || hole.par,
        distance: parsedData.distances[index] || hole.distance
      }))

      courses[courseIndex] = {
        ...courses[courseIndex],
        holes: updatedHoles,
        needsVerification: false,
        verifiedAt: new Date().toISOString()
      }

      wx.setStorageSync('courses', courses)
      this.setData({ currentCourse: courses[courseIndex] })

      wx.showToast({ title: '球场数据已更新', icon: 'success' })
    }
  },

  // 继续开始比赛（跳过验证或验证完成后调用）
  doStartGame() {
    const { currentCourse, players, selectedMode, handicaps, teams, landlordId, handicapType } = this.data

    // 保存球员到正式存储
    wx.setStorageSync('players', players)

    // 清理临时数据
    wx.removeStorageSync('tempPlayers')

    // 初始化比赛
    const game = {
      id: Date.now().toString(),
      courseId: currentCourse.id,
      courseName: currentCourse.name,
      players: players,
      scores: {},
      timestamp: Date.now(),
      completed: false,
      gameMode: selectedMode
    }

    // 根据玩法添加设置
    if (selectedMode === 'stroke' || selectedMode === 'match') {
      game.handicaps = handicaps
      game.handicapType = handicapType
    }

    if (selectedMode === 'bestball') {
      game.teams = teams
    }

    if (selectedMode === 'landlord') {
      game.landlordId = landlordId
      game.currentLandlordId = landlordId
    }

    players.forEach(player => {
      game.scores[player.id] = {}
    })

    wx.setStorageSync('currentGame', game)

    wx.showToast({
      title: '比赛开始！',
      icon: 'success',
      success: () => {
        setTimeout(() => {
          // 使用 redirectTo 跳转到记分卡（不是 tabBar 页面）
          wx.redirectTo({
            url: '/pages/scorecard/scorecard'
          })
        }, 1500)
      }
    })
  }
})
