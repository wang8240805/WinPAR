// 开发模式开关
const DEV_MODE = false

Page({
  data: {
    currentCourse: null,
    players: [],
    newPlayerName: '',
    colors: ['#2c8f4e', '#2196f3', '#ff9800', '#f44336', '#9c27b0', '#00bcd4', '#795548', '#607d8b']
  },

  onLoad(options) {
    this.loadCourse(options && options.courseId ? options.courseId : null)
    this.loadPlayers()

    // 如果是通过分享邀请进来，自动添加当前用户到球员列表
    if (options && options.courseId) {
      this.autoAddCurrentUserOnShare()
      // 自动添加分享者到球员列表（邀请人）
      if (options.shareNickName) {
        const shareNickName = decodeURIComponent(options.shareNickName)
        const shareAvatar = options.shareAvatar ? decodeURIComponent(options.shareAvatar) : ''
        console.log('收到分享参数:', { shareNickName, shareAvatar })
        this.addSharedInviter(shareNickName, shareAvatar)
      }
    }
  },

  onShow() {
    this.loadPlayers()
    // step2-players 不是 TabBar 页面，不需要设置 selected
  },

  // 分享邀请进来，自动添加当前用户
  autoAddCurrentUserOnShare() {
    const cachedUserInfo = wx.getStorageSync('userInfo')
    const { players, colors } = this.data

    if (cachedUserInfo && cachedUserInfo.nickName) {
      // 已有授权信息，直接添加
      const colorIndex = players.length % colors.length
      const newPlayer = {
        id: 'current-user-share',
        name: cachedUserInfo.nickName,
        color: colors[colorIndex],
        fromContact: true,
        avatar: cachedUserInfo.avatarUrl,
        isMe: true
      }
      const updatedPlayers = [...players, newPlayer]
      wx.setStorageSync('tempPlayers', updatedPlayers)
      this.setData({ players: updatedPlayers })
      wx.showToast({ title: '已自动添加你到球员列表', icon: 'success' })
    } else {
      // 未授权，弹框授权
      wx.getUserProfile({
        desc: '获取你的昵称和头像加入比赛',
        success: (res) => {
          const userInfo = res.userInfo
          wx.setStorageSync('userInfo', userInfo)

          const colorIndex = players.length % colors.length
          const newPlayer = {
            id: 'current-user-share',
            name: userInfo.nickName,
            color: colors[colorIndex],
            fromContact: true,
            avatar: userInfo.avatarUrl,
            isMe: true
          }
          const updatedPlayers = [...players, newPlayer]
          wx.setStorageSync('tempPlayers', updatedPlayers)
          this.setData({ players: updatedPlayers })
          wx.showToast({ title: '添加成功', icon: 'success' })
        },
        fail: () => {
          // 授权失败，还是添加进去，使用默认名称
          const colorIndex = players.length % colors.length
          const newPlayer = {
            id: 'current-user-share',
            name: '我',
            color: colors[colorIndex],
            fromContact: true,
            avatar: '',
            isMe: true
          }
          const updatedPlayers = [...players, newPlayer]
          wx.setStorageSync('tempPlayers', updatedPlayers)
          this.setData({ players: updatedPlayers })
          wx.showToast({ title: '已添加，昵称使用默认，授权后可更新', icon: 'none' })
        }
      })
    }
  },

  // 分享功能
  onShareAppMessage() {
    const { currentCourse, players } = this.data
    const courseId = currentCourse ? currentCourse.id : ''
    // 带上分享者自己的昵称和头像，对方打开后自动添加分享者到列表
    const cachedUserInfo = wx.getStorageSync('userInfo') || {}
    const shareNickName = cachedUserInfo.nickName || '我'
    const shareAvatar = cachedUserInfo.avatarUrl || ''
    const shareOpenid = cachedUserInfo.openid || ''

    return {
      title: `${shareNickName}邀请你加入${currentCourse?.name || ''}的比赛`,
      path: `pages/new-game/step2-players/step2-players?courseId=${courseId}&shareNickName=${encodeURIComponent(shareNickName)}&shareAvatar=${encodeURIComponent(shareAvatar)}&shareOpenid=${shareOpenid}`,
      desc: `${players.length}人已加入，点击加入比赛`
    }
  },

  // 加载当前球场
  loadCourse(courseIdFromUrl) {
    let currentCourseId = courseIdFromUrl || wx.getStorageSync('currentCourseId')
    const courses = wx.getStorageSync('courses') || []
    // 先从本地存储找，找不到再从全局数据找
    let currentCourse = courses.find(c => c.id === currentCourseId)
    if (!currentCourse) {
      const { CHINA_COURSES } = require('../../../data/courses-accurate.js')
      currentCourse = CHINA_COURSES.find(c => c.id === currentCourseId)
      if (currentCourse && !courses.find(c => c.id === currentCourseId)) {
        courses.push(currentCourse)
        wx.setStorageSync('courses', courses)
      }
    }

    if (currentCourse) {
      currentCourse.totalPar = currentCourse.holes.reduce((sum, h) => sum + h.par, 0)
      // 保存到存储，后续步骤需要
      wx.setStorageSync('currentCourseId', currentCourseId)
    }

    this.setData({ currentCourse })
  },

  // 加载球员
  loadPlayers() {
    let players = wx.getStorageSync('tempPlayers') || []
    const cachedUserInfo = wx.getStorageSync('userInfo')

    // 如果用户未授权，先添加默认的"我"，由球员列表内的授权框引导用户
    // 微信规则：必须用户主动点击才能授权，不能自动弹出
    // 💡 去掉弹窗提示，只在球员卡片内显示授权框，避免提示两次
    if (!cachedUserInfo || !cachedUserInfo.nickName) {
      // 检查是否已经有默认的我
      const hasMe = players.some(p => p.id === 'current-user' || p.isMe)
      if (!hasMe && players.length === 0) {
        // 添加默认名称"我"
        const currentUser = {
          id: 'current-user',
          name: '我',
          color: this.data.colors[0],
          fromContact: false,
          avatar: '',
          isMe: true,
          isCurrentUser: true,
          needAuth: true
        }
        players = [currentUser]
        wx.setStorageSync('tempPlayers', players)
      }
      this.setData({ players })
    } else {
      const hasOnlyUnAuthorizedMe = players.length === 1 &&
        players[0].id === 'current-user' &&
        !players[0].avatar

      if (hasOnlyUnAuthorizedMe && cachedUserInfo) {
        // 已有授权，但列表还是默认未授权，重新添加自己到第一位
        this.addCurrentUserAsPlayer()
      } else {
        // 检查自己是否已经在列表第一位，如果不在，添加到第一位
        const hasMe = players.some(p => p.id === 'current-user' || p.isMe)
        if (!hasMe) {
          // 已有授权，添加自己到第一位
          this.addCurrentUserToFront()
        }
        this.setData({ players })
      }
    }
  },

  // 添加当前用户本人（已有授权）
  addCurrentUserAsPlayer() {
    const { colors } = this.data
    const cachedUserInfo = wx.getStorageSync('userInfo')

    // 已有缓存信息，直接添加
    const currentUser = {
      id: 'current-user',
      name: cachedUserInfo.nickName,
      color: colors[0],
      fromContact: false,
      avatar: cachedUserInfo.avatarUrl,
      isMe: true,
      isCurrentUser: true
    }
    const updatedPlayers = [currentUser]
    wx.setStorageSync('tempPlayers', updatedPlayers)
    this.setData({
      players: updatedPlayers
    })
    return
  },

  // 选择自己的头像（官方最新API）
  onChooseAvatarMe(e) {
    const { avatarUrl } = e.detail
    const { players } = this.data

    // 更新当前用户的头像
    const updatedPlayers = players.map(p => {
      if (p.id === 'current-user' || p.isMe) {
        return { ...p, avatar: avatarUrl }
      }
      return p
    })

    // 更新全局缓存中的用户信息
    let userInfo = wx.getStorageSync('userInfo') || {}
    userInfo.avatarUrl = avatarUrl
    wx.setStorageSync('userInfo', userInfo)

    wx.setStorageSync('tempPlayers', updatedPlayers)
    this.setData({ players: updatedPlayers })
    wx.showToast({ title: '头像已更新', icon: 'success' })
  },

  // 输入自己的昵称（官方最新API，微信自动提供选项）
  onNickNameInputMe(e) {
    const nickName = e.detail.value
    if (!nickName || nickName.trim().length === 0) return

    const { players } = this.data

    // 更新当前用户的昵称
    const updatedPlayers = players.map(p => {
      if (p.id === 'current-user' || p.isMe) {
        return { ...p, name: nickName, needAuth: false }
      }
      return p
    })

    // 更新全局缓存中的用户信息
    let userInfo = wx.getStorageSync('userInfo') || {}
    userInfo.nickName = nickName
    wx.setStorageSync('userInfo', userInfo)

    wx.setStorageSync('tempPlayers', updatedPlayers)
    this.setData({ players: updatedPlayers })
    wx.showToast({ title: '昵称已保存', icon: 'success' })
  },

  // 添加当前用户到列表第一位
  addCurrentUserToFront() {
    const cachedUserInfo = wx.getStorageSync('userInfo')
    if (!cachedUserInfo) return

    const { players, colors } = this.data
    const currentUser = {
      id: 'current-user',
      name: cachedUserInfo.nickName,
      color: colors[0],
      fromContact: false,
      avatar: cachedUserInfo.avatarUrl,
      isMe: true,
      isCurrentUser: true
    }
    // 插入到第一位
    const updatedPlayers = [currentUser, ...players]
    wx.setStorageSync('tempPlayers', updatedPlayers)
    this.setData({ players: updatedPlayers })
  },

  // 添加微信好友 - 直接从微信通讯录选择添加
  addPlayerFromContact() {
    if (this.data.players.length === 0) {
      wx.showToast({ title: '请先添加自己', icon: 'none' })
      return
    }

    // 打开微信通讯录选择联系人
    wx.chooseContact({
      success: (res) => {
        const { nickName, avatarUrl } = res
        const { players, colors } = this.data

        // 检查是否已添加
        if (players.some(p => p.name === nickName)) {
          wx.showToast({ title: '该球员已在列表中', icon: 'none' })
          return
        }

        const colorIndex = players.length % colors.length
        const newPlayer = {
          id: Date.now().toString(),
          name: nickName,
          color: colors[colorIndex],
          fromContact: true,
          avatar: avatarUrl || '',
          isContact: true
        }

        const updatedPlayers = [...players, newPlayer]
        wx.setStorageSync('tempPlayers', updatedPlayers)
        this.setData({ players: updatedPlayers })
        wx.showToast({ title: '添加成功', icon: 'success' })
      },
      fail: () => {
        // 延迟执行避免微信内部错误 Cannot read property '__subPageFrameEndTime__' of null
        setTimeout(() => {
          wx.showToast({ title: '取消添加', icon: 'none' })
        }, 100)
      }
    })
  },

  // 输入框变化
  onNameInput(e) {
    this.setData({ newPlayerName: e.detail.value })
  },

  // 确认添加球员
  confirmAddPlayer() {
    const { newPlayerName } = this.data

    if (!newPlayerName.trim()) {
      wx.showToast({ title: '请输入姓名', icon: 'none' })
      return
    }

    if (this.data.players.some(p => p.name === newPlayerName.trim())) {
      wx.showToast({ title: '该球员已在列表中', icon: 'none' })
      return
    }

    this.addPlayer(newPlayerName.trim(), false)
    this.setData({ newPlayerName: '' })
  },

  // 添加球员
  addPlayer(name, fromContact) {
    const { players, colors } = this.data

    const colorIndex = players.length % colors.length

    const newPlayer = {
      id: Date.now().toString(),
      name: name,
      color: colors[colorIndex],
      fromContact: fromContact,
      avatar: ''
    }

    const updatedPlayers = [...players, newPlayer]
    wx.setStorageSync('tempPlayers', updatedPlayers)

    this.setData({ players: updatedPlayers })
    wx.showToast({ title: '添加成功', icon: 'success' })
  },

  // 添加分享邀请人到球员列表（对方分享给你，你打开后自动添加对方）
  addSharedInviter(nickName, avatar) {
    const { players, colors } = this.data
    console.log('addSharedInviter 被调用:', { nickName, avatar, players: players.map(p => p.name) })

    // 检查是否已添加
    if (players.some(p => p.name === nickName)) {
      console.log(`分享者 ${nickName} 已在列表中，跳过`)
      return
    }

    const colorIndex = players.length % colors.length
    const newPlayer = {
      id: 'share-' + Date.now().toString(),
      name: nickName,
      color: colors[colorIndex],
      fromContact: true,
      avatar: avatar || '',
      isShared: true
    }

    const updatedPlayers = [...players, newPlayer]
    wx.setStorageSync('tempPlayers', updatedPlayers)
    this.setData({ players: updatedPlayers })
    console.log(`已自动添加分享者 "${nickName}" 到球员列表`)
  },

  // 移除球员
  removePlayer(e) {
    const index = e.currentTarget.dataset.index
    const players = this.data.players.filter((_, i) => i !== index)
    wx.setStorageSync('tempPlayers', players)
    this.setData({ players })
  },

  // 上一步
  goBack() {
    wx.navigateBack()
  },

  // 下一步
  goNext() {
    if (this.data.players.length === 0) {
      wx.showToast({ title: '请至少添加一名球员', icon: 'none' })
      return
    }

    // 如果只有1名球员，直接默认比杆模式开始比赛，跳过模式选择
    if (this.data.players.length === 1) {
      this.startSinglePlayerGame()
      return
    }

    wx.navigateTo({
      url: '/pages/new-game/step3-mode/step3-mode'
    })
  },

  // 单人比赛直接开始
  startSinglePlayerGame() {
    const { currentCourse, players } = this.data

    // 检查球场数据是否需要验证
    const verifiedCourses = wx.getStorageSync('verifiedCourses') || []
    const isCourseVerified = verifiedCourses.includes(currentCourse.id)

    if (!isCourseVerified && currentCourse.needsVerification) {
      // 显示请求验证弹窗
      wx.showModal({
        title: '球场数据待验证',
        content: '该球场的数据尚未经过人工核对，可能存在偏差。为了确保计分准确，建议您拍摄一张球场纸质记分卡，AI将自动解析出每洞的标准杆和距离数据。',
        confirmText: '拍摄记分卡',
        cancelText: '使用现有数据',
        success: (res) => {
          if (res.confirm) {
            wx.showToast({ title: '开发中，使用现有数据', icon: 'none' })
            this.doStartSinglePlayerGame()
          } else {
            this.doStartSinglePlayerGame()
          }
        }
      })
      return
    }

    this.doStartSinglePlayerGame()
  },

  // 执行比赛开始逻辑（创建云端多人同步比赛）
  doStartSinglePlayerGame() {
    const { currentCourse, players } = this.data
    const userInfo = wx.getStorageSync('userInfo') || {}

    wx.showLoading({ title: '创建比赛...' })

    // 给每个球员加上openid（当前用户就是创建者）
    const playersWithOpenid = players.map(p => {
      // 如果是当前用户，加上openid
      if (p.isMe) {
        return {
          ...p,
          openid: userInfo.openid || '',
          isCreator: true
        }
      }
      return p
    })

    // 调用云函数创建比赛
    wx.cloud.callFunction({
      name: 'createGame',
      data: {
        courseId: currentCourse.id,
        courseName: currentCourse.name,
        players: playersWithOpenid,
        gameMode: 'stroke'
      },
      success: (res) => {
        wx.hideLoading()
        if (res.result.success) {
          const gameId = res.result.gameId
          console.log('比赛创建成功，gameId:', gameId)

          // 清理临时数据
          wx.removeStorageSync('tempPlayers')
          wx.setStorageSync('players', players)

          wx.showToast({
            title: '比赛开始！',
            icon: 'success',
            success: () => {
              setTimeout(() => {
                // 跳转到记分卡，带gameId参数打开多人同步模式
                wx.redirectTo({
                  url: `/pages/scorecard/scorecard?gameId=${gameId}`
                })
              }, 1500)
            }
          })
        } else {
          console.error('创建比赛失败:', res.result.error)
          wx.showToast({ title: '创建比赛失败: ' + res.result.error, icon: 'none' })
        }
      },
      fail: (err) => {
        wx.hideLoading()
        console.error('创建比赛调用失败:', err)
        wx.showToast({ title: '创建比赛失败，请重试', icon: 'none' })
      }
    })
  }
})
