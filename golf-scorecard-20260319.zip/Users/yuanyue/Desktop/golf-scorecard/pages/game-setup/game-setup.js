const app = getApp()

// 开发模式开关 - 在模拟器中使用模拟数据
const DEV_MODE = false

Page({
  data: {
    currentCourse: null,
    totalPar: 0,
    totalDistance: 0,
    players: [],
    showAddPlayer: false,
    newPlayerName: '',
    newPlayerHandicap: '',
    selectedColor: '#2c8f4e',
    gameId: '',
    colors: ['#2c8f4e', '#2196f3', '#ff9800', '#f44336', '#9c27b0', '#00bcd4', '#795548', '#607d8b']
  },

  onLoad(options) {
    // 生成比赛唯一ID
    const gameId = 'game_' + Date.now()

    // 加载当前球场
    const currentCourseId = wx.getStorageSync('currentCourseId')
    const courses = wx.getStorageSync('courses') || []
    const currentCourse = courses.find(c => c.id === currentCourseId) || courses[0]

    if (currentCourse) {
      currentCourse.totalPar = currentCourse.holes.reduce((sum, h) => sum + h.par, 0)
      currentCourse.totalDistance = currentCourse.holes.reduce((sum, h) => sum + (h.distance || 0), 0)
    }

    // 获取已保存的球员（从本地存储或分享参数）
    const savedPlayers = wx.getStorageSync('tempPlayers') || []

    this.setData({
      gameId,
      currentCourse,
      totalPar: currentCourse?.totalPar || 0,
      totalDistance: currentCourse?.totalDistance || 0,
      players: savedPlayers
    })

    // 检查是否是受邀加入
    if (options.gameId) {
      this.handleInvite(options)
    }
  },

  onShow() {
    // 刷新球员列表
    const savedPlayers = wx.getStorageSync('tempPlayers') || []
    this.setData({ players: savedPlayers })

    // 设置TabBar选中状态 - 开始比赛页面选中GO按钮
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 4 })
    }
  },

  // 分享给好友
  onShareAppMessage() {
    const { gameId, currentCourse, players } = this.data

    // 保存当前比赛信息到存储
    wx.setStorageSync('tempGameId', gameId)
    wx.setStorageSync('tempPlayers', players)

    return {
      title: `邀请你加入${currentCourse.name}的比赛`,
      path: `/pages/game-setup/game-setup?gameId=${gameId}&course=${currentCourse.id}`,
      imageUrl: '', // 可以生成一张分享图
      desc: `${players.length}人已加入，点击加入比赛`
    }
  },

  // 分享到朋友圈
  onShareTimeline() {
    const { gameId, currentCourse, players } = this.data

    return {
      title: `邀请你加入${currentCourse.name}的高尔夫比赛`,
      query: `gameId=${gameId}&course=${currentCourse.id}`,
      imageUrl: ''
    }
  },

  // 处理邀请链接
  handleInvite(options) {
    const { gameId } = options

    // 获取发起人的球员信息
    const inviterPlayers = wx.getStorageSync('tempPlayers') || []

    wx.showModal({
      title: '加入比赛',
      content: `是否加入这场在${this.data.currentCourse?.name}进行的比赛？`,
      success: (res) => {
        if (res.confirm) {
          // 获取当前用户信息
          wx.getUserProfile({
            desc: '用于显示球员名称',
            success: (userRes) => {
              const newPlayer = {
                id: Date.now().toString(),
                name: userRes.userInfo.nickName || '微信用户',
                avatar: userRes.userInfo.avatarUrl,
                color: this.data.colors[Math.floor(Math.random() * this.data.colors.length)],
                handicap: null,
                isInvited: true
              }

              const players = [...inviterPlayers, newPlayer]
              wx.setStorageSync('tempPlayers', players)

              this.setData({ players })
              wx.showToast({ title: '加入成功', icon: 'success' })
            },
            fail: () => {
              // 用户拒绝授权，手动输入名称
              this.promptForName()
            }
          })
        }
      }
    })
  },

  // 提示手动输入名称
  promptForName() {
    wx.showModal({
      title: '输入姓名',
      editable: true,
      placeholderText: '请输入您的姓名',
      success: (res) => {
        if (res.confirm && res.content) {
          const newPlayer = {
            id: Date.now().toString(),
            name: res.content,
            color: this.data.colors[Math.floor(Math.random() * this.data.colors.length)],
            handicap: null,
            isInvited: true
          }

          const players = [...this.data.players, newPlayer]
          wx.setStorageSync('tempPlayers', players)
          this.setData({ players })
        }
      }
    })
  },

  // 添加球员 - 默认从微信好友选择
  addPlayer() {
    this.chooseContact()
  },

  // 选择微信好友
  chooseContact() {
    // 开发模式：模拟选择联系人
    if (DEV_MODE) {
      wx.showActionSheet({
        itemList: ['测试好友-张三', '测试好友-李四', '测试好友-王五', '取消'],
        success: (res) => {
          if (res.tapIndex === 3) return // 取消

          const mockNames = ['张三', '李四', '王五']
          const displayName = mockNames[res.tapIndex]

          // 自动添加好友为球员
          const { players, colors } = this.data

          // 检查是否已存在同名的球员
          if (players.some(p => p.name === displayName)) {
            wx.showToast({ title: '该好友已在列表中', icon: 'none' })
            return
          }

          const newPlayer = {
            id: Date.now().toString(),
            name: displayName,
            handicap: null,
            color: colors[Math.floor(Math.random() * colors.length)],
            avatar: '',
            isInvited: false,
            fromContact: true
          }

          const updatedPlayers = [...players, newPlayer]
          wx.setStorageSync('tempPlayers', updatedPlayers)

          this.setData({ players: updatedPlayers })
          wx.showToast({ title: '添加成功', icon: 'success' })
        }
      })
      return
    }

    // 真实环境调用
    wx.chooseContact({
      success: (res) => {
        const { displayName, photoFilePath } = res
        const { players, colors } = this.data

        if (players.some(p => p.name === displayName)) {
          wx.showToast({ title: '该好友已在列表中', icon: 'none' })
          return
        }

        const newPlayer = {
          id: Date.now().toString(),
          name: displayName,
          handicap: null,
          color: colors[Math.floor(Math.random() * colors.length)],
          avatar: photoFilePath || '',
          isInvited: false,
          fromContact: true
        }

        const updatedPlayers = [...players, newPlayer]
        wx.setStorageSync('tempPlayers', updatedPlayers)

        this.setData({ players: updatedPlayers })
        wx.showToast({ title: '添加成功', icon: 'success' })
      },
      fail: (err) => {
        console.log('选择联系人失败:', err)
        wx.showToast({ title: '请使用下方手动输入', icon: 'none' })
      }
    })
  },

  // 显示手动添加表单
  showManualAddForm() {
    this.setData({
      showAddPlayer: true,
      selectedColor: this.data.colors[0],
      newPlayerName: '',
      newPlayerHandicap: ''
    })
  },

  // 取消添加球员
  cancelAddPlayer() {
    this.setData({ showAddPlayer: false })
  },

  // 输入姓名
  onNameInput(e) {
    this.setData({ newPlayerName: e.detail.value })
  },

  // 输入差点
  onHandicapInput(e) {
    this.setData({ newPlayerHandicap: e.detail.value })
  },

  // 选择颜色
  selectColor(e) {
    this.setData({ selectedColor: e.currentTarget.dataset.color })
  },

  // 确认添加球员（简化版，自动选择颜色）
  confirmAddPlayer() {
    const { newPlayerName, players, colors } = this.data

    if (!newPlayerName.trim()) {
      wx.showToast({ title: '请输入姓名', icon: 'none' })
      return
    }

    // 自动分配一个颜色（循环使用）
    const colorIndex = players.length % colors.length

    const newPlayer = {
      id: Date.now().toString(),
      name: newPlayerName.trim(),
      handicap: null,
      color: colors[colorIndex],
      isInvited: false
    }

    const updatedPlayers = [...players, newPlayer]
    wx.setStorageSync('tempPlayers', updatedPlayers)

    this.setData({
      players: updatedPlayers,
      newPlayerName: ''
    })

    wx.showToast({ title: '添加成功', icon: 'success' })
  },

  // 移除球员
  removePlayer(e) {
    const index = e.currentTarget.dataset.index
    const players = this.data.players.filter((_, i) => i !== index)
    wx.setStorageSync('tempPlayers', players)
    this.setData({ players })
  },

  // 分享到好友
  shareToFriend() {
    if (this.data.players.length === 0) {
      wx.showToast({ title: '请先添加至少一名球员', icon: 'none' })
      return
    }

    // 触发分享
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage']
    })
  },

  // 分享到群
  shareToGroup() {
    if (this.data.players.length === 0) {
      wx.showToast({ title: '请先添加至少一名球员', icon: 'none' })
      return
    }

    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage']
    })
  },

  // 开始比赛
  startGame() {
    const { currentCourse, players } = this.data

    if (players.length === 0) {
      wx.showToast({ title: '请至少添加一名球员', icon: 'none' })
      return
    }

    // 保存球员到正式存储
    wx.setStorageSync('players', players)

    // 清理临时数据
    wx.removeStorageSync('tempPlayers')

    // 初始化比赛
    const game = {
      id: Date.now().toString(),
      courseId: currentCourse.id,
      courseName: currentCourse.name,
      players: players,
      holes: currentCourse.holes,
      scores: {},
      timestamp: Date.now(),
      completed: false
    }

    players.forEach(player => {
      game.scores[player.id] = {}
    })

    wx.setStorageSync('currentGame', game)

    wx.showToast({
      title: '比赛开始！',
      icon: 'success',
      success: () => {
        setTimeout(() => {
          wx.switchTab({
            url: '/pages/scorecard/scorecard'
          })
        }, 1500)
      }
    })
  }
})