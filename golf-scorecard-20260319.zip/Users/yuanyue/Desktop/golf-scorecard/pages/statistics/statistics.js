Page({
  data: {
    hasData: false,
    totalStats: {},
    scoreDistribution: {},
    weakPoints: [],
    recentTrend: [],
    bestCourses: [],
    radarData: {
      drive: 60,
      approach: 50,
      putting: 70,
      short: 55,
      stable: 65
    }
  },

  onLoad() {
    wx.setNavigationBarTitle({ title: '技术统计' })

    // 开发模式自动注入模拟数据
    const isDev = false // 开发模式开关，上线时改为false
    if (isDev) {
      const existingGames = wx.getStorageSync('games') || []
      if (existingGames.length === 0) {
        // 生成3场模拟比赛数据
        const mockGames = [
          // 第一场：成绩稍差
          {
            id: 'mock-game-1',
            courseId: 'china-1',
            courseName: '北京华彬高尔夫俱乐部',
            timestamp: Date.now() - 86400000 * 10, // 10天前
            completed: true,
            players: [{ id: 'player-1', name: '我', color: '#2c8f4e' }],
            scores: {
              'player-1': {
                1: 5, 2: 6, 3: 4, 4: 5, 5: 4, 6: 5, 7: 6, 8: 4, 9: 5,
                10: 5, 11: 6, 12: 4, 13: 5, 14: 4, 15: 6, 16: 5, 17: 4, 18: 5
              }
            },
            putts: {
              'player-1': {
                1: 2, 2: 3, 3: 2, 4: 2, 5: 1, 6: 2, 7: 3, 8: 2, 9: 2,
                10: 2, 11: 3, 12: 2, 13: 2, 14: 1, 15: 3, 16: 2, 17: 2, 18: 2
              }
            },
            fairways: {
              'player-1': { 1: true, 2: false, 3: true, 4: false, 5: true, 6: false, 7: false, 8: true, 9: true, 10: false, 11: false, 12: true, 13: false, 14: true, 15: false, 16: true, 17: false, 18: true }
            },
            statistics: {
              'player-1': {
                totalScore: 94,
                toPar: 22,
                eagles: 0,
                birdies: 1,
                pars: 5,
                bogeys: 8,
                doubleBogeys: 4,
                others: 0,
                holesPlayed: 18
              }
            }
          },
          // 第二场：中等成绩
          {
            id: 'mock-game-2',
            courseId: 'china-2',
            courseName: '上海佘山国际高尔夫俱乐部',
            timestamp: Date.now() - 86400000 * 5, // 5天前
            completed: true,
            players: [{ id: 'player-1', name: '我', color: '#2c8f4e' }],
            scores: {
              'player-1': {
                1: 4, 2: 5, 3: 4, 4: 4, 5: 3, 6: 5, 7: 5, 8: 4, 9: 5,
                10: 4, 11: 5, 12: 4, 13: 4, 14: 3, 15: 5, 16: 4, 17: 5, 18: 4
              }
            },
            putts: {
              'player-1': {
                1: 2, 2: 2, 3: 2, 4: 1, 5: 1, 6: 2, 7: 2, 8: 2, 9: 2,
                10: 2, 11: 2, 12: 2, 13: 1, 14: 1, 15: 2, 16: 2, 17: 2, 18: 2
              }
            },
            fairways: {
              'player-1': { 1: true, 2: true, 3: true, 4: false, 5: true, 6: false, 7: true, 8: true, 9: false, 10: true, 11: true, 12: false, 13: true, 14: true, 15: false, 16: true, 17: true, 18: false }
            },
            statistics: {
              'player-1': {
                totalScore: 82,
                toPar: 10,
                eagles: 0,
                birdies: 2,
                pars: 10,
                bogeys: 5,
                doubleBogeys: 1,
                others: 0,
                holesPlayed: 18
              }
            }
          },
          // 第三场：最好成绩
          {
            id: 'mock-game-3',
            courseId: 'china-3',
            courseName: '深圳观澜湖高尔夫球会',
            timestamp: Date.now() - 86400000 * 1, // 1天前
            completed: true,
            players: [{ id: 'player-1', name: '我', color: '#2c8f4e' }],
            scores: {
              'player-1': {
                1: 4, 2: 4, 3: 3, 4: 4, 5: 3, 6: 4, 7: 5, 8: 3, 9: 4,
                10: 4, 11: 4, 12: 3, 13: 4, 14: 4, 15: 3, 16: 5, 17: 4, 18: 3
              }
            },
            putts: {
              'player-1': {
                1: 2, 2: 1, 3: 1, 4: 2, 5: 1, 6: 2, 7: 2, 8: 1, 9: 2,
                10: 2, 11: 1, 12: 1, 13: 2, 14: 2, 15: 1, 16: 2, 17: 2, 18: 1
              }
            },
            fairways: {
              'player-1': { 1: true, 2: true, 3: true, 4: true, 5: true, 6: false, 7: true, 8: true, 9: true, 10: true, 11: true, 12: true, 13: false, 14: true, 15: true, 16: false, 17: true, 18: true }
            },
            statistics: {
              'player-1': {
                totalScore: 76,
                toPar: 4,
                eagles: 0,
                birdies: 6,
                pars: 10,
                bogeys: 2,
                doubleBogeys: 0,
                others: 0,
                holesPlayed: 18
              }
            }
          }
        ]
        wx.setStorageSync('games', mockGames)
        wx.showToast({ title: '模拟数据已加载', icon: 'success' })
      }
    }

    this.calculateStatistics()
  },

  onShow() {
    // 开发模式自动注入模拟数据
    const isDev = false // 开发模式开关，上线时改为false
    const forceRefreshMockData = false // 临时强制刷新模拟数据，用完改为false
    if (isDev) {
      const existingGames = wx.getStorageSync('games') || []
      if (existingGames.length === 0 || forceRefreshMockData) {
        // 生成3场模拟比赛数据
        const mockGames = [
          // 第一场：成绩稍差
          {
            id: 'mock-game-1',
            courseId: 'china-1',
            courseName: '北京华彬高尔夫俱乐部',
            timestamp: Date.now() - 86400000 * 10, // 10天前
            completed: true,
            players: [{ id: 'player-1', name: '我', color: '#2c8f4e' }],
            scores: {
              'player-1': {
                1: 5, 2: 6, 3: 4, 4: 5, 5: 4, 6: 5, 7: 6, 8: 4, 9: 5,
                10: 5, 11: 6, 12: 4, 13: 5, 14: 4, 15: 6, 16: 5, 17: 4, 18: 5
              }
            },
            putts: {
              'player-1': {
                1: 2, 2: 3, 3: 2, 4: 2, 5: 1, 6: 2, 7: 3, 8: 2, 9: 2,
                10: 2, 11: 3, 12: 2, 13: 2, 14: 1, 15: 3, 16: 2, 17: 2, 18: 2
              }
            },
            fairways: {
              'player-1': { 1: true, 2: false, 3: true, 4: false, 5: true, 6: false, 7: false, 8: true, 9: true, 10: false, 11: false, 12: true, 13: false, 14: true, 15: false, 16: true, 17: false, 18: true }
            },
            statistics: {
              'player-1': {
                totalScore: 94,
                toPar: 22,
                eagles: 0,
                birdies: 1,
                pars: 5,
                bogeys: 8,
                doubleBogeys: 4,
                others: 0,
                holesPlayed: 18
              }
            }
          },
          // 第二场：中等成绩
          {
            id: 'mock-game-2',
            courseId: 'china-2',
            courseName: '上海佘山国际高尔夫俱乐部',
            timestamp: Date.now() - 86400000 * 5, // 5天前
            completed: true,
            players: [{ id: 'player-1', name: '我', color: '#2c8f4e' }],
            scores: {
              'player-1': {
                1: 4, 2: 5, 3: 4, 4: 4, 5: 3, 6: 5, 7: 5, 8: 4, 9: 5,
                10: 4, 11: 5, 12: 4, 13: 4, 14: 3, 15: 5, 16: 4, 17: 5, 18: 4
              }
            },
            putts: {
              'player-1': {
                1: 2, 2: 2, 3: 2, 4: 1, 5: 1, 6: 2, 7: 2, 8: 2, 9: 2,
                10: 2, 11: 2, 12: 2, 13: 1, 14: 1, 15: 2, 16: 2, 17: 2, 18: 2
              }
            },
            fairways: {
              'player-1': { 1: true, 2: true, 3: true, 4: false, 5: true, 6: false, 7: true, 8: true, 9: false, 10: true, 11: true, 12: false, 13: true, 14: true, 15: false, 16: true, 17: true, 18: false }
            },
            statistics: {
              'player-1': {
                totalScore: 82,
                toPar: 10,
                eagles: 0,
                birdies: 2,
                pars: 10,
                bogeys: 5,
                doubleBogeys: 1,
                others: 0,
                holesPlayed: 18
              }
            }
          },
          // 第三场：最好成绩
          {
            id: 'mock-game-3',
            courseId: 'china-3',
            courseName: '深圳观澜湖高尔夫球会',
            timestamp: Date.now() - 86400000 * 1, // 1天前
            completed: true,
            players: [{ id: 'player-1', name: '我', color: '#2c8f4e' }],
            scores: {
              'player-1': {
                1: 4, 2: 4, 3: 3, 4: 4, 5: 3, 6: 4, 7: 5, 8: 3, 9: 4,
                10: 4, 11: 4, 12: 3, 13: 4, 14: 4, 15: 3, 16: 5, 17: 4, 18: 3
              }
            },
            putts: {
              'player-1': {
                1: 2, 2: 1, 3: 1, 4: 2, 5: 1, 6: 2, 7: 2, 8: 1, 9: 2,
                10: 2, 11: 1, 12: 1, 13: 2, 14: 2, 15: 1, 16: 2, 17: 2, 18: 1
              }
            },
            fairways: {
              'player-1': { 1: true, 2: true, 3: true, 4: true, 5: true, 6: false, 7: true, 8: true, 9: true, 10: true, 11: true, 12: true, 13: false, 14: true, 15: true, 16: false, 17: true, 18: true }
            },
            statistics: {
              'player-1': {
                totalScore: 76,
                toPar: 4,
                eagles: 0,
                birdies: 6,
                pars: 10,
                bogeys: 2,
                doubleBogeys: 0,
                others: 0,
                holesPlayed: 18
              }
            }
          }
        ]
        wx.setStorageSync('games', mockGames)
        wx.showToast({ title: '模拟数据已加载', icon: 'success' })
      }
    }

    this.calculateStatistics()
  },

  calculateStatistics() {
    const games = wx.getStorageSync('games') || []
    // 只统计已完成且打满18洞的比赛
    const completedGames = games.filter(g => {
      if (!g.completed) return false

      // 检查当前用户是否完成全部18洞
      const player = g.players?.find(p => p.isMe) || g.players?.[0]
      if (!player) return false

      // 新格式：player.scores数组
      if (player.scores && Array.isArray(player.scores)) {
        const validScores = player.scores.filter(s => s.strokes > 0)
        return validScores.length >= 18
      }
      // 旧格式：game.scores对象
      else if (g.scores && g.scores[player.id]) {
        const scores = g.scores[player.id]
        const validCount = Object.values(scores).filter(v => v > 0).length
        return validCount >= 18
      }
      // 兼容有statistics字段的情况
      else if (g.statistics && g.statistics[player.id]) {
        return g.statistics[player.id].holesPlayed >= 18
      }

      return false
    })

    if (completedGames.length < 1) {
      this.setData({ hasData: false })
      return
    }

    // 1. 计算总体统计
    const totalStats = this.calculateTotalStats(completedGames)

    // 2. 计算成绩分布
    const scoreDistribution = this.calculateScoreDistribution(completedGames)

    // 3. 分析技术短板
    const weakPoints = this.analyzeWeakPoints(completedGames, totalStats)

    // 4. 最近10轮趋势
    const { points: recentTrend, linePath: trendLinePath } = this.getRecentTrend(completedGames)

    // 5. 最佳球场排名
    const bestCourses = this.getBestCourses(completedGames)

    // 计算雷达图数据
    const radarData = this.calculateRadarData(weakPoints, totalStats)

    this.setData({
      hasData: true,
      totalStats,
      scoreDistribution,
      weakPoints,
      recentTrend,
      trendLinePath,
      bestCourses,
      radarData
    })
  },

  // 计算总体统计
  calculateTotalStats(games) {
    let totalHoles = 0
    let totalScore = 0
    let totalToPar = 0
    let bestScore = Infinity
    let totalFairways = 0
    let totalFairwayAttempts = 0
    let totalGirs = 0
    let totalPutts = 0

    games.forEach(game => {
      const playerId = this.getCurrentPlayerId(game)
      if (!playerId) return

      const stats = game.statistics?.[playerId]
      if (!stats) return

      totalHoles += stats.holesPlayed || 18
      totalScore += stats.totalScore
      totalToPar += stats.toPar
      if (stats.totalScore < bestScore) bestScore = stats.totalScore

      // 计算开球上球道率
      if (game.fairways && game.fairways[playerId]) {
        const fairways = game.fairways[playerId]
        Object.values(fairways).forEach(fairway => {
          totalFairwayAttempts++
          if (fairway) totalFairways++
        })
      }

      // 计算标准杆上果岭率（简化版：杆数 <= par 视为上果岭，兼容无球场数据场景）
      if (game.scores && game.scores[playerId]) {
        const scores = game.scores[playerId]
        Object.values(scores).forEach(score => {
          if (score && score <= 4) { // 简化逻辑：大部分洞par为4，杆数<=4视为上果岭
            totalGirs++
          }
        })
      }

      // 计算总推杆数
      if (game.putts && game.putts[playerId]) {
        const putts = game.putts[playerId]
        Object.values(putts).forEach(putt => {
          totalPutts += putt || 0
        })
      }
    })

    const rounds = games.length
    const avgScore = rounds > 0 ? (totalScore / rounds).toFixed(1) : '-'
    const avgToPar = rounds > 0 ? (totalToPar / rounds).toFixed(1) : '-'
    const fairwayRate = totalFairwayAttempts > 0 ? Math.round(totalFairways / totalFairwayAttempts * 100) : 0
    const girRate = totalHoles > 0 ? Math.round(totalGirs / totalHoles * 100) : 0
    const avgPutts = totalHoles > 0 ? (totalPutts / totalHoles).toFixed(1) : '-'

    // 平均分颜色
    let avgScoreClass = 'over'
    if (parseFloat(avgScore) <= 72) avgScoreClass = 'under'
    else if (parseFloat(avgScore) <= 80) avgScoreClass = 'par'

    let avgToParClass = 'over'
    if (parseFloat(avgToPar) <= 0) avgToParClass = 'under'
    else if (parseFloat(avgToPar) <= 8) avgToParClass = 'par'

    return {
      games: games.length,
      rounds: rounds,
      holes: totalHoles,
      avgScore,
      avgScoreClass,
      avgToPar: parseFloat(avgToPar) > 0 ? `+${avgToPar}` : avgToPar,
      avgToParClass,
      bestScore: bestScore === Infinity ? '-' : bestScore,
      fairwayRate,
      girRate,
      avgPutts
    }
  },

  // 计算成绩分布
  calculateScoreDistribution(games) {
    let eagles = 0
    let birdies = 0
    let pars = 0
    let bogeys = 0
    let doubleBogeys = 0
    let others = 0
    let totalHoles = 0

    games.forEach(game => {
      const playerId = this.getCurrentPlayerId(game)
      if (!playerId || !game.scores || !game.scores[playerId]) return

      const scores = game.scores[playerId]
      // 简化逻辑：默认par为4，不依赖球场数据
      Object.values(scores).forEach(score => {
        if (!score) return

        totalHoles++
        const diff = score - 4 // 默认标准杆为4

        if (diff <= -2) eagles++
        else if (diff === -1) birdies++
        else if (diff === 0) pars++
        else if (diff === 1) bogeys++
        else if (diff === 2) doubleBogeys++
        else others++
      })
    })

    const total = totalHoles || 1
    // 精确计算百分比，确保总和为100%
    const eaglePct = (eagles / total) * 100
    const birdiePct = (birdies / total) * 100
    const parPct = (pars / total) * 100
    const bogeyPct = (bogeys / total) * 100
    const doublePct = ((doubleBogeys + others) / total) * 100

    // 修正四舍五入误差，调整最大项
    const pcts = [eaglePct, birdiePct, parPct, bogeyPct, doublePct]
    const sum = pcts.reduce((a, b) => a + b, 0)
    const diff = 100 - sum
    const maxIndex = pcts.indexOf(Math.max(...pcts))
    pcts[maxIndex] += diff

    return {
      eagles,
      birdies,
      pars,
      bogeys,
      doubleBogeys,
      others,
      eaglePct: parseFloat(pcts[0].toFixed(1)),
      birdiePct: parseFloat(pcts[1].toFixed(1)),
      parPct: parseFloat(pcts[2].toFixed(1)),
      bogeyPct: parseFloat(pcts[3].toFixed(1)),
      doublePct: parseFloat(pcts[4].toFixed(1))
    }
  },

  // 分析技术短板
  analyzeWeakPoints(games, totalStats) {
    const points = []

    // 开球分析
    const fairwayRate = totalStats.fairwayRate || 0
    if (fairwayRate < 40) {
      points.push({
        type: 'drive',
        icon: '🏌️',
        title: '开球稳定性待提升',
        desc: `开球上球道率仅 ${fairwayRate}%，建议加强一号木精准度练习`,
        score: Math.max(30, fairwayRate * 0.7),
        level: 'low'
      })
    } else if (fairwayRate < 60) {
      points.push({
        type: 'drive',
        icon: '🏌️',
        title: '开球表现中等',
        desc: `开球上球道率 ${fairwayRate}%，还有提升空间`,
        score: 50 + fairwayRate * 0.5,
        level: 'medium'
      })
    } else {
      points.push({
        type: 'drive',
        icon: '🏌️',
        title: '开球表现优秀',
        desc: `开球上球道率 ${fairwayRate}%，稳定性很好`,
        score: 80 + Math.min(20, (fairwayRate - 60) * 0.5),
        level: 'high'
      })
    }

    // 攻果岭分析
    const girRate = totalStats.girRate || 0
    if (girRate < 30) {
      points.push({
        type: 'approach',
        icon: '🎯',
        title: '攻果岭准确率偏低',
        desc: `标准杆上果岭率仅 ${girRate}%，建议加强铁杆精准度练习`,
        score: Math.max(30, girRate * 0.8),
        level: 'low'
      })
    } else if (girRate < 50) {
      points.push({
        type: 'approach',
        icon: '🎯',
        title: '攻果岭表现中等',
        desc: `标准杆上果岭率 ${girRate}%，多练习100码内切杆`,
        score: 50 + girRate * 0.5,
        level: 'medium'
      })
    } else {
      points.push({
        type: 'approach',
        icon: '🎯',
        title: '攻果岭表现优秀',
        desc: `标准杆上果岭率 ${girRate}%，攻杆非常稳定`,
        score: 80 + Math.min(20, (girRate - 50) * 0.4),
        level: 'high'
      })
    }

    // 推杆分析
    const avgPutts = parseFloat(totalStats.avgPutts) || 2.5
    if (avgPutts > 2.0) {
      points.push({
        type: 'putting',
        icon: '⛳',
        title: '推杆有较大提升空间',
        desc: `平均每洞推杆 ${avgPutts} 次，建议多练习短推`,
        score: Math.max(30, 100 - (avgPutts - 1.5) * 60),
        level: 'low'
      })
    } else if (avgPutts > 1.8) {
      points.push({
        type: 'putting',
        icon: '⛳',
        title: '推杆表现中等',
        desc: `平均每洞推杆 ${avgPutts} 次，多练习3码内推击`,
        score: 60 + Math.min(20, (2.0 - avgPutts) * 100),
        level: 'medium'
      })
    } else {
      points.push({
        type: 'putting',
        icon: '⛳',
        title: '推杆表现优秀',
        desc: `平均每洞推杆 ${avgPutts} 次，推杆很稳定`,
        score: 80 + Math.min(20, (1.8 - avgPutts) * 100),
        level: 'high'
      })
    }

    // 按得分排序
    return points.sort((a, b) => a.score - b.score)
  },

  // 获取最近10轮趋势
  getRecentTrend(games) {
    const recentGames = games.slice(-10) // 取最新10轮，顺序从早到晚，最新的在数组最后
    if (recentGames.length === 0) return { points: [], linePath: 'polygon(0% 0%, 0% 0%, 0% 0%, 0% 0%)' }

    // 计算分数范围，用于映射到y坐标
    const scores = recentGames.map(g => {
      const playerId = this.getCurrentPlayerId(g)
      return g.statistics?.[playerId]?.totalScore || 0
    })
    const minScore = Math.min(...scores)
    const maxScore = Math.max(...scores)
    const scoreRange = maxScore - minScore || 1 // 防止除以0

    const points = recentGames.map((game, index) => {
      const playerId = this.getCurrentPlayerId(game)
      const toPar = game.statistics?.[playerId]?.toPar || 0
      const totalScore = game.statistics?.[playerId]?.totalScore || 0
      const date = new Date(game.timestamp)
      const dateStr = `${date.getMonth() + 1}/${date.getDate()}`

      // 计算前一轮的成绩，第一项和自己比较
      let preToPar = toPar
      if (index > 0) {
        const preGame = recentGames[index - 1]
        const prePlayerId = this.getCurrentPlayerId(preGame)
        preToPar = preGame.statistics?.[prePlayerId]?.toPar || toPar
      }

      let toParDisplay = 'E'
      if (toPar > 0) toParDisplay = `+${toPar}`
      else if (toPar < 0) toParDisplay = toPar.toString()

      // 计算y坐标：分数越小越靠上，范围10% - 90%
      const y = 90 - ((totalScore - minScore) / scoreRange) * 80

      return {
        round: index + 1,
        date: dateStr,
        totalScore,
        toPar,
        toParDisplay,
        preToPar,
        y
      }
    })

    // 生成折线路径字符串（WXML直接使用，避免角度计算问题）
    const pointCount = points.length
    const stepX = 80 / (pointCount - 1 || 1) // 左右各留10%边距，居中显示
    const pathPoints = []
    const bottomPoints = []

    points.forEach((point, index) => {
      const x = 10 + index * stepX // 从10%开始，到90%结束，居中
      const y = point.y
      pathPoints.push(`${x}% ${y}%`)
      bottomPoints.push(`${x}% ${y + 1}%`) // 折线厚度1%
    })

    // 生成闭合多边形路径，正确连接所有点
    const linePath = `polygon(${pathPoints.join(', ')}, ${bottomPoints.reverse().join(', ')})`

    // 更新点的x坐标用于点定位
    points.forEach((point, index) => {
      point.x = 10 + index * stepX
    })

    return { points, linePath }
  },

  // 获取最佳球场排名
  getBestCourses(games) {
    const courseMap = {}

    games.forEach(game => {
      const playerId = this.getCurrentPlayerId(game)
      if (!playerId || !game.statistics?.[playerId]) return

      const stats = game.statistics[playerId]
      if (!courseMap[game.courseId]) {
        courseMap[game.courseId] = {
          courseId: game.courseId,
          courseName: game.courseName,
          playCount: 0,
          bestScore: Infinity,
          bestToPar: Infinity
        }
      }

      const course = courseMap[game.courseId]
      course.playCount++
      if (stats.totalScore < course.bestScore) {
        course.bestScore = stats.totalScore
        course.bestToPar = stats.toPar
      }
    })

    // 转换为数组并按最佳成绩排序
    const courseList = Object.values(courseMap).sort((a, b) => a.bestScore - b.bestScore).slice(0, 5)

    // 格式化显示
    return courseList.map(course => {
      let toParDisplay = 'E'
      if (course.bestToPar > 0) toParDisplay = `+${course.bestToPar}`
      else if (course.bestToPar < 0) toParDisplay = course.bestToPar.toString()

      return {
        ...course,
        toParDisplay
      }
    })
  },

  // 获取当前玩家ID（取第一个玩家作为"我"）
  getCurrentPlayerId(game) {
    if (!game.players || game.players.length === 0) return null
    // 默认取第一个玩家作为当前用户，后续可以优化为用户选择
    return game.players[0].id
  },

  // 计算雷达图数据
  calculateRadarData(weakPoints, totalStats) {
    // 从weakPoints中提取各维度得分
    const driveScore = weakPoints.find(p => p.type === 'drive')?.score || 50
    const approachScore = weakPoints.find(p => p.type === 'approach')?.score || 50
    const puttingScore = weakPoints.find(p => p.type === 'putting')?.score || 50

    // 计算短杆得分（基于推杆和攻果岭综合）
    const shortScore = Math.round((puttingScore * 0.6 + approachScore * 0.4))

    // 计算稳定性得分（基于成绩波动）
    const recentScores = this.data.recentTrend.map(t => t.toPar)
    const variance = recentScores.length > 1
      ? recentScores.reduce((sum, val) => sum + Math.pow(val - recentScores.reduce((a,b) => a+b,0)/recentScores.length, 2), 0) / recentScores.length
      : 20
    const stableScore = Math.max(30, Math.min(100, 90 - variance * 2))

    return {
      drive: Math.min(100, Math.max(0, driveScore)),
      approach: Math.min(100, Math.max(0, approachScore)),
      putting: Math.min(100, Math.max(0, puttingScore)),
      short: Math.min(100, Math.max(0, shortScore)),
      stable: Math.min(100, Math.max(0, Math.round(stableScore)))
    }
  },

  // 获取球场信息
  getCourseById(courseId) {
    const { CHINA_COURSES } = require('../../data/courses-accurate.js')
    const customCourses = wx.getStorageSync('customCourses') || []
    return [...CHINA_COURSES, ...customCourses].find(c => c.id === courseId)
  }
})
