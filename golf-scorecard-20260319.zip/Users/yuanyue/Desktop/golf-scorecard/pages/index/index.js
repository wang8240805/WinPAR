const app = getApp()
// 使用准确数据（374个球场，正确Par分布）
const { CHINA_COURSES } = require('../../data/courses-accurate.js')
const { calculateDistance } = require('../../utils/geo-utils.js')
const COURSE_COUNT = CHINA_COURSES?.length || 0

// 开发模式开关 - 在模拟器中使用模拟数据
const DEV_MODE = false

Page({
  data: {
    currentCourse: null,
    courses: [],
    builtinCourses: [],
    filteredCourses: [],
    nearbyCourses: [],
    recentGames: [],
    hasOngoingGame: false,
    ongoingGame: null,
    ongoingDetail: null,
    showOngoingDetail: false,
    showStatsDetail: false,
    userStats: { totalGames: 0, avgToPar: 0, birdies: 0, bestScore: 0 },
    golfNews: [],
    selectedProvince: '全部',
    provinces: ['全部', '北京', '上海', '广东', '江苏', '浙江', '山东', '四川', '海南', '福建', '云南', '辽宁', '湖北', '湖南', '河南', '河北', '天津', '重庆', '陕西', '安徽', '江西', '广西', '贵州', '山西', '吉林', '黑龙江', '甘肃', '内蒙古', '新疆', '西藏', '宁夏', '青海'],
    courseCount: 0,
    userLocation: null,
    locationAuth: false
  },

  onLoad() {
    console.log('【index】onLoad start')
    console.log('【index】CHINA_COURSES count:', COURSE_COUNT)
    this.initCourses()
    this.loadData()
    this.getUserLocation()
    console.log('【index】onLoad end')
  },

  onShow() {
    this.loadData()
    this.checkOngoingGame()
    // 设置TabBar选中状态 - 首页是第0个
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 0 })
    }
  },

  // 获取用户位置
  getUserLocation() {
    // 开发模式：模拟北京位置
    if (DEV_MODE) {
      const MOCK_LOCATION = { latitude: 39.90, longitude: 116.40 }
      this.setData({
        userLocation: MOCK_LOCATION,
        locationAuth: true
      })
      this.calculateNearbyCourses(MOCK_LOCATION)
      console.log('开发模式：使用模拟位置（北京）')
      return
    }

    // 真实环境调用
    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        const location = {
          latitude: res.latitude,
          longitude: res.longitude
        }
        this.setData({
          userLocation: location,
          locationAuth: true
        })
        this.calculateNearbyCourses(location)
      },
      fail: () => {
        this.setData({ locationAuth: false })
        console.log('未获取到位置权限')
      }
    })
  },

  // 计算并排序附近球场
  calculateNearbyCourses(userLoc) {
    const courses = wx.getStorageSync('courses') || []
    // 过滤掉模拟数据，显示所有真实球场
    const builtinCourses = courses.filter(c => !c.id.startsWith('mock-'))

    const coursesWithDistance = builtinCourses.map(course => {
      const distance = calculateDistance(
        userLoc.latitude, userLoc.longitude,
        course.latitude, course.longitude
      )
      return { ...course, distance }
    })

    // 按距离排序
    const sorted = coursesWithDistance.sort((a, b) => a.distance - b.distance)

    // 取最近的10个
    const nearbyCourses = sorted.slice(0, 10).map(course => ({
      ...course,
      distanceFormatted: this.formatDistance(course.distance)
    }))

    this.setData({
      nearbyCourses
    })
  },

  // 格式化距离显示
  formatDistance(distance) {
    if (distance < 1000) {
      return Math.round(distance) + 'm'
    }
    return (distance / 1000).toFixed(1) + 'km'
  },

  // 初始化球场数据（预置 + 用户自定义）
  initCourses() {
    // 获取当前存储的球场数量和预置数据对比
    const currentCourses = wx.getStorageSync('courses') || []
    const storedCount = currentCourses.length
    const actualCount = CHINA_COURSES.length

    // 如果数据量不对或未初始化，重新加载
    const initialized = wx.getStorageSync('coursesInitialized')
    const dataVersion = wx.getStorageSync('coursesDataVersion')

    // 如果数据版本不对或球场数量不匹配，重新初始化
    if (!initialized || dataVersion !== '387' || storedCount !== actualCount) {
      console.log('重新初始化球场数据:', storedCount, '->', actualCount)

      // 合并预置球场和用户已有球场（保留用户的自定义球场）
      const userCustomCourses = currentCourses.filter(uc =>
        uc.id && (uc.id.startsWith('custom-') || !CHINA_COURSES.some(bc => bc.id === uc.id))
      )
      const allCourses = [...CHINA_COURSES, ...userCustomCourses]

      wx.setStorageSync('courses', allCourses)
      wx.setStorageSync('coursesInitialized', true)
      wx.setStorageSync('coursesDataVersion', '387')

      // 设置默认选中的球场
      if (!wx.getStorageSync('currentCourseId') && CHINA_COURSES.length > 0) {
        wx.setStorageSync('currentCourseId', CHINA_COURSES[0].id)
      }

      console.log('球场数据已初始化，共', allCourses.length, '个球场')
    } else {
      console.log('球场数据已是最新，共', storedCount, '个球场')
    }
  },

  loadData() {
    // 加载球场数据
    let courses = wx.getStorageSync('courses') || []

    // 如果还没有初始化，先初始化
    if (courses.length === 0) {
      this.initCourses()
      courses = wx.getStorageSync('courses') || []
    }

    const currentCourseId = wx.getStorageSync('currentCourseId')
    let currentCourse = courses.find(c => c.id === currentCourseId) || courses[0]

    // 计算每个球场的总标准杆和总距离
    courses.forEach(course => {
      course.totalPar = course.holes.reduce((sum, h) => sum + h.par, 0)
      course.totalDistance = course.holes.reduce((sum, h) => sum + (h.distance || 0), 0)
    })

    // 区分预置球场和自定义球场
    let builtinCourses = courses.filter(c => !c.id.startsWith('mock-') && !c.id.startsWith('custom-'))
    const customCourses = courses.filter(c => c.id.startsWith('custom-'))

    // 按省份筛选
    const { selectedProvince } = this.data
    if (selectedProvince !== '全部') {
      builtinCourses = builtinCourses.filter(c => c.province === selectedProvince)
    }

    // 加载最近比赛
    const games = wx.getStorageSync('games') || []
    const recentGames = games.slice(-3).reverse().map(game => {
      const me = game.players?.find(p => p.isMe) || game.players?.[0]
      return {
        ...game,
        date: this.formatDate(game.timestamp),
        myScore: me?.totalScore || 0
      }
    })

    // 计算当前球场的平均杆数
    const averageScore = this.calculateAverageScore(currentCourse?.id)

    this.setData({
      courses: customCourses,
      builtinCourses,
      currentCourse,
      recentGames,
      courseCount: COURSE_COUNT,
      totalPar: currentCourse?.holes?.reduce((sum, h) => sum + h.par, 0) || 0,
      averageScore,
      hasOngoingGame: false,
      ongoingGame: null
    }, () => {
      // 数据设置完成后，检查是否有进行中的比赛
      this.checkOngoingGame()
    })
  },

  checkOngoingGame() {
    const currentGame = wx.getStorageSync('currentGame')
    if (currentGame && !currentGame.completed) {
      const scores = currentGame.scores || {}
      const players = currentGame.players || []

      // 如果 currentGame 没有 holes，从 courses 中加载
      let holes = currentGame.holes || []
      if (holes.length === 0 && currentGame.courseId) {
        const courses = wx.getStorageSync('courses') || []
        const course = courses.find(c => c.id === currentGame.courseId)
        if (course && course.holes) {
          holes = course.holes
        }
      }

      // 找到当前用户（isMe=true 或第一个球员）
      const me = players.find(p => p.isMe) || players[0]
      if (!me) {
        this.setData({ hasOngoingGame: false, ongoingGame: null })
        return
      }

      const myScores = scores[me.id] || {}

      // 从成绩数据中找出已打的洞
      const playedHoleNumbers = Object.keys(myScores)
        .map(Number)
        .filter(holeNum => myScores[holeNum] > 0)
        .sort((a, b) => a - b)

      // 找到当前打到第几洞（用户有成绩的最后一洞的下一洞）
      const lastPlayedHole = playedHoleNumbers.length > 0 ? playedHoleNumbers[playedHoleNumbers.length - 1] : 0
      const totalHoles = holes.length || 18
      const currentHole = lastPlayedHole === 0 ? 1 : Math.min(lastPlayedHole + 1, totalHoles)

      // 计算已打洞的标准杆总数和总杆数
      let playedPar = 0
      let myStrokes = 0
      let myHolesPlayed = 0

      playedHoleNumbers.forEach(holeNum => {
        // 从 holes 数组中找对应洞的标准杆
        const holeData = holes.find(h => h.hole === holeNum)
        const par = holeData ? holeData.par : 4
        playedPar += par
        myStrokes += myScores[holeNum]
        myHolesPlayed++
      })

      // 只计算已打洞的差点
      const myToPar = myHolesPlayed > 0 ? myStrokes - playedPar : 0

      // 计算预估成绩（按当前进度推算18洞）
      const totalPar = holes.reduce((sum, h) => sum + (h.par || 4), 0)
      const estimatedScore = myHolesPlayed > 0
        ? Math.round((myStrokes / myHolesPlayed) * totalHoles)
        : totalPar

      this.setData({
        hasOngoingGame: true,
        ongoingGame: {
          courseName: currentGame.courseName,
          currentHole,
          totalHoles,
          myScore: {
            name: me.name,
            totalScore: myStrokes,
            holesPlayed: myHolesPlayed,
            toPar: myToPar,
            estimatedScore
          }
        }
      })
    } else {
      this.setData({ hasOngoingGame: false, ongoingGame: null, ongoingDetail: null })
    }
    this.loadUserStats()
  },

  loadUserStats() {
    const games = wx.getStorageSync('games') || []

    // 无论是否有比赛记录，都加载新闻
    this.loadGolfNews()

    if (games.length === 0) return

    let birdies = 0
    let pars = 0
    let improvement = 0
    const scores = []
    const toPars = []

    games.forEach((g, index) => {
      const player = g.players?.find(p => p.isMe) || g.players?.[0]
      if (!player) return

      // 总杆和差点
      if (player.totalScore) {
        scores.push(player.totalScore)
      }
      if (player.toPar !== undefined) {
        toPars.push(player.toPar)
      }

      // 小鸟球和标准杆
      if (player.scores) {
        player.scores.forEach(s => {
          if (s.strokes > 0) {
            const par = s.par || 4
            if (s.strokes < par) birdies++
            else if (s.strokes === par) pars++
          }
        })
      }

      // 计算进步场次（当前比赛比前一场好）
      if (index > 0 && player.toPar !== undefined) {
        const prevGame = games[index - 1]
        const prevPlayer = prevGame.players?.find(p => p.isMe) || prevGame.players?.[0]
        if (prevPlayer && prevPlayer.toPar !== undefined) {
          if (player.toPar < prevPlayer.toPar) improvement++
        }
      }
    })

    this.setData({
      userStats: {
        totalGames: games.length,
        birdies,
        pars,
        improvement,
        bestScore: scores.length ? Math.min(...scores) : 0
      }
    })
  },

  // 加载高尔夫新闻
  // 从本地数据文件读取，需要更新时拉取最新数据文件即可
  // 符合"定期离线更新"的需求，稳定零故障永不失败
  loadGolfNews() {
    try {
      // 尝试读取本地新闻数据
      const golfNewsData = require('../../data/golf-news.js')
      if (golfNewsData && Array.isArray(golfNewsData) && golfNewsData.length > 0) {
        // 取最新5条显示
        const news = golfNewsData.slice(0, 5).map((item, index) => {
          return {
            id: index,
            title: this.cleanTitle(item.title),
            source: item.source || '凤凰体育',
            time: item.time || this.formatTime(item.pubDate),
            url: this.getMobileUrl(item.link || item.url)
          }
        })
        this.setData({ golfNews: news })
        // 缓存到本地存储
        wx.setStorageSync('golfNewsCache', news)
        return
      }
    } catch (e) {
      console.log('读取本地新闻数据失败', e)
    }
    // 失败降级到默认
    this.useDefaultNews()
  },

  // 转换为移动端适配URL
  getMobileUrl(url) {
    // 自动转换为移动端链接，更好的浏览体验
    if (!url) return url
    // 凤凰网PC转移动端
    if (url.includes('ifeng.com')) {
      return url.replace('sports.ifeng.com', 'm.ifeng.com')
    }
    // 新浪PC转移动端
    if (url.includes('sports.sina.com.cn')) {
      return url.replace('sports.sina.com.cn', 'sports.sina.cn')
    }
    // 腾讯PC转移动端
    if (url.includes('sports.qq.com')) {
      return url.replace('sports.qq.com', 'm.sports.qq.com')
    }
    return url
  },

  // 使用默认数据降级
  useDefaultNews() {
    const news = [
      { id: 1, title: '泰勒·麦克罗伊赢得PGA锦标赛冠军', source: '新浪高尔夫', time: '2小时前', url: 'https://sports.sina.com.cn/golf/' },
      { id: 2, title: '2026美国公开赛赛程公布', source: '新浪高尔夫', time: '5小时前', url: 'https://sports.sina.com.cn/golf/' },
      { id: 3, title: '中国高尔夫球队备战新赛季', source: '新浪高尔夫', time: '昨天', url: 'https://sports.sina.com.cn/golf/' }
    ]
    this.setData({ golfNews: news })
  },

  // 清理标题（去掉网站后缀）
  cleanTitle(title) {
    return title.replace(/\s*_.*$/, '').replace(/\s*－.*$/, '').replace(/\s*-.*$/, '')
  },

  // 格式化发布时间为"多久前"
  formatTime(pubDate) {
    try {
      const pubDateTs = new Date(pubDate).getTime()
      const now = Date.now()
      const diff = now - pubDateTs
      const minutes = Math.floor(diff / (1000 * 60))
      const hours = Math.floor(diff / (1000 * 60 * 60))
      const days = Math.floor(diff / (1000 * 60 * 60 * 24))

      if (minutes < 60) {
        return `${minutes}分钟前`
      } else if (hours < 24) {
        return `${hours}小时前`
      } else if (days < 7) {
        return `${days}天前`
      } else {
        const d = new Date(pubDate)
        return `${d.getMonth() + 1}月${d.getDate()}日`
      }
    } catch (e) {
      return '最新'
    }
  },

  // 打开新闻链接
  openNews(e) {
    const url = e.currentTarget.dataset.url
    wx.navigateTo({
      url: '/pages/webview/webview?url=' + encodeURIComponent(url)
    })
  },

  continueGame() {
    this.setData({ showOngoingDetail: true })
  },

  continueGameFromModal() {
    this.setData({ showOngoingDetail: false })
    wx.navigateTo({ url: '/pages/scorecard/scorecard' })
  },

  hideOngoingDetail() {
    this.setData({ showOngoingDetail: false })
  },

  showStatsPopup() {
    this.setData({ showStatsDetail: true })
  },

  hideStatsDetail() {
    this.setData({ showStatsDetail: false })
  },

  preventHide(e) {
    // 阻止冒泡
  },

  formatDate(timestamp) {
    const date = new Date(timestamp)
    return `${date.getMonth() + 1}月${date.getDate()}日`
  },

  // 计算球场的平均杆数
  calculateAverageScore(courseId) {
    if (!courseId) return '-'

    // 从 storage 获取所有比赛记录
    const games = wx.getStorageSync('games') || []

    // 筛选出在该球场完成的比赛
    const courseGames = games.filter(game =>
      game.courseId === courseId && game.completed
    )

    if (courseGames.length === 0) {
      return '-'
    }

    // 计算所有球员的总杆数
    let totalStrokes = 0
    let playerCount = 0

    courseGames.forEach(game => {
      if (game.scores) {
        Object.values(game.scores).forEach(playerScores => {
          // 计算该球员在这场比赛的总杆数
          const playerTotal = Object.values(playerScores).reduce((sum, score) => sum + (score || 0), 0)
          if (playerTotal > 0) {
            totalStrokes += playerTotal
            playerCount++
          }
        })
      }
    })

    if (playerCount === 0) {
      return '-'
    }

    // 返回平均杆数，保留一位小数
    return (totalStrokes / playerCount).toFixed(1)
  },

  // 选择球场
  selectCourse(e) {
    const course = e.currentTarget.dataset.course
    wx.setStorageSync('currentCourseId', course.id)
    this.setData({
      currentCourse: course,
      totalPar: course.holes.reduce((sum, h) => sum + h.par, 0),
      averageScore: this.calculateAverageScore(course.id)
    })
  },

  // 选择最近的球场
  selectNearestCourse() {
    const { nearestCourse } = this.data
    if (nearestCourse) {
      wx.setStorageSync('currentCourseId', nearestCourse.id)
      this.setData({
        currentCourse: nearestCourse,
        totalPar: nearestCourse.totalPar || nearestCourse.holes.reduce((sum, h) => sum + h.par, 0),
        averageScore: this.calculateAverageScore(nearestCourse.id)
      })
      wx.showToast({ title: '已选择：' + nearestCourse.name, icon: 'none' })
    }
  },

  // 按省份筛选
  selectProvince(e) {
    const province = e.currentTarget.dataset.province
    this.setData({ selectedProvince: province })
    this.loadData()
  },

  // 开始新比赛 - 跳转到第一步：选择球场
  startNewGame() {
    // 清空临时球员数据，让用户重新设置
    wx.removeStorageSync('tempPlayers')
    wx.navigateTo({
      url: '/pages/new-game/step1-course/step1-course'
    })
  },

  // 继续比赛
  continueGame() {
    wx.navigateTo({
      url: '/pages/scorecard/scorecard'
    })
  },

  // 跳转历史记录
  goToHistory() {
    wx.navigateTo({
      url: '/pages/history/history'
    })
  },

  // 跳转到记分卡（进行中比赛）
  goToScorecard() {
    wx.navigateTo({
      url: '/pages/scorecard/scorecard'
    })
  },

  // 跳转到高级数据分析页面
  goToStatsAnalysis() {
    wx.navigateTo({
      url: '/pages/stats-analysis/stats-analysis'
    })
  },

  // 跳转设置
  goToSettings() {
    wx.navigateTo({
      url: '/pages/settings/settings'
    })
  },

  // 查看历史比赛详情
  viewGame(e) {
    const gameId = e.currentTarget.dataset.game?.id
    if (!gameId) return

    // 获取完整比赛数据
    const games = wx.getStorageSync('games') || []
    const game = games.find(g => g.id === gameId)

    if (!game) {
      wx.showToast({ title: '比赛数据不存在', icon: 'none' })
      return
    }

    // 如果是未完成的比赛，询问是否继续
    // 支持两种字段判断：completed 布尔值 或 status === 'completed'
    const isCompleted = game.completed === true || game.status === 'completed'
    if (!isCompleted) {
      wx.showModal({
        title: '比赛未结束',
        content: '这场比赛还未完成，是否继续？',
        confirmText: '继续比赛',
        cancelText: '查看详情',
        success: (res) => {
          if (res.confirm) {
            // 设置为当前比赛并跳转记分
            wx.setStorageSync('currentGame', game)
            wx.navigateTo({
              url: '/pages/scorecard/scorecard'
            })
          } else {
            // 查看报告
            this.viewGameReport(game)
          }
        }
      })
    } else {
      // 已完成，先查看记分卡（只读模式）
      this.viewScorecard(game)
    }
  },

  // 查看比赛记分卡（历史比赛只读模式）
  viewScorecard(game) {
    // 将比赛数据存入storage供记分卡页面读取
    wx.setStorageSync('currentGame', game)
    wx.setStorageSync('viewMode', 'readonly') // 标记为只读模式

    wx.navigateTo({
      url: '/pages/scorecard/scorecard?mode=readonly&gameId=' + (game?.id || '')
    })
  },

  // 查看比赛报告
  viewGameReport(game) {
    const historyGames = wx.getStorageSync('games') || []

    // 确保有完整的比赛数据存入storage供详情页读取
    if (game && game.id) {
      wx.setStorageSync('game_' + game.id, game)
    }

    wx.navigateTo({
      url: '/pages/game-report/game-report?gameId=' + (game?.id || ''),
      success: (res) => {
        // 同时通过eventChannel传递数据
        if (res.eventChannel) {
          res.eventChannel.emit('reportData', {
            game: game,
            report: null
          })
        }
      }
    })
  },

  // 搜索球场
  onSearchInput(e) {
    const keyword = e.detail.value.toLowerCase()
    const allCourses = wx.getStorageSync('courses') || []
    const builtinCourses = allCourses.filter(c =>
      !c.id.startsWith('mock-') &&
      !c.id.startsWith('custom-') &&
      (c.name.toLowerCase().includes(keyword) || c.location.toLowerCase().includes(keyword))
    )

    this.setData({ builtinCourses })
  },

  // 跳转到意见反馈页面
  goToFeedback() {
    console.log('goToFeedback clicked')
    wx.navigateTo({
      url: '/pages/feedback/feedback',
      success: () => console.log('navigateTo feedback success'),
      fail: (err) => console.error('navigateTo feedback fail:', err)
    })
  },

  // 跳转到打赏页面
  goToReward() {
    console.log('goToReward clicked')
    wx.navigateTo({
      url: '/pages/reward/reward',
      success: () => console.log('navigateTo reward success'),
      fail: (err) => console.error('navigateTo reward fail:', err)
    })
  }
})
