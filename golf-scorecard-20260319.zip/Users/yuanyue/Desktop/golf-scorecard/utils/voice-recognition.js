/**
 * 语音识别工具
 * 支持自然语言成绩记录
 */

// 语义解析正则规则
const PATTERNS = {
  // 洞号识别: "3号洞", "第三洞", "第3"
  hole: /(\d+)[号]?洞|第(\d+)洞|第(\d+)/,

  // 杆数识别: "5杆", "五杆", "打了5个"
  strokes: /(\d+)\s*杆|([一二两三四五六七八九十]+)杆|([-+]?\d+)\s*个/,

  // 成绩术语: "帕", "小鸟", "柏忌", "老鹰", "双柏忌", "+1", "-1"
  scoreTerms: {
    '老鹰': -2,
    '信天翁': -3,
    '小鸟': -1,
    '帕': 0,
    '标准': 0,
    '平标准': 0,
    '柏忌': 1,
    'bogey': 1,
    '双柏忌': 2,
    '双柏': 2,
    '三柏忌': 3,
    '爆': 3
  },

  // 动作指令
  actions: {
    '上一洞': 'prev',
    '刚才': 'prev',
    '前一个': 'prev',
    '修改': 'edit',
    '改成': 'edit',
    '改为': 'edit',
    '换成': 'edit',
    '删掉': 'delete',
    '删除': 'delete',
    '清空': 'clear'
  }
}

// 中文数字转阿拉伯数字
const CHINESE_NUMBERS = {
  '一': 1, '二': 2, '两': 2, '三': 3, '四': 4, '五': 5,
  '六': 6, '七': 7, '八': 8, '九': 9, '十': 10
}

function parseChineseNumber(str) {
  if (!str) return null
  if (/^\d+$/.test(str)) return parseInt(str)

  let result = 0
  for (let char of str) {
    if (CHINESE_NUMBERS[char]) {
      result += CHINESE_NUMBERS[char]
    }
  }
  return result > 0 ? result : null
}

/**
 * 解析语音输入
 * @param {string} text - 语音识别结果
 * @param {number} currentHole - 当前洞号
 * @param {number} currentPar - 当前标准杆
 * @returns {Object} 解析结果
 */
function parseVoiceInput(text, currentHole = 1, currentPar = 4) {
  text = text.toLowerCase().replace(/\s+/g, '')

  const result = {
    action: 'record', // record, prev, edit, delete
    hole: null,
    strokes: null,
    isValid: false,
    originalText: text
  }

  // 1. 识别动作指令
  for (let [key, action] of Object.entries(PATTERNS.actions)) {
    if (text.includes(key)) {
      result.action = action
      break
    }
  }

  // 2. 识别洞号
  const holeMatch = text.match(PATTERNS.hole)
  if (holeMatch) {
    result.hole = parseInt(holeMatch[1] || holeMatch[2] || holeMatch[3])
  } else if (result.action === 'prev' || text.includes('刚才')) {
    result.hole = Math.max(1, currentHole - 1)
  } else {
    result.hole = currentHole
  }

  // 3. 识别杆数
  // 先尝试直接数字
  const strokeMatch = text.match(PATTERNS.strokes)
  if (strokeMatch) {
    if (strokeMatch[1]) {
      result.strokes = parseInt(strokeMatch[1])
    } else if (strokeMatch[2]) {
      result.strokes = parseChineseNumber(strokeMatch[2])
    } else if (strokeMatch[3]) {
      result.strokes = parseInt(strokeMatch[3])
    }
  }

  // 再尝试成绩术语（相对标准杆）
  if (!result.strokes) {
    for (let [term, offset] of Object.entries(PATTERNS.scoreTerms)) {
      if (text.includes(term)) {
        result.strokes = currentPar + offset
        break
      }
    }
  }

  // 4. 验证结果
  // - 如果识别出洞号且有杆数：有效，录入成绩
  // - 如果只识别出洞号：有效，跳转洞号，不录入（让用户手动输入）
  // - 动作是prev：有效，直接跳转
  const hasValidHole = result.hole >= 1 && result.hole <= 18
  const hasValidStrokes = result.strokes >= 1 && result.strokes <= 20
  const isAction = result.action !== 'record'

  result.isValid = hasValidHole && (hasValidStrokes || isAction)

  return result
}

// 全局录音管理器（保持引用）
let recorderManager = null
// 流式识别管理器
let recognitionManager = null

/**
 * 开始语音识别（文件模式，录音结束后识别）
 * 使用微信录音API + 微信同声传译语音识别，更稳定
 */
function startVoiceRecognition(options = {}) {
  const {
    onStart,
    onRecognize,
    onFinish,
    onError,
    currentHole,
    currentPar
  } = options

  // 尝试加载微信同声传译插件
  try {
    const plugin = requirePlugin('WechatSI')

    // 创建录音管理器
    if (!recorderManager) {
      recorderManager = wx.getRecorderManager()
    }

    // 绑定回调
    recorderManager.onStart(() => {
      console.log('录音开始')
      if (onStart) onStart()
    })

    recorderManager.onError((res) => {
      console.error('录音错误', res)
      if (onError) onError(new Error(res.errMsg))
      recognizeVoiceSimple(options)
    })

    recorderManager.onStop((res) => {
      console.log('录音完成', res)
      const { tempFilePath } = res

      if (!tempFilePath) {
        if (onError) onError(new Error('录音失败'))
        return
      }

      // 使用微信同声传译识别音频文件
      plugin.speechRecognize({
        lang: 'zh_CN',
        filePath: tempFilePath,
        success: (recognizeRes) => {
          console.log('语音识别完整结果:', recognizeRes)
          const text = recognizeRes.result || recognizeRes.text || ''
          console.log('提取识别文本:', text)

          if (!text || text.trim().length === 0) {
            if (onError) onError(new Error('未识别到内容'))
            return
          }

          const parsed = parseVoiceInput(text.trim(), currentHole, currentPar)
          console.log('解析结果:', parsed)
          if (parsed.isValid) {
            if (onRecognize) onRecognize(text, parsed)
          }
          if (onFinish) onFinish(parsed)
        },
        fail: (err) => {
          console.error('识别失败', err)
          if (onError) onError(new Error(err.errMsg || '识别失败'))
          recognizeVoiceSimple(options)
        }
      })
    })

    // 开始录音
    recorderManager.start({
      duration: 60000, // 最长60秒
      sampleRate: 16000,
      numberOfChannels: 1,
      encodeBitRate: 48000,
      format: 'mp3'
    })

    return recorderManager

  } catch (e) {
    // 插件不存在，fallback到手动文字输入
    console.log('微信同声传译插件不可用，使用手动输入', e)
    wx.showToast({
      title: '插件未安装，使用手动输入',
      icon: 'none',
      duration: 1500
    })
    setTimeout(() => {
      recognizeVoiceSimple(options)
    }, 1600)
    return null
  }
}

/**
 * 开始流式语音识别（实时识别，边说边出文字）
 * 使用微信同声传译官方插件的流式识别API
 */
function startStreamingVoiceRecognition(options = {}) {
  const {
    onStart,
    onRecognize,   // 实时识别回调 (text) => {}
    onFinish,       // 识别完成回调 (text, parsed) => {}
    onError,
    currentHole,
    currentPar
  } = options

  // 尝试加载微信同声传译插件
  try {
    const plugin = requirePlugin('WechatSI')

    // 获取流式识别管理器
    if (!recognitionManager) {
      recognitionManager = plugin.getRecordRecognitionManager()
    }

    // 清理之前的监听
    recognitionManager.onStart(() => {
      console.log('流式识别开始')
      if (onStart) onStart()
    })

    recognitionManager.onRecognize((res) => {
      // 实时返回识别结果，不断更新
      const text = res.currentVoice || res.text || ''
      console.log('流式识别中间结果:', text)
      if (onRecognize) onRecognize(text)
    })

    recognitionManager.onStop((res) => {
      // 识别结束，返回最终结果
      console.log('流式识别完成，最终结果:', res)
      const text = (res.text || '').trim()

      if (!text || text.length === 0) {
        if (onError) onError(new Error('未识别到内容'))
        return
      }

      const parsed = parseVoiceInput(text, currentHole, currentPar)
      console.log('解析结果:', parsed)
      if (onFinish) onFinish(text, parsed)
    })

    recognitionManager.onError((res) => {
      console.error('流式识别错误:', res)
      if (onError) onError(new Error(res.errMsg || '识别失败'))
    })

    // 开始流式识别
    recognitionManager.start({
      lang: 'zh_CN',
      duration: 60000
    })

    return recognitionManager

  } catch (e) {
    // 插件不存在，fallback到手动文字输入
    console.log('微信同声传译流式识别不可用，fallback', e)
    wx.showToast({
      title: '流式识别不可用，使用手动输入',
      icon: 'none',
      duration: 1500
    })
    setTimeout(() => {
      recognizeVoiceSimple(options)
    }, 1600)
    return null
  }
}

/**
 * 结束流式语音识别
 */
function stopStreamingVoiceRecognition() {
  if (recognitionManager) {
    recognitionManager.stop()
  }
}

/**
 * 简化的语音识别（使用微信小程序同声传译插件或手动输入模拟）
 */
function recognizeVoiceSimple(options = {}) {
  const { currentHole = 1, currentPar = 4, onSuccess, onError } = options

  // 方案1: 如果安装了同声传译插件
  // const plugin = requirePlugin('WechatSI')
  // plugin.getRecordRecognitionManager()

  // 方案2: 模拟演示（开发测试用）
  wx.showModal({
    title: '语音输入',
    content: '',
    editable: true,
    placeholderText: '请输入语音指令，如："3号洞5杆"、"刚才柏忌"',
    success: (res) => {
      if (res.confirm && res.content) {
        const parsed = parseVoiceInput(res.content, currentHole, currentPar)
        if (onSuccess) onSuccess(parsed)
      } else {
        if (onError) onError(new Error('用户取消'))
      }
    }
  })
}

module.exports = {
  parseVoiceInput,
  startVoiceRecognition,
  recognizeVoiceSimple
}
