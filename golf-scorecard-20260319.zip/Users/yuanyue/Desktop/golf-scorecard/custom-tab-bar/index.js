Component({
  data: {
    selected: 0,
    color: '#999999',
    selectedColor: '#2c8f4e',
    list: [
      {
        pagePath: 'pages/index/index',
        text: '首页',
        icon: 'home'
      },
      {
        pagePath: 'pages/profile/profile',
        text: '我的',
        icon: 'profile'
      }
    ]
  },

  methods: {
    switchTab(e) {
      const data = e.currentTarget.dataset
      const path = this.data.list[data.index].pagePath
      const url = '/' + path

      // 获取当前页面栈
      const pages = getCurrentPages()
      const currentPage = pages[pages.length - 1]
      const currentRoute = currentPage ? currentPage.route : ''

      // 执行跳转
      wx.switchTab({
        url: url,
        success: () => {
          this.setData({
            selected: data.index
          })
        },
        fail: (err) => {
          console.error('[CustomTabBar] switchTab failed:', err)
          wx.navigateTo({ url })
        }
      })
    },

    startNewGame() {
      // 获取当前页面栈
      const pages = getCurrentPages()
      const currentPage = pages[pages.length - 1]
      const currentRoute = currentPage ? currentPage.route : ''

      // 检查是否有进行中的比赛
      const currentGame = wx.getStorageSync('currentGame')
      const hasOngoingGame = currentGame && currentGame.id && !currentGame.completed

      // 如果已经在step1-course页面，则不重复跳转
      if (currentRoute === 'pages/new-game/step1-course/step1-course') {
        return
      }

      // 如果有进行中的比赛，跳转到记分页面
      if (hasOngoingGame) {
        wx.navigateTo({
          url: '/pages/scorecard/scorecard'
        })
        return
      }

      // 如果在新比赛流程的其他页面，重定向到第一步
      if (currentRoute && currentRoute.startsWith('pages/new-game/')) {
        wx.redirectTo({
          url: '/pages/new-game/step1-course/step1-course'
        })
      } else {
        // 导航到新比赛流程的第一步
        wx.navigateTo({
          url: '/pages/new-game/step1-course/step1-course'
        })
      }
    }
  }
})
