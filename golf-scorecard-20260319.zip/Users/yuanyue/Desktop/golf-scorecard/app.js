// 初始化微信云开发
if (!wx.cloud) {
  console.error('请使用 2.2.3 或以上的基础库以使用云开发能力')
} else {
  wx.cloud.init({
    env: 'cloudbase-3g7ya74db1a5f864',
    traceUser: true
  })
}

App({
  onLaunch() {
    // 开发模式：每次启动清除用户授权信息，方便测试授权流程
    const accountInfo = wx.getAccountInfoSync()
    // 真机调试/开发工具环境都清除用户信息
    if (accountInfo.miniProgram.envVersion !== 'release') {
      wx.removeStorageSync('userInfo')
      console.log('[dev] 已清除用户信息，每次启动将重新体验授权流程')
    }

    // 检查本地存储的数据
    const courses = wx.getStorageSync('courses') || []
    if (courses.length === 0) {
      // 初始化默认球场数据（将在首页被覆盖）
      console.log('等待球场数据初始化')
    }

    // 初始化全局数据
    this.globalData = {
      currentCourse: null,
      currentPlayers: [],
      currentScores: {},
      tabBarSelected: 0
    }
  },

  // 设置TabBar选中状态
  setTabBarSelected(index) {
    this.globalData.tabBarSelected = index
    if (this.customTabBar) {
      this.customTabBar.setData({
        selected: index
      })
    }
  },

  globalData: {
    currentCourse: null,
    currentPlayers: [],
    currentScores: {},
    tabBarSelected: 0
  }
})