import sys
import os
# 禁用Paddle模型源检查，加快启动速度
os.environ['PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK'] = 'True'
from sources.dianping import get_beijing_courses, get_course_hole_data
from sources.xiaohongshu import search_beijing_course_scorecards
from processors.validator import validate_course, deduplicate_courses
from utils.export_tool import export_to_course_js
import json

def main():
    print("🚀 高尔夫球场数据爬取工具")
    print("1. 大众点评爬虫")
    print("2. 小红书爬虫")
    choice = input("请选择爬虫类型(1/2): ") if len(sys.argv) < 2 else sys.argv[1]

    valid_courses = []

    if choice == '2':
        print("\n📕 启动小红书爬虫...")
        # 爬取小红书记分卡数据
        courses = search_beijing_course_scorecards()
        valid_courses = [c for c in courses if validate_course(c)]
        output_name = 'courses-beijing-xiaohongshu.js'
    else:
        print("\n💬 启动大众点评爬虫...")
        # 第一步：获取北京球场列表
        print("\n1/3 正在获取北京地区高尔夫球场列表...")
        courses = get_beijing_courses()
        print(f"共获取到{len(courses)}个球场基础信息")

        # 第二步：逐个获取洞标准杆数据
        print("\n2/3 正在逐个爬取球场洞数据...")
        valid_courses = []

        for i, course in enumerate(courses):
            print(f"正在处理 ({i+1}/{len(courses)}): {course['name']}")
            course_data = get_course_hole_data(course)
            if course_data and validate_course(course_data):
                valid_courses.append(course_data)
                # 每获取5个就临时保存一次
                if len(valid_courses) % 5 == 0:
                    with open('output/temp.json', 'w', encoding='utf-8') as f:
                        json.dump(valid_courses, f, ensure_ascii=False, indent=2)
        output_name = 'courses-beijing-dianping.js'

    # 第三步：去重并导出
    print("\n3/3 正在处理数据并导出...")
    unique_courses = deduplicate_courses(valid_courses)
    export_to_course_js(unique_courses, f'output/{output_name}')

    print(f"\n🎉 任务完成！共获取到{len(unique_courses)}个北京地区完整洞数据的球场")

if __name__ == '__main__':
    main()
