import json

def export_to_course_js(courses, output_path='output/courses-beijing.js'):
    """导出为与现有项目格式完全兼容的JS文件"""
    js_template = f"const courses = {json.dumps(courses, ensure_ascii=False, indent=2)};\n\nmodule.exports = courses;"
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(js_template)
    print(f"✅ 导出成功，共{len(courses)}个北京地区有效球场数据")
