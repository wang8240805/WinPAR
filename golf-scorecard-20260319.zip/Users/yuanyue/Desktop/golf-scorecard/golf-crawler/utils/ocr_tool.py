from paddleocr import PaddleOCR
import numpy as np
import cv2
import re

# 初始化OCR模型，只加载一次
ocr = PaddleOCR(use_angle_cls=True, lang='ch')

def recognize_scorecard(img_content):
    """识别高尔夫记分卡图片，返回18洞标准杆和距离数据"""
    try:
        nparr = np.frombuffer(img_content, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        result = ocr.ocr(img, cls=True)

        holes = []
        current_hole = None
        all_text = []

        # 先收集所有识别出的文本
        for line in result:
            for item in line:
                text = item[1][0].strip()
                if text:
                    all_text.append(text)

        # 查找洞号和标准杆数据
        hole_pattern = re.compile(r'[第#]?(\d{1,2})[洞号#]?')
        par_pattern = re.compile(r'(PAR|标准杆|Par|par)\s*(\d)')
        distance_pattern = re.compile(r'(\d{2,4})\s*(码|Y|y|M|m)')

        holes_data = {}
        current_hole_num = None

        for text in all_text:
            # 匹配洞号
            hole_match = hole_pattern.search(text)
            if hole_match:
                hole_num = int(hole_match.group(1))
                if 1 <= hole_num <= 18:
                    current_hole_num = hole_num
                    if current_hole_num not in holes_data:
                        holes_data[current_hole_num] = {'id': current_hole_num, 'par': None, 'distance': None}

            # 匹配标准杆
            if current_hole_num:
                par_match = par_pattern.search(text)
                if par_match:
                    par = int(par_match.group(2))
                    if 3 <= par <=5:
                        holes_data[current_hole_num]['par'] = par

            # 匹配距离
            if current_hole_num:
                dist_match = distance_pattern.search(text)
                if dist_match:
                    dist = int(dist_match.group(1))
                    if 100 <= dist <= 700:
                        holes_data[current_hole_num]['distance'] = dist

        # 转换为列表，只保留有par数据的洞
        holes = [h for h in holes_data.values() if h['par'] is not None]
        holes.sort(key=lambda x: x['id'])

        print(f"  OCR识别到 {len(holes)} 个洞信息: {[h['id'] for h in holes]}")
        if len(holes) > 0:
            print(f"  识别到标准杆: {[h['par'] for h in holes]}")

        # 验证：至少识别出12个洞才保留，允许缺失
        # 用户后续可以手动补全
        if len(holes) >= 12:
            total_par = sum(h['par'] for h in holes)
            # 总标准杆范围放宽到65-75
            if 65 <= total_par <= 75:
                # 如果洞不全，补全缺失的洞
                full_holes = []
                for i in range(1, 19):
                    found = next((h for h in holes if h['id'] == i), None)
                    if found:
                        # 如果没有距离，填充0
                        if found.get('distance') is None:
                            found['distance'] = 0
                        full_holes.append(found)
                    else:
                        # 缺失的洞用默认par=4填充
                        full_holes.append({'id': i, 'par': 4, 'distance': 0})
                total_par_final = sum(h['par'] for h in full_holes)
                print(f"  ✅ 有效记分卡，最终总标准杆: {total_par_final}")
                return full_holes, total_par_final

        print(f"  ❌ 识别洞数量不足({len(holes)}), 跳过")
        return None, 0

    except Exception as e:
        print(f"OCR识别出错: {str(e)}")
        return None, 0
