import requests
import time
import random
from fake_useragent import UserAgent

ua = UserAgent()

def get_session():
    session = requests.Session()
    session.headers.update({
        'User-Agent': ua.random,
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Referer': 'https://www.dianping.com',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8'
    })
    # 随机延迟1-3秒，反爬
    time.sleep(random.uniform(1, 3))
    return session
