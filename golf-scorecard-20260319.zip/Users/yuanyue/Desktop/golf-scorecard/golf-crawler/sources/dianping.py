import re
import json
from utils.http_client import get_session
from utils.ocr_tool import recognize_scorecard

BASE_URL = 'https://www.dianping.com'
CITY_ID = '10' # 北京城市ID

def get_beijing_courses():
    """获取北京地区高尔夫球场列表"""
    session = get_session()
    courses = []

    # 爬取前5页
    for page in range(1, 6):
        try:
            url = f"{BASE_URL}/search/category/{CITY_ID}/10/g34024p{page}"
            response = session.get(url)

            # 解析商家ID和名称
            shop_pattern = re.compile(r'data-shopid="(\d+)".*?data-shopname="([^"]+)"', re.S)
            shops = shop_pattern.findall(response.text)

            for shop_id, shop_name in shops:
                courses.append({
                    'id': f'dp_{shop_id}',
                    'name': shop_name,
                    'city': '北京',
                    'source': '大众点评',
                    'shop_id': shop_id
                })

            print(f"已获取第{page}页，共{len(courses)}个球场")

        except Exception as e:
            print(f"爬取第{page}页出错: {str(e)}")
            continue

    return courses

def get_course_hole_data(course):
    """获取单个球场的洞标准杆数据，通过用户上传的记分卡图片"""
    session = get_session()
    shop_id = course['shop_id']

    try:
        # 爬取商家相册中的记分卡图片
        url = f"{BASE_URL}/shop/{shop_id}/photos/p3" # p3表示环境相册，记分卡一般在这里
        response = session.get(url)

        # 提取图片URL
        img_pattern = re.compile(r'data-src="(https://qcloud.dpfile.com/pc/[^"]+)"', re.S)
        img_urls = img_pattern.findall(response.text)

        for img_url in img_urls[:10]: # 最多检查10张图片
            try:
                img_response = session.get(img_url, timeout=10)
                holes, total_par = recognize_scorecard(img_response.content)

                if holes:
                    print(f"✅ {course['name']} 识别成功，{len(holes)}洞，标准杆{total_par}")
                    course['holes'] = holes
                    course['par'] = total_par
                    course['needsVerification'] = False
                    return course

            except Exception as e:
                continue

    except Exception as e:
        print(f"获取{course['name']}数据出错: {str(e)}")

    return None
