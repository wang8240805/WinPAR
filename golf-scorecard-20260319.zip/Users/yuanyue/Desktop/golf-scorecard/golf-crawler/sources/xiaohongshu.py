import re
import json
import time
import random
import hashlib
from urllib.parse import quote
from utils.http_client import get_session
from utils.ocr_tool import recognize_scorecard

# 小红书Web端API配置
BASE_URL = 'https://www.xiaohongshu.com'
SEARCH_API = 'https://edith.xiaohongshu.com/api/sns/web/v1/search/notes'

# 请填入你登录小红书网页版后的Cookie
COOKIE = 'xsecappid=xhs-pc-web; gid=yj8f0Sid4JSYyj8f0SifdC800dy2F3EvqdxKl632Y9MKF9q8uA438h888qj2K2J8KJ0jSjWD; abRequestId=72afe0cf-8ba6-5716-af21-c3d26757b663; a1=19c65b9b254otvccz9h3dcx8ubxagr90gkn0nat0j30000369377; webId=07f9beca38ac8f9ef77ee72606cb4feb; web_session=04006979dcfb2270966fe199853b4b9cef9a7d; id_token=VjEAAM0lr8nvmXO6kazu2yuVD2o4QkK0mlwkr72ZPTKNxsiVh+I7uNHfxbSv0nJk6nCnPNpi2JMTDQx4rXzFSN32NRzgYbt5i9aLCoKt83MwIoWGMvp5UgcuDvQxMZE55MAmzvnD; webBuild=6.0.0; loadts=1773389994521; websectiga=3fff3a6f9f07284b62c0f2ebf91a3b10193175c06e4f71492b60e056edcdebb2; unread={%22ub%22:%2269b37ebe000000001d026479%22%2C%22ue%22:%2269b39cb40000000021012e37%22%2C%22uc%22:45}; sec_poison_id=91319b34-fcd4-4bfa-916d-c89ea8e2039a; acw_tc=0a00ddd717733936270867315ea0a4070267eb17716c20b066794b10c65fed'

# X-Sign 生成密钥 (小红书web端固定)
X_SIGN_KEY = 'WSUDDyV5wAyZTgIdMQGHvzrjJBmx6HnI'

def generate_x_sign(params, timestamp):
    """生成小红书X-Sign签名"""
    # 按照小红书算法排序参数并拼接
    sorted_keys = sorted(params.keys())
    str_to_sign = ''
    for key in sorted_keys:
        str_to_sign += f'{key}={params[key]}'
    str_to_sign += X_SIGN_KEY + str(timestamp)
    # md5加密
    sign = hashlib.md5(str_to_sign.encode('utf-8')).hexdigest()
    return sign

def get_headers():
    """获取动态请求头"""
    timestamp = int(time.time())
    return {
        'Cookie': COOKIE,
        'Referer': 'https://www.xiaohongshu.com/search_result?keyword=' + quote('北京 高尔夫 记分卡'),
        'Origin': 'https://www.xiaohongshu.com',
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/plain, */*',
        'X-B3-TraceId': ''.join(random.choices('0123456789abcdef', k=32)),
        'X-Timestamp': str(timestamp)
    }

def search_beijing_course_scorecards():
    """搜索北京高尔夫球场记分卡相关笔记"""
    session = get_session()
    courses_data = {}
    keywords = [
        '北京 高尔夫 记分卡',
        '北京 球场 成绩卡',
        '北京高尔夫 18洞 标准杆',
        '北京高尔夫 记分卡',
        '北京高尔夫球场 标准杆'
    ]

    for keyword in keywords:
        print(f"\n正在搜索关键词: {keyword}")

        # 爬取前5页
        for page in range(1, 6):
            try:
                timestamp = int(time.time())
                headers = get_headers()

                data = {
                    'keyword': keyword,
                    'page': page,
                    'page_size': 20,
                    'search_id': f'search_{random.randint(1000000, 9999999)}',
                    'sort': 'general',
                    'note_type': '0'
                }

                # 生成X-Sign签名
                sign = generate_x_sign(data, timestamp)
                headers['X-Sign'] = sign
                session.headers.update(headers)

                # 小红书搜索API是POST请求不是GET
                response = session.post(SEARCH_API, json=data, timeout=15)
                response.raise_for_status()

                try:
                    result = response.json()
                except json.JSONDecodeError:
                    print(f"JSON解析失败，响应内容: {response.text[:200]}")
                    break

                if result.get('code') != 0:
                    print(f"搜索请求失败: code={result.get('code')}, msg={result.get('msg')}")
                    # 如果是认证失败，说明Cookie过期
                    if result.get('code') in [-3, 401, 403]:
                        print("⚠️  Cookie可能已过期，请重新获取")
                    break

                data = result.get('data', {})
                notes = data.get('items', [])
                if not notes:
                    print(f"第{page}页没有更多结果，完整返回: {list(data.keys())}")
                    break

                print(f"第{page}页找到 {len(notes)} 条笔记")
                # 调试：打印第一条笔记结构
                if page == 1 and len(notes) > 0:
                    first_note = notes[0]
                    print(f"第一条笔记keys: {list(first_note.keys())}")
                    if 'note_card' in first_note:
                        print(f"note_cardkeys: {list(first_note['note_card'].keys())}")

                for note in notes:
                    note_id = note.get('id')
                    note_card = note.get('note_card', {})
                    title = note_card.get('display_title', note_card.get('title', ''))
                    desc = note_card.get('desc', '')
                    images = note_card.get('image_list', [])

                    if not images or len(images) == 0:
                        continue

                    # 只处理包含高尔夫关键词的笔记
                    title_lower = title.lower()
                    if '高尔夫' not in title_lower and '球场' not in title_lower and '记分卡' not in title_lower and '成绩卡' not in title_lower:
                        continue

                    # 尝试提取球场名称
                    course_name = extract_course_name(title)
                    if not course_name:
                        course_name = extract_course_name(desc)

                    # 如果还是没提取到，用标题前20个字符
                    if not course_name:
                        clean_title = title[:20].replace('记分卡', '').replace('高尔夫', '').strip()
                        if len(clean_title) >= 2:
                            course_name = f"北京{clean_title}高尔夫"
                        else:
                            continue

                    if course_name in courses_data:
                        print(f"跳过已爬取: {course_name}")
                        continue

                    print(f"🎯 找到候选: {title[:60]}")
                    print(f"   ⤷ 提取名称: {course_name}")

                    # 分析笔记中的所有图片
                    for img in images[:5]:
                        # 获取更大尺寸的图片
                        img_url = img.get('url_pre', img.get('url_default', ''))
                        if not img_url:
                            continue

                        try:
                            # 添加随机延迟
                            time.sleep(random.uniform(1, 3))
                            img_response = session.get(img_url, timeout=15)
                            if img_response.status_code != 200:
                                continue

                            holes, total_par = recognize_scorecard(img_response.content)

                            if holes and len(holes) >= 18:
                                print(f"✅ 识别成功: {course_name}，总标准杆{total_par}")
                                courses_data[course_name] = {
                                    'name': course_name,
                                    'city': '北京',
                                    'par': total_par,
                                    'holes': holes,
                                    'source': '小红书',
                                    'note_id': note_id,
                                    'needsVerification': False
                                }
                                break  # 找到记分卡就不用看其他图片了

                        except Exception as e:
                            print(f"图片识别出错: {str(e)[:50]}")
                            continue

                # 随机延迟避免反爬 - 增加更长的随机间隔
                delay = random.uniform(5, 12)
                print(f"等待 {delay:.1f} 秒后继续...")
                time.sleep(delay)

            except Exception as e:
                print(f"爬取第{page}页出错: {str(e)}")
                time.sleep(random.uniform(10, 20))
                continue

    print(f"\n爬取完成，共找到 {len(courses_data)} 个球场数据")
    return list(courses_data.values())

def extract_course_name(title):
    """从标题中提取球场名称"""
    # 如果标题包含高尔夫，尝试提取整个标题作为球场名称候选
    if '高尔夫' in title or '球场' in title or '记分卡' in title or '成绩卡' in title:
        # 保留前30个字符作为名称
        clean_title = title.replace('记分卡', '').replace('成绩卡', '').replace('高尔夫', '').strip()
        if len(clean_title) > 2:
            # 去掉常见修饰词
            for word in ['北京', '攻略', '周末', '体验', '下场', '打卡', '分享', '今天', '我的']:
                clean_title = clean_title.replace(word, '').strip()
            if len(clean_title) >= 2 and len(clean_title) <= 20:
                if '高尔夫' not in clean_title:
                    return f"北京{clean_title}高尔夫俱乐部"
                return clean_title

    # 常见北京球场名称关键词 - 用于快速匹配
    course_keywords = [
        '华彬', '北湖', '鸿华', '万柳', '天安假日', '清河湾', '伯爵园',
        '丽宫', '渔阳', '银泰鸿业', '加州水郡', '净山湖', 'CBD', '东方天星',
        '北辰', '京南', '龙熙', '龙熙温泉', '雁栖湖', '顺峰', '金熊', '金色河畔',
        '红枫湖', '森林假日', '九松山', '辉煌', '辉煌国际', '云佛山', '君山',
        '人济', '太伟', '东方双鹰', '大运河', '京都', '八达岭', '伯爵园'
    ]

    for keyword in course_keywords:
        if keyword in title:
            # 补全名称
            if '高尔夫' not in title:
                return f"北京{keyword}高尔夫俱乐部"
            # 提取包含关键词的部分
            idx = title.find(keyword)
            end_idx = min(idx + len(keyword) + 5, len(title))
            return title[idx:end_idx].strip()

    return None
