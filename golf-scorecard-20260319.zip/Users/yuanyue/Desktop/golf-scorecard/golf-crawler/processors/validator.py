def validate_course(course):
    """验证球场数据是否有效"""
    if not course.get('name'):
        return False

    # 必须有完整18洞数据
    holes = course.get('holes', [])
    if len(holes) != 18:
        return False

    # 每个洞par必须在3-5之间
    for hole in holes:
        if not (3 <= hole.get('par', 0) <= 5):
            return False
        if hole.get('id', 0) < 1 or hole.get('id', 0) > 18:
            return False

    # 总标准杆必须在70-73之间
    total_par = sum(h['par'] for h in holes)
    if not (70 <= total_par <= 73):
        return False

    return True

def deduplicate_courses(courses):
    """去重，按名称相似度判断"""
    seen = set()
    unique = []

    for course in courses:
        # 简化名称作为key，去掉特殊字符
        name_key = ''.join(filter(lambda c: '\u4e00' <= c <= '\u9fff', course['name']))
        if name_key not in seen:
            seen.add(name_key)
            unique.append(course)

    return unique
