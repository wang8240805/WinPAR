import requests
import json
import time
import random
import hashlib
from urllib.parse import quote
from utils.ocr_tool import recognize_scorecard

# 测试下载图片并OCR识别

COOKIE = 'xsecappid=xhs-pc-web; gid=yj8f0Sid4JSYyj8f0SifdC800dy2F3EvqdxKl632Y9MKF9q8uA438h888qj2K2J8KJ0jSjWD; abRequestId=72afe0cf-8ba6-5716-af21-c3d26757b663; a1=19c65b9b254otvccz9h3dcx8ubxagr90gkn0nat0j30000369377; webId=07f9beca38ac8f9ef77ee72606cb4feb; web_session=04006979dcfb2270966fe199853b4b9cef9a7d; id_token=VjEAAM0lr8nvmXO6kazu2yuVD2o4QkK0mlwkr72ZPTKNxsiVh+I7uNHfxbSv0nJk6nCnPNpi2JMTDQx4rXzFSN32NRzgYbt5i9aLCoKt83MwIoWGMvp5UgcuDvQxMZE55MAmzvnD; webBuild=6.0.0; loadts=1773389994521; websectiga=3fff3a6f9f07284b62c0f2ebf91a3b10193175c06e4f71492b60e056edcdebb2; unread={%22ub%22:%2269b37ebe000000001d026479%22%2C%22ue%22:%2269b39cb40000000021012e37%22%2C%22uc%22:45}; sec_poison_id=91319b34-fcd4-4bfa-916d-c89ea8e2039a; acw_tc=0a00ddd717733936270867315ea0a4070267eb17716c20b066794b10c65fed'

session = requests.Session()
session.headers.update({
    'Cookie': COOKIE,
    'Referer': 'https://www.xiaohongshu.com/search_result',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
})

from sources.xiaohongshu import generate_x_sign, get_headers, SEARCH_API

def get_first_image(course_name):
    timestamp = int(time.time())
    data = {
        'keyword': course_name,
        'page': 1,
        'page_size': 10,
        'search_id': f'search_{random.randint(1000000, 9999999)}',
        'sort': 'general',
        'note_type': '0'
    }
    headers = get_headers()
    sign = generate_x_sign(data, timestamp)
    headers['X-Sign'] = sign

    r = session.post(SEARCH_API, json=data, headers=headers, timeout=15)
    result = r.json()
    items = result.get('data', {}).get('items', [])
    print(f"找到 {len(items)} 条笔记\n")

    for item in items[:3]:
        nc = item.get('note_card', {})
        title = nc.get('display_title', '')
        print(f"📝 标题: {title}")
        images = nc.get('image_list', [])
        print(f"🖼️  图片数: {len(images)}")
        for i, img in enumerate(images[:3]):
            url = img.get('url_pre', img.get('url_default', ''))
            if not url:
                continue
            print(f"  图片{i}: {url[:80]}...")

            # 下载测试
            try:
                resp = session.get(url, timeout=10)
                if resp.status_code == 200:
                    print(f"  ✅ 下载成功，大小: {len(resp.content)} bytes")
                    # 保存到本地看看
                    with open(f'test_img_{i}.jpg', 'wb') as f:
                        f.write(resp.content)
                    holes, total_par = recognize_scorecard(resp.content)
                    if holes and len(holes) >= 1:
                        print(f"  🔍 OCR识别到 {len(holes)} 个洞信息，总标准杆: {total_par}")
                        for h in holes:
                            print(f"    洞{h['id']}: par={h['par']}, distance={h['distance']}")
                    else:
                        print(f"  ❌ OCR识别失败，未能识别足够洞信息")
                else:
                    print(f"  ❌ 下载失败，状态码: {resp.status_code}")
            except Exception as e:
                print(f"  ❌ 下载异常: {e}")
        print()

if __name__ == '__main__':
    print("🔍 测试搜索: 北京 雁栖湖 高尔夫\n")
    get_first_image("北京 雁栖湖 高尔夫")
