import requests
import json
import time
import random
import hashlib
from urllib.parse import quote

# 小红书Web端API配置
SEARCH_API = 'https://edith.xiaohongshu.com/api/sns/web/v1/search/notes'
COOKIE = 'xsecappid=xhs-pc-web; gid=yj8f0Sid4JSYyj8f0SifdC800dy2F3EvqdxKl632Y9MKF9q8uA438h888qj2K2J8KJ0jSjWD; abRequestId=72afe0cf-8ba6-5716-af21-c3d26757b663; a1=19c65b9b254otvccz9h3dcx8ubxagr90gkn0nat0j30000369377; webId=07f9beca38ac8f9ef77ee72606cb4feb; web_session=04006979dcfb2270966fe199853b4b9cef9a7d; id_token=VjEAAM0lr8nvmXO6kazu2yuVD2o4QkK0mlwkr72ZPTKNxsiVh+I7uNHfxbSv0nJk6nCnPNpi2JMTDQx4rXzFSN32NRzgYbt5i9aLCoKt83MwIoWGMvp5UgcuDvQxMZE55MAmzvnD; webBuild=6.0.0; loadts=1773389994521; websectiga=3fff3a6f9f07284b62c0f2ebf91a3b10193175c06e4f71492b60e056edcdebb2; unread={%22ub%22:%2269b37ebe000000001d026479%22%2C%22ue%22:%2269b39cb40000000021012e37%22%2C%22uc%22:45}; sec_poison_id=91319b34-fcd4-4bfa-916d-c89ea8e2039a; acw_tc=0a00ddd717733936270867315ea0a4070267eb17716c20b066794b10c65fed'
X_SIGN_KEY = 'WSUDDyV5wAyZTgIdMQGHvzrjJBmx6HnI'

def generate_x_sign(params, timestamp):
    sorted_keys = sorted(params.keys())
    str_to_sign = ''
    for key in sorted_keys:
        str_to_sign += f'{key}={params[key]}'
    str_to_sign += X_SIGN_KEY + str(timestamp)
    sign = hashlib.md5(str_to_sign.encode('utf-8')).hexdigest()
    return sign

def get_headers():
    timestamp = int(time.time())
    return {
        'Cookie': COOKIE,
        'Referer': 'https://www.xiaohongshu.com/search_result?keyword=' + quote('北京 高尔夫 记分卡'),
        'Origin': 'https://www.xiaohongshu.com',
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/plain, */*',
        'X-B3-TraceId': ''.join(random.choices('0123456789abcdef', k=32)),
        'X-Timestamp': str(timestamp)
    }

session = requests.Session()
keyword = '北京 高尔夫 记分卡'
timestamp = int(time.time())
headers = get_headers()
data = {
    'keyword': keyword,
    'page': 1,
    'page_size': 20,
    'search_id': f'search_{random.randint(1000000, 9999999)}',
    'sort': 'general',
    'note_type': '0'
}
sign = generate_x_sign(data, timestamp)
headers['X-Sign'] = sign

print(f"请求数据: {json.dumps(data, indent=2, ensure_ascii=False)}")
print(f"Headers: {headers}")
print(f"X-Sign: {sign}")

response = session.post(SEARCH_API, json=data, headers=headers, timeout=15)
print(f"\n状态码: {response.status_code}")

try:
    result = response.json()
    print(f"\n返回结构: code={result.get('code')}, msg={result.get('msg')}")
    print(f"data keys: {list(result.get('data', {}).keys())}")
    notes = result.get('data', {}).get('items', [])
    print(f"找到 {len(notes)} 条笔记")
    if len(notes) > 0:
        print("\n第一条笔记:")
        first = notes[0]
        print(f"  id: {first.get('id')}")
        print(f"  keys: {list(first.keys())}")
        if 'note_card' in first:
            nc = first['note_card']
            print(f"  note_card keys: {list(nc.keys())}")
            print(f"  title: {nc.get('title', 'NO_TITLE')}")
            print(f"  desc: {nc.get('desc', 'NO_DESC')[:100]}...")
            images = nc.get('image_list', [])
            print(f"  图片数量: {len(images)}")
except Exception as e:
    print(f"解析JSON失败: {e}")
    print(f"响应内容前500字符: {response.text[:500]}")
