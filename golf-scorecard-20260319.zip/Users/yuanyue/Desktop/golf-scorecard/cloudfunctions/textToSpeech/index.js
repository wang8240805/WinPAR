// 云函数：文字转语音中转
// 使用百度TTS，云函数请求不会有跨域问题

const cloud = require('wx-server-sdk')
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

// 获取百度TTS音频
exports.main = async (event, context) => {
  const { text } = event

  if (!text) {
    return {
      errCode: 1,
      errMsg: '缺少text参数'
    }
  }

  try {
    // 使用百度免费TTS
    const encodedText = encodeURIComponent(text)
    const url = `https://tts.baidu.com/text2audio?lan=zh&pid=101&ie=UTF-8&text=${encodedText}`

    // 获取音频数据
    const response = await fetch(url)
    const audioBuffer = await response.arrayBuffer()

    // 返回音频数据
    return {
      errCode: 0,
      errMsg: 'ok',
      audioData: Buffer.from(audioBuffer).toString('base64'),
      contentType: response.headers.get('content-type')
    }

  } catch (error) {
    console.error('TTS失败', error)
    return {
      errCode: 2,
      errMsg: error.message
    }
  }
}
