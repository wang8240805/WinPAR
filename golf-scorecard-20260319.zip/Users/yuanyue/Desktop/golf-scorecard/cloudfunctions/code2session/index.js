// 云函数：换取openid
// 前端调用 wx.login() 获取code，然后调用这个云函数换取openid

const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

// 微信小程序appid - 直接写死
const appid = 'wx89e0c07e1e728a41'
// 密钥 - 直接写死
const secret = '1a025f7d0caabf42d0896fa7ad410dbd'

exports.main = async (event, context) => {
  const { code } = event

  if (!code) {
    return {
      success: false,
      error: '缺少code参数'
    }
  }

  try {
    // 请求微信接口换取openid
    const url = `https://api.weixin.qq.com/sns/jscode2session?appid=${appid}&secret=${secret}&js_code=${code}&grant_type=authorization_code`

    const response = await fetch(url)
    const data = await response.json()

    console.log('code2session response:', data)

    if (data.errcode) {
      return {
        success: false,
        error: data.errmsg,
        errcode: data.errcode
      }
    }

    // 返回openid和session_key
    return {
      success: true,
      openid: data.openid,
      unionid: data.unionid || null,
      session_key: data.session_key
    }

  } catch (err) {
    console.error('code2session error:', err)
    return {
      success: false,
      error: err.message
    }
  }
}
