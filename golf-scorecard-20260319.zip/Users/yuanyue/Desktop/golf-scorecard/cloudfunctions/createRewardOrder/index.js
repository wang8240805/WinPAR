// 云函数：创建打赏订单，调用微信支付统一下单
// 需要在云开发后台配置：
// 1. 开通微信支付，绑定商户号
// 2. 在云函数环境变量中配置：
//    - appid: 小程序appid
//    - mchid: 微信支付商户号
//    - apiKey: 商户号API密钥

const cloud = require('wx-server-sdk')
const crypto = require('crypto')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

// 生成随机字符串
function generateNonceString(length = 32) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  let result = ''
  for (let i = 0; i < length; i++) {
    result += chars[Math.floor(Math.random() * chars.length)]
  }
  return result
}

// 计算MD5
function md5(str) {
  return crypto.createHash('md5').update(str).digest('hex').toUpperCase()
}

// 整理签名参数
function getSign(params, key) {
  // 按键名ASCII字典序排序
  const sortedKeys = Object.keys(params).sort()
  let string = ''
  for (const k of sortedKeys) {
    if (params[k] && k !== 'sign') {
      string += `${k}=${params[k]}&`
    }
  }
  string += `key=${key}`
  return md5(string)
}

// 统一下单请求
async function unifiedOrder(params, apiKey) {
  const { appid, mchid, body, out_trade_no, total_fee, notify_url } = params

  // 构建请求参数
  const orderParams = {
    appid,
    mch_id: mchid,
    nonce_str: generateNonceString(),
    body,
    out_trade_no,
    total_fee,
    spbill_create_ip: '127.0.0.1',
    notify_url,
    trade_type: 'JSAPI'
  }

  // 计算签名
  orderParams.sign = getSign(orderParams, apiKey)

  // 转换为XML
  let xml = '<xml>'
  for (const [k, v] of Object.entries(orderParams)) {
    xml += `<${k}>${v}</${k}>`
  }
  xml += '</xml>'

  // 请求统一下单API
  const response = await fetch('https://api.mch.weixin.qq.com/pay/unifiedorder', {
    method: 'POST',
    body: xml,
    headers: {
      'Content-Type': 'text/xml'
    }
  })

  const text = await response.text()
  // 简单解析XML返回
  const result = {}
  const reg = /<([^>]+)>([^<]+)<\/[^>]+>/g
  let match
  while ((match = reg.exec(text)) !== null) {
    result[match[1]] = match[2]
  }

  return result
}

exports.main = async (event, context) => {
  const { amount } = event
  const appid = process.env.appid
  const mchid = process.env.mchid
  const apiKey = process.env.apiKey

  // 检查环境变量配置
  if (!appid || !mchid || !apiKey) {
    return {
      errCode: 1,
      errMsg: '请在云函数环境变量中配置 appid, mchid, apiKey'
    }
  }

  // 生成商户订单号
  const outTradeNo = `WINPAR${Date.now()}${Math.floor(Math.random() * 1000)}`

  // 金额转换为分（微信支付要求单位是分）
  const totalFee = Math.round(amount * 100)

  try {
    // 调用统一下单
    const notifyUrl = `https://${cloud.getWXContext().getEnv()}.service.tcloudbase.com/rewardNotify`
    const result = await unifiedOrder({
      appid,
      mchid,
      body: 'WinPAR高尔夫记分卡 - 打赏支持',
      out_trade_no: outTradeNo,
      total_fee: totalFee,
      notify_url: notifyUrl
    }, apiKey)

    if (result.return_code !== 'SUCCESS' || result.result_code !== 'SUCCESS') {
      console.error('统一下单失败', result)
      return {
        errCode: 2,
        errMsg: result.err_code_des || result.return_msg
      }
    }

    // 生成客户端支付参数
    const payment = {
      timeStamp: Date.now().toString(),
      nonceStr: generateNonceString(),
      package: `prepay_id=${result.prepay_id}`,
      signType: 'MD5'
    }
    payment.paySign = getSign(payment, apiKey)

    // 保存订单到数据库
    const db = cloud.database()
    await db.collection('reward_orders').add({
      data: {
        outTradeNo,
        amount,
        totalFee,
        prepayId: result.prepay_id,
        createTime: db.serverDate(),
        status: 'created'
      }
    })

    return {
      errCode: 0,
      errMsg: 'ok',
      payment
    }

  } catch (error) {
    console.error('创建订单异常', error)
    return {
      errCode: 3,
      errMsg: error.message
    }
  }
}
