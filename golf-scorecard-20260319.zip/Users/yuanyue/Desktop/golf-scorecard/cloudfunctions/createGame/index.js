// 云函数：创建新的多人同步比赛
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

exports.main = async (event, context) => {
  const { courseId, courseName, players, gameMode, openid } = event

  try {
    // 创建比赛文档
    const result = await db.collection('games').add({
      data: {
        courseId,
        courseName,
        gameMode,
        // 球员列表，包含每个人的openid，昵称，头像
        players: players.map(p => ({
          id: p.id,
          name: p.name,
          avatar: p.avatar || '',
          openid: p.openid || '',
          isCreator: p.isCreator || false
        })),
        // 所有杆数，key: playerId-holeId -> score
        scores: {},
        // 创建时间
        createTime: db.serverDate(),
        // 更新时间
        updateTime: db.serverDate(),
        // 是否完成
        completed: false
      }
    })

    console.log('创建比赛成功:', result._id)
    return {
      success: true,
      gameId: result._id,
      gameIdString: result._id
    }

  } catch (err) {
    console.error('创建比赛失败:', err)
    return {
      success: false,
      error: err.message
    }
  }
}
